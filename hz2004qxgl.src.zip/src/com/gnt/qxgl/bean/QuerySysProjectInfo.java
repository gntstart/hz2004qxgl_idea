package com.gnt.qxgl.bean;

public class QuerySysProjectInfo extends SysProjectInfo{
	private String xmgly;
	
	private String xmglyxm;

	public String getXmgly() {
		return xmgly;
	}

	public void setXmgly(String xmgly) {
		this.xmgly = xmgly;
	}

	public String getXmglyxm() {
		return xmglyxm;
	}

	public void setXmglyxm(String xmglyxm) {
		this.xmglyxm = xmglyxm;
	}
	
	

}
