package com.gnt.qxgl.bean;


public class QuerySysFunctionInfo extends SysFunctionInfo{
	private String funrole;
	
	private String funrolexm;

	public String getFunrole() {
		return funrole;
	}

	public void setFunrole(String funrole) {
		this.funrole = funrole;
	}

	public String getFunrolexm() {
		return funrolexm;
	}

	public void setFunrolexm(String funrolexm) {
		this.funrolexm = funrolexm;
	}
	
	
}
