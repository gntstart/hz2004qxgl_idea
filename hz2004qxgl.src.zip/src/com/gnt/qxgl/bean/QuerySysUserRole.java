package com.gnt.qxgl.bean;

import com.gnt.qxgl.hz2004.entity.XtJsxxb;

public class QuerySysUserRole extends XtJsxxb {
	private String roleName;
	private String zfpq_opener;

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getZfpq_opener() {
		return zfpq_opener;
	}

	public void setZfpq_opener(String zfpq_opener) {
		this.zfpq_opener = zfpq_opener;
	}
	
	
	
	
}
