package com.gnt.qxgl.hz2004.entity;

import java.util.List;

public class XT_JLXXXB implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	private String  dm;//  char(12) not null,
	private String  mc;//   nvarchar2(100) not null,
	private String  zwpy;// varchar2(50),
	private String  wbpy;// varchar2(20),
	private String qhdm;// char(6) not null,
	private String  bz;//   nvarchar2(100),
	private String  qybz;// char(1) not null,
	private String  bdlx;// char(1),
	private String  bdsj;// char(14)
	private List<XT_JWHXXB> jwhList;
	
	public List<XT_JWHXXB> getJwhList() {
		return jwhList;
	}
	public void setJwhList(List<XT_JWHXXB> jwhList) {
		this.jwhList = jwhList;
	}
	public String getDm() {
		return dm;
	}
	public void setDm(String dm) {
		this.dm = dm;
	}
	public String getMc() {
		return mc;
	}
	public void setMc(String mc) {
		this.mc = mc;
	}
	public String getZwpy() {
		return zwpy;
	}
	public void setZwpy(String zwpy) {
		this.zwpy = zwpy;
	}
	public String getWbpy() {
		return wbpy;
	}
	public void setWbpy(String wbpy) {
		this.wbpy = wbpy;
	}
	public String getQhdm() {
		return qhdm;
	}
	public void setQhdm(String qhdm) {
		this.qhdm = qhdm;
	}
	public String getBz() {
		return bz;
	}
	public void setBz(String bz) {
		this.bz = bz;
	}
	public String getQybz() {
		return qybz;
	}
	public void setQybz(String qybz) {
		this.qybz = qybz;
	}
	public String getBdlx() {
		return bdlx;
	}
	public void setBdlx(String bdlx) {
		this.bdlx = bdlx;
	}
	public String getBdsj() {
		return bdsj;
	}
	public void setBdsj(String bdsj) {
		this.bdsj = bdsj;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
