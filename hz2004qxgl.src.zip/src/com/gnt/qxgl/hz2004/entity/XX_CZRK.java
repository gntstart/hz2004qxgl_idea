package com.gnt.qxgl.hz2004.entity;

import java.io.Serializable;

public class XX_CZRK  implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Long czrkrkid;
	private String czrkssssxq;
	private String czrkgmsfhm;
	private String czrkxm;
	private String czrkcym;
	private String czrkxb;
	private String czrkmz;
	private String czrkcsrq;
	private String czrkcsdgj;
	private String czrkcsdssx;
	private String czrkcsdxz;
	private String czrkjggj;
	private String czrkjgssx;
	private String czrkwhcd;
	private String czrkhyzk;
	private String czrkbyzk;
	private String czrksg;
	private String czrkzy;
	private String czrkfwcs;
	private String czrkzz;
	private Long czrkxpid;
	private String czrkxxjb;
	private String czrkzxbs;
	private String czrkxjgajgmc;
	private String czrkxjgajgjgdm;
	private String czrkpcsmc;
	private String czrkpcsjgdm;
	private String czrkxxtqsj;
	private String czrkryid;
	private String czrkhsqlbs;
	private String czrkhyqlbs;
	private String czrkhdqlgj;
	private String czrkhdqlssx;
	private String czrkhdqlxz;
	private String czrkssxzjd;
	private String czrkjhryhm;
	private String czrkjhryxm;
	private String czrkjhrygx;
	private String czrkjhrehm;
	private String czrkjhrexm;
	private String czrkjhregx;
	private String czrkfqhm;
	private String czrkfqxm;
	private String czrkmqhm;
	private String czrkmqxm;
	private String czrkpohm;
	private String czrkpoxm;
	private String czrkzjxy;
	private String czrkxx;
	private String czrkzylb;
	private String czrkswrq;
	private String czrkswzxlb;
	private String czrkqcrq;
	private String czrkqczxlb;
	private String czrkqwdgj;
	private String czrkqwdssx;
	private String czrkqwdxz;
	private String czrkcszmbh;
	private String czrkbwbh;
	private String czrkjlxmc;
	private String czrkjwhmc;
	private String czrkhsqlbz;
	private String czrkhyqlbz;
	private String czrkhzqlgj;
	private String czrkhzqlssx;
	private String czrkhzqlxz;
	private String czrkhh;
	private String czrkhlx;
	private String czrkyhzgx;
	private String czrkbwbhb;
	private String czrklxdh;
	private String sjbz;
	private String czrkzxrq;
	private String czrksjxgxsj;
	private String czrkjlx;
	private String czrkjwh;
	private String czrkxzjd;
	private String czrkmlph;
	private String czrkmlxz;
	private String czrkxmpy;
	public Long getCzrkrkid() {
		return czrkrkid;
	}
	public void setCzrkrkid(Long czrkrkid) {
		this.czrkrkid = czrkrkid;
	}
	public String getCzrkssssxq() {
		return czrkssssxq;
	}
	public void setCzrkssssxq(String czrkssssxq) {
		this.czrkssssxq = czrkssssxq;
	}
	public String getCzrkgmsfhm() {
		return czrkgmsfhm;
	}
	public void setCzrkgmsfhm(String czrkgmsfhm) {
		this.czrkgmsfhm = czrkgmsfhm;
	}
	public String getCzrkxm() {
		return czrkxm;
	}
	public void setCzrkxm(String czrkxm) {
		this.czrkxm = czrkxm;
	}
	public String getCzrkcym() {
		return czrkcym;
	}
	public void setCzrkcym(String czrkcym) {
		this.czrkcym = czrkcym;
	}
	public String getCzrkxb() {
		return czrkxb;
	}
	public void setCzrkxb(String czrkxb) {
		this.czrkxb = czrkxb;
	}
	public String getCzrkmz() {
		return czrkmz;
	}
	public void setCzrkmz(String czrkmz) {
		this.czrkmz = czrkmz;
	}
	public String getCzrkcsrq() {
		return czrkcsrq;
	}
	public void setCzrkcsrq(String czrkcsrq) {
		this.czrkcsrq = czrkcsrq;
	}
	public String getCzrkcsdgj() {
		return czrkcsdgj;
	}
	public void setCzrkcsdgj(String czrkcsdgj) {
		this.czrkcsdgj = czrkcsdgj;
	}
	public String getCzrkcsdssx() {
		return czrkcsdssx;
	}
	public void setCzrkcsdssx(String czrkcsdssx) {
		this.czrkcsdssx = czrkcsdssx;
	}
	public String getCzrkcsdxz() {
		return czrkcsdxz;
	}
	public void setCzrkcsdxz(String czrkcsdxz) {
		this.czrkcsdxz = czrkcsdxz;
	}
	public String getCzrkjggj() {
		return czrkjggj;
	}
	public void setCzrkjggj(String czrkjggj) {
		this.czrkjggj = czrkjggj;
	}
	public String getCzrkjgssx() {
		return czrkjgssx;
	}
	public void setCzrkjgssx(String czrkjgssx) {
		this.czrkjgssx = czrkjgssx;
	}
	public String getCzrkwhcd() {
		return czrkwhcd;
	}
	public void setCzrkwhcd(String czrkwhcd) {
		this.czrkwhcd = czrkwhcd;
	}
	public String getCzrkhyzk() {
		return czrkhyzk;
	}
	public void setCzrkhyzk(String czrkhyzk) {
		this.czrkhyzk = czrkhyzk;
	}
	public String getCzrkbyzk() {
		return czrkbyzk;
	}
	public void setCzrkbyzk(String czrkbyzk) {
		this.czrkbyzk = czrkbyzk;
	}
	public String getCzrksg() {
		return czrksg;
	}
	public void setCzrksg(String czrksg) {
		this.czrksg = czrksg;
	}
	public String getCzrkzy() {
		return czrkzy;
	}
	public void setCzrkzy(String czrkzy) {
		this.czrkzy = czrkzy;
	}
	public String getCzrkfwcs() {
		return czrkfwcs;
	}
	public void setCzrkfwcs(String czrkfwcs) {
		this.czrkfwcs = czrkfwcs;
	}
	public String getCzrkzz() {
		return czrkzz;
	}
	public void setCzrkzz(String czrkzz) {
		this.czrkzz = czrkzz;
	}
	public Long getCzrkxpid() {
		return czrkxpid;
	}
	public void setCzrkxpid(Long czrkxpid) {
		this.czrkxpid = czrkxpid;
	}
	public String getCzrkxxjb() {
		return czrkxxjb;
	}
	public void setCzrkxxjb(String czrkxxjb) {
		this.czrkxxjb = czrkxxjb;
	}
	public String getCzrkzxbs() {
		return czrkzxbs;
	}
	public void setCzrkzxbs(String czrkzxbs) {
		this.czrkzxbs = czrkzxbs;
	}
	public String getCzrkxjgajgmc() {
		return czrkxjgajgmc;
	}
	public void setCzrkxjgajgmc(String czrkxjgajgmc) {
		this.czrkxjgajgmc = czrkxjgajgmc;
	}
	public String getCzrkxjgajgjgdm() {
		return czrkxjgajgjgdm;
	}
	public void setCzrkxjgajgjgdm(String czrkxjgajgjgdm) {
		this.czrkxjgajgjgdm = czrkxjgajgjgdm;
	}
	public String getCzrkpcsmc() {
		return czrkpcsmc;
	}
	public void setCzrkpcsmc(String czrkpcsmc) {
		this.czrkpcsmc = czrkpcsmc;
	}
	public String getCzrkpcsjgdm() {
		return czrkpcsjgdm;
	}
	public void setCzrkpcsjgdm(String czrkpcsjgdm) {
		this.czrkpcsjgdm = czrkpcsjgdm;
	}
	public String getCzrkxxtqsj() {
		return czrkxxtqsj;
	}
	public void setCzrkxxtqsj(String czrkxxtqsj) {
		this.czrkxxtqsj = czrkxxtqsj;
	}
	public String getCzrkryid() {
		return czrkryid;
	}
	public void setCzrkryid(String czrkryid) {
		this.czrkryid = czrkryid;
	}
	public String getCzrkhsqlbs() {
		return czrkhsqlbs;
	}
	public void setCzrkhsqlbs(String czrkhsqlbs) {
		this.czrkhsqlbs = czrkhsqlbs;
	}
	public String getCzrkhyqlbs() {
		return czrkhyqlbs;
	}
	public void setCzrkhyqlbs(String czrkhyqlbs) {
		this.czrkhyqlbs = czrkhyqlbs;
	}
	public String getCzrkhdqlgj() {
		return czrkhdqlgj;
	}
	public void setCzrkhdqlgj(String czrkhdqlgj) {
		this.czrkhdqlgj = czrkhdqlgj;
	}
	public String getCzrkhdqlssx() {
		return czrkhdqlssx;
	}
	public void setCzrkhdqlssx(String czrkhdqlssx) {
		this.czrkhdqlssx = czrkhdqlssx;
	}
	public String getCzrkhdqlxz() {
		return czrkhdqlxz;
	}
	public void setCzrkhdqlxz(String czrkhdqlxz) {
		this.czrkhdqlxz = czrkhdqlxz;
	}
	public String getCzrkssxzjd() {
		return czrkssxzjd;
	}
	public void setCzrkssxzjd(String czrkssxzjd) {
		this.czrkssxzjd = czrkssxzjd;
	}
	public String getCzrkjhryhm() {
		return czrkjhryhm;
	}
	public void setCzrkjhryhm(String czrkjhryhm) {
		this.czrkjhryhm = czrkjhryhm;
	}
	public String getCzrkjhryxm() {
		return czrkjhryxm;
	}
	public void setCzrkjhryxm(String czrkjhryxm) {
		this.czrkjhryxm = czrkjhryxm;
	}
	public String getCzrkjhrygx() {
		return czrkjhrygx;
	}
	public void setCzrkjhrygx(String czrkjhrygx) {
		this.czrkjhrygx = czrkjhrygx;
	}
	public String getCzrkjhrehm() {
		return czrkjhrehm;
	}
	public void setCzrkjhrehm(String czrkjhrehm) {
		this.czrkjhrehm = czrkjhrehm;
	}
	public String getCzrkjhrexm() {
		return czrkjhrexm;
	}
	public void setCzrkjhrexm(String czrkjhrexm) {
		this.czrkjhrexm = czrkjhrexm;
	}
	public String getCzrkjhregx() {
		return czrkjhregx;
	}
	public void setCzrkjhregx(String czrkjhregx) {
		this.czrkjhregx = czrkjhregx;
	}
	public String getCzrkfqhm() {
		return czrkfqhm;
	}
	public void setCzrkfqhm(String czrkfqhm) {
		this.czrkfqhm = czrkfqhm;
	}
	public String getCzrkfqxm() {
		return czrkfqxm;
	}
	public void setCzrkfqxm(String czrkfqxm) {
		this.czrkfqxm = czrkfqxm;
	}
	public String getCzrkmqhm() {
		return czrkmqhm;
	}
	public void setCzrkmqhm(String czrkmqhm) {
		this.czrkmqhm = czrkmqhm;
	}
	public String getCzrkmqxm() {
		return czrkmqxm;
	}
	public void setCzrkmqxm(String czrkmqxm) {
		this.czrkmqxm = czrkmqxm;
	}
	public String getCzrkpohm() {
		return czrkpohm;
	}
	public void setCzrkpohm(String czrkpohm) {
		this.czrkpohm = czrkpohm;
	}
	public String getCzrkpoxm() {
		return czrkpoxm;
	}
	public void setCzrkpoxm(String czrkpoxm) {
		this.czrkpoxm = czrkpoxm;
	}
	public String getCzrkzjxy() {
		return czrkzjxy;
	}
	public void setCzrkzjxy(String czrkzjxy) {
		this.czrkzjxy = czrkzjxy;
	}
	public String getCzrkxx() {
		return czrkxx;
	}
	public void setCzrkxx(String czrkxx) {
		this.czrkxx = czrkxx;
	}
	public String getCzrkzylb() {
		return czrkzylb;
	}
	public void setCzrkzylb(String czrkzylb) {
		this.czrkzylb = czrkzylb;
	}
	public String getCzrkswrq() {
		return czrkswrq;
	}
	public void setCzrkswrq(String czrkswrq) {
		this.czrkswrq = czrkswrq;
	}
	public String getCzrkswzxlb() {
		return czrkswzxlb;
	}
	public void setCzrkswzxlb(String czrkswzxlb) {
		this.czrkswzxlb = czrkswzxlb;
	}
	public String getCzrkqcrq() {
		return czrkqcrq;
	}
	public void setCzrkqcrq(String czrkqcrq) {
		this.czrkqcrq = czrkqcrq;
	}
	public String getCzrkqczxlb() {
		return czrkqczxlb;
	}
	public void setCzrkqczxlb(String czrkqczxlb) {
		this.czrkqczxlb = czrkqczxlb;
	}
	public String getCzrkqwdgj() {
		return czrkqwdgj;
	}
	public void setCzrkqwdgj(String czrkqwdgj) {
		this.czrkqwdgj = czrkqwdgj;
	}
	public String getCzrkqwdssx() {
		return czrkqwdssx;
	}
	public void setCzrkqwdssx(String czrkqwdssx) {
		this.czrkqwdssx = czrkqwdssx;
	}
	public String getCzrkqwdxz() {
		return czrkqwdxz;
	}
	public void setCzrkqwdxz(String czrkqwdxz) {
		this.czrkqwdxz = czrkqwdxz;
	}
	public String getCzrkcszmbh() {
		return czrkcszmbh;
	}
	public void setCzrkcszmbh(String czrkcszmbh) {
		this.czrkcszmbh = czrkcszmbh;
	}
	public String getCzrkbwbh() {
		return czrkbwbh;
	}
	public void setCzrkbwbh(String czrkbwbh) {
		this.czrkbwbh = czrkbwbh;
	}
	public String getCzrkjlxmc() {
		return czrkjlxmc;
	}
	public void setCzrkjlxmc(String czrkjlxmc) {
		this.czrkjlxmc = czrkjlxmc;
	}
	public String getCzrkjwhmc() {
		return czrkjwhmc;
	}
	public void setCzrkjwhmc(String czrkjwhmc) {
		this.czrkjwhmc = czrkjwhmc;
	}
	public String getCzrkhsqlbz() {
		return czrkhsqlbz;
	}
	public void setCzrkhsqlbz(String czrkhsqlbz) {
		this.czrkhsqlbz = czrkhsqlbz;
	}
	public String getCzrkhyqlbz() {
		return czrkhyqlbz;
	}
	public void setCzrkhyqlbz(String czrkhyqlbz) {
		this.czrkhyqlbz = czrkhyqlbz;
	}
	public String getCzrkhzqlgj() {
		return czrkhzqlgj;
	}
	public void setCzrkhzqlgj(String czrkhzqlgj) {
		this.czrkhzqlgj = czrkhzqlgj;
	}
	public String getCzrkhzqlssx() {
		return czrkhzqlssx;
	}
	public void setCzrkhzqlssx(String czrkhzqlssx) {
		this.czrkhzqlssx = czrkhzqlssx;
	}
	public String getCzrkhzqlxz() {
		return czrkhzqlxz;
	}
	public void setCzrkhzqlxz(String czrkhzqlxz) {
		this.czrkhzqlxz = czrkhzqlxz;
	}
	public String getCzrkhh() {
		return czrkhh;
	}
	public void setCzrkhh(String czrkhh) {
		this.czrkhh = czrkhh;
	}
	public String getCzrkhlx() {
		return czrkhlx;
	}
	public void setCzrkhlx(String czrkhlx) {
		this.czrkhlx = czrkhlx;
	}
	public String getCzrkyhzgx() {
		return czrkyhzgx;
	}
	public void setCzrkyhzgx(String czrkyhzgx) {
		this.czrkyhzgx = czrkyhzgx;
	}
	public String getCzrkbwbhb() {
		return czrkbwbhb;
	}
	public void setCzrkbwbhb(String czrkbwbhb) {
		this.czrkbwbhb = czrkbwbhb;
	}
	public String getCzrklxdh() {
		return czrklxdh;
	}
	public void setCzrklxdh(String czrklxdh) {
		this.czrklxdh = czrklxdh;
	}
	public String getSjbz() {
		return sjbz;
	}
	public void setSjbz(String sjbz) {
		this.sjbz = sjbz;
	}
	public String getCzrkzxrq() {
		return czrkzxrq;
	}
	public void setCzrkzxrq(String czrkzxrq) {
		this.czrkzxrq = czrkzxrq;
	}
	public String getCzrksjxgxsj() {
		return czrksjxgxsj;
	}
	public void setCzrksjxgxsj(String czrksjxgxsj) {
		this.czrksjxgxsj = czrksjxgxsj;
	}
	public String getCzrkjlx() {
		return czrkjlx;
	}
	public void setCzrkjlx(String czrkjlx) {
		this.czrkjlx = czrkjlx;
	}
	public String getCzrkjwh() {
		return czrkjwh;
	}
	public void setCzrkjwh(String czrkjwh) {
		this.czrkjwh = czrkjwh;
	}
	public String getCzrkxzjd() {
		return czrkxzjd;
	}
	public void setCzrkxzjd(String czrkxzjd) {
		this.czrkxzjd = czrkxzjd;
	}
	public String getCzrkmlph() {
		return czrkmlph;
	}
	public void setCzrkmlph(String czrkmlph) {
		this.czrkmlph = czrkmlph;
	}
	public String getCzrkmlxz() {
		return czrkmlxz;
	}
	public void setCzrkmlxz(String czrkmlxz) {
		this.czrkmlxz = czrkmlxz;
	}
	public String getCzrkxmpy() {
		return czrkxmpy;
	}
	public void setCzrkxmpy(String czrkxmpy) {
		this.czrkxmpy = czrkxmpy;
	}
}
