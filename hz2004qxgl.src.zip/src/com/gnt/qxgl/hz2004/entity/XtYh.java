package com.gnt.qxgl.hz2004.entity;

import java.io.Serializable;
import java.util.Date;

public class XtYh  implements Serializable{
	private String yhid;
	private String dlm;
	private String jyh;
	private String ssdwjgdm;
	private String xm;
	private String xb;
	private String dlkl;
	private String xxjb;
	private String zt;
	private String gmsfhm;
	private String yhjzsj;
	private String dlsid;
	private Date dlsidsj;
	
	public String getDlsid() {
		return dlsid;
	}
	public void setDlsid(String dlsid) {
		this.dlsid = dlsid;
	}
	public Date getDlsidsj() {
		return dlsidsj;
	}
	public void setDlsidsj(Date dlsidsj) {
		this.dlsidsj = dlsidsj;
	}
	public String getYhid() {
		return yhid;
	}
	public void setYhid(String yhid) {
		this.yhid = yhid;
	}
	public String getDlm() {
		return dlm;
	}
	public void setDlm(String dlm) {
		this.dlm = dlm;
	}
	public String getJyh() {
		return jyh;
	}
	public void setJyh(String jyh) {
		this.jyh = jyh;
	}
	public String getSsdwjgdm() {
		return ssdwjgdm;
	}
	public void setSsdwjgdm(String ssdwjgdm) {
		this.ssdwjgdm = ssdwjgdm;
	}
	public String getXm() {
		return xm;
	}
	public void setXm(String xm) {
		this.xm = xm;
	}
	public String getXb() {
		return xb;
	}
	public void setXb(String xb) {
		this.xb = xb;
	}
	public String getDlkl() {
		return dlkl;
	}
	public void setDlkl(String dlkl) {
		this.dlkl = dlkl;
	}
	public String getXxjb() {
		return xxjb;
	}
	public void setXxjb(String xxjb) {
		this.xxjb = xxjb;
	}
	public String getZt() {
		return zt;
	}
	public void setZt(String zt) {
		this.zt = zt;
	}
	public String getGmsfhm() {
		return gmsfhm;
	}
	public void setGmsfhm(String gmsfhm) {
		this.gmsfhm = gmsfhm;
	}
	public String getYhjzsj() {
		return yhjzsj;
	}
	public void setYhjzsj(String yhjzsj) {
		this.yhjzsj = yhjzsj;
	}
}
