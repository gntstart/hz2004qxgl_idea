package com.gnt.qxgl.hz2004.entity;

import java.io.Serializable;

public class XtSpdzb implements Serializable{
	private String	dzid;
	private String	dzmc;
	private String	ms;
	private String	fwjb;
	private String	qybz;
	private String dqbm;
	
	public String getDqbm() {
		return dqbm;
	}

	public void setDqbm(String dqbm) {
		this.dqbm = dqbm;
	}

	public String getDzid(){
		return this.dzid;
	}

	public void setDzid(String dzid){
		this.dzid=dzid;
	}

	public String getDzmc(){
		return this.dzmc;
	}

	public void setDzmc(String dzmc){
		this.dzmc=dzmc;
	}

	public String getMs(){
		return this.ms;
	}

	public void setMs(String ms){
		this.ms=ms;
	}

	public String getFwjb(){
		return this.fwjb;
	}

	public void setFwjb(String fwjb){
		this.fwjb=fwjb;
	}

	public String getQybz(){
		return this.qybz;
	}

	public void setQybz(String qybz){
		this.qybz=qybz;
	}

	public String getLayerOooo(){
		return "";
	}

	public void setLayerOooo(String layerOoooo){
	}
}