package com.gnt.qxgl.hz2004.entity;

import java.io.Serializable;

public class XtYhsjfwb implements Serializable{
	private static final long serialVersionUID = 1L;
	private String	sjfwid;
	private String	yhid;
	private String	xqlx;
	private String	sjfw;
	private String dqbm;
	private String yhxm;
	private String yhdlm;

	public String getYhxm() {
		return yhxm;
	}

	public void setYhxm(String yhxm) {
		this.yhxm = yhxm;
	}

	public String getYhdlm() {
		return yhdlm;
	}

	public void setYhdlm(String yhdlm) {
		this.yhdlm = yhdlm;
	}

	public String getDqbm() {
		return dqbm;
	}

	public void setDqbm(String dqbm) {
		this.dqbm = dqbm;
	}

	public String getSjfwid(){
		return this.sjfwid;
	}

	public void setSjfwid(String sjfwid){
		this.sjfwid=sjfwid;
	}

	public String getYhid(){
		return this.yhid;
	}

	public void setYhid(String yhid){
		this.yhid=yhid;
	}

	public String getXqlx(){
		return this.xqlx;
	}

	public void setXqlx(String xqlx){
		this.xqlx=xqlx;
	}

	public String getSjfw(){
		return this.sjfw;
	}

	public void setSjfw(String sjfw){
		this.sjfw=sjfw;
	}

	public String getLayerOooo(){
		return "";
	}

	public void setLayerOooo(String layerOoooo){
	}
}