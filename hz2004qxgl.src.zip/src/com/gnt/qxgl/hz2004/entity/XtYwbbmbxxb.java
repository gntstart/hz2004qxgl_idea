package com.gnt.qxgl.hz2004.entity;

import java.io.Serializable;

/**
*涓氬姟鎶ヨ〃妯℃澘淇℃伅琛�
*/
public class XtYwbbmbxxb implements Serializable{
	/*
	*鍗曚綅灞傛鐮�
	*/
	/*
	*涓氬姟鎶ヨ〃ID
	*/
	private String	ywbbid;
	/*
	*涓氬姟鎶ヨ〃绫诲埆
	*/
	private String	ywbblb;
	/*
	*鎶ヨ〃鍚嶇О
	*/
	private String	bbmc;
	/*
	*鎶ヨ〃妯℃澘
	*/
	private String	bbmb;
	/*
	*寤虹珛鏃堕棿
	*/
	private String	jlsj;
	/*
	*寤虹珛浜篒D
	*/
	private String	jlrid;
	/*
	*淇敼鏃堕棿
	*/
	private String	xgsj;
	/*
	*淇敼浜篒D
	*/
	private String	xgrid;



	public String getYwbbid(){
		return this.ywbbid;
	}

	public void setYwbbid(String ywbbid){
		this.ywbbid=ywbbid;
	}

	public String getYwbblb(){
		return this.ywbblb;
	}

	public void setYwbblb(String ywbblb){
		this.ywbblb=ywbblb;
	}

	public String getBbmc(){
		return this.bbmc;
	}

	public void setBbmc(String bbmc){
		this.bbmc=bbmc;
	}

	public String getBbmb(){
		return this.bbmb;
	}

	public void setBbmb(String bbmb){
		this.bbmb=bbmb;
	}

	public String getJlsj(){
		return this.jlsj;
	}

	public void setJlsj(String jlsj){
		this.jlsj=jlsj;
	}

	public String getJlrid(){
		return this.jlrid;
	}

	public void setJlrid(String jlrid){
		this.jlrid=jlrid;
	}

	public String getXgsj(){
		return this.xgsj;
	}

	public void setXgsj(String xgsj){
		this.xgsj=xgsj;
	}

	public String getXgrid(){
		return this.xgrid;
	}

	public void setXgrid(String xgrid){
		this.xgrid=xgrid;
	}
}