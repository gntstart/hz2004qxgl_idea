package com.gnt.qxgl.hz2004.entity;

import java.io.Serializable;

public class XtYhipyxxxb implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String	ipyxid;
	private String	yhid;
	private String	ipdz;
	private String	cjrid;
	private String	cjsj;
	private String dqbm;
	private String yhxm;
	private String yhdlm;
	private String cjrxm;
	
	public String getYhdlm() {
		return yhdlm;
	}

	public void setYhdlm(String yhdlm) {
		this.yhdlm = yhdlm;
	}

	public String getCjrxm() {
		return cjrxm;
	}

	public void setCjrxm(String cjrxm) {
		this.cjrxm = cjrxm;
	}

	public String getYhxm() {
		return yhxm;
	}

	public void setYhxm(String yhxm) {
		this.yhxm = yhxm;
	}

	public String getDqbm() {
		return dqbm;
	}

	public void setDqbm(String dqbm) {
		this.dqbm = dqbm;
	}
	
	public String getIpyxid(){
		return this.ipyxid;
	}

	public void setIpyxid(String ipyxid){
		this.ipyxid=ipyxid;
	}

	public String getYhid(){
		return this.yhid;
	}

	public void setYhid(String yhid){
		this.yhid=yhid;
	}

	public String getIpdz(){
		return this.ipdz;
	}

	public void setIpdz(String ipdz){
		this.ipdz=ipdz;
	}

	public String getCjrid(){
		return this.cjrid;
	}

	public void setCjrid(String cjrid){
		this.cjrid=cjrid;
	}

	public String getCjsj(){
		return this.cjsj;
	}

	public void setCjsj(String cjsj){
		this.cjsj=cjsj;
	}

	public String getLayerOooo(){
		return "";
	}

	public void setLayerOooo(String layerOoooo){
	}
}