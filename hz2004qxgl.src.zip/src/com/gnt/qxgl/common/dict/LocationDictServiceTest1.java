package com.gnt.qxgl.common.dict;

import java.util.List;
import java.util.Map;

import com.gnt.qxgl.bean.SysCode;


public class LocationDictServiceTest1 implements LocationDictService{
	public Map<String, Map<String, List<SysCode>>> loadDict() {
		// TODO Auto-generated method stub
		return null;
	}
}
