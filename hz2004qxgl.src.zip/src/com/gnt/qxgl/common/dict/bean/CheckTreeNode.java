package com.gnt.qxgl.common.dict.bean;

public class CheckTreeNode extends TreeNode{
	private Boolean checked;

	public Boolean getChecked() {
	    return checked;
	}

	public void setChecked(Boolean checked) {
	    this.checked = checked;
	}
	
}
