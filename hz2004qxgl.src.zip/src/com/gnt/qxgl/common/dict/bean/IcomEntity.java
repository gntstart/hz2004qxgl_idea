package com.gnt.qxgl.common.dict.bean;

/**
 * 
 * @author 所有实体实现的基本接口，保留。
 *
 */
public interface IcomEntity {
	/**
	 * 克隆POJO对象。
	 * @return
	 */
	public Object getClone();
}
