package com.gnt.qxgl.common.dict.bean;

import com.gnt.qxgl.hz2004.entity.XtDwxxb;

public class SysOrganizeInfo extends XtDwxxb{
	private static final long serialVersionUID = 1L;
	
	public String ccm;

	public String getCcm() {
		return ccm;
	}

	public void setCcm(String ccm) {
		this.ccm = ccm;
	}
}
