package  com.hzjc.hz2004.po;

public class PoLSSFZ_SLLSB implements com.hzjc.wsstruts.po.PO
{
  private Long lssllsbid;
  private Long lsslid;
  private Long ryid;
  private String bgqkh;
  private String bghkh;
  private Long czyid;
  private String czsj;
  private String czyip;

  public void setLssllsbid(Long lssllsbid) {
    this.lssllsbid = lssllsbid;
  }

  public Long getLssllsbid() {
    return lssllsbid;
  }

  public void setLsslid(Long lsslid) {
    this.lsslid = lsslid;
  }

  public Long getLsslid() {
    return lsslid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setBgqkh(String bgqkh) {
    this.bgqkh = bgqkh;
  }

  public String getBgqkh() {
    return bgqkh;
  }

  public void setBghkh(String bghkh) {
    this.bghkh = bghkh;
  }

  public String getBghkh() {
    return bghkh;
  }

  public void setCzyid(Long czyid) {
    this.czyid = czyid;
  }

  public Long getCzyid() {
    return czyid;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

  public void setCzyip(String czyip) {
    this.czyip = czyip;
  }

  public String getCzyip() {
    return czyip;
  }

}
