package  com.hzjc.hz2004.po;

public class PoXT_XTGNB implements com.hzjc.wsstruts.po.PO
{
  private Long gnid;
  private String gnbh;
  private String gnmc;
  private String gnlx;
  private String qybz;

  public void setGnid(Long gnid) {
    this.gnid = gnid;
  }

  public Long getGnid() {
    return gnid;
  }

  public void setGnbh(String gnbh) {
    this.gnbh = gnbh;
  }

  public String getGnbh() {
    return gnbh;
  }

  public void setGnmc(String gnmc) {
    this.gnmc = gnmc;
  }

  public String getGnmc() {
    return gnmc;
  }

  public void setGnlx(String gnlx) {
    this.gnlx = gnlx;
  }

  public String getGnlx() {
    return gnlx;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

}
