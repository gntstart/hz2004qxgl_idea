package  com.hzjc.hz2004.po;

public class PoWW_FJJGRZB implements com.hzjc.wsstruts.po.PO
{
  private Long fjjgid;
  private String slh;
  private String slzt;
  private String xm;
  private String gmsfhm;
  private String yxqxqsrq;
  private String yxqxjzrq;
  private String czsj;
  private Long czrid;
  private String czrip;
  private String czrdw;
  private String bz;

  private String fjpch;
  private Long cwh;
  private String cwhdypcs;
  private Long mlpnbid;
  private String ssxq;
  private String jlx;
  private String mlph;
  private String mlxz;
  private String pcs;
  private String zrq;
  private String xzjd;
  private String jcwh;
  private String pxh;
  private Long ryid;
  private Long rynbid;
  private String jlbz;//��¼��־

  public void setFjjgid(Long fjjgid) {
    this.fjjgid = fjjgid;
  }

  public Long getFjjgid() {
    return fjjgid;
  }

  public void setSlh(String slh) {
    this.slh = slh;
  }

  public String getSlh() {
    return slh;
  }

  public void setSlzt(String slzt) {
    this.slzt = slzt;
  }

  public String getSlzt() {
    return slzt;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setYxqxqsrq(String yxqxqsrq) {
    this.yxqxqsrq = yxqxqsrq;
  }

  public String getYxqxqsrq() {
    return yxqxqsrq;
  }

  public void setYxqxjzrq(String yxqxjzrq) {
    this.yxqxjzrq = yxqxjzrq;
  }

  public String getYxqxjzrq() {
    return yxqxjzrq;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

  public void setCzrid(Long czrid) {
    this.czrid = czrid;
  }

  public Long getCzrid() {
    return czrid;
  }

  public void setCzrip(String czrip) {
    this.czrip = czrip;
  }

  public String getCzrip() {
    return czrip;
  }

  public void setCzrdw(String czrdw) {
    this.czrdw = czrdw;
  }

  public String getCzrdw() {
    return czrdw;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setFjpch(String fjpch) {
    this.fjpch = fjpch;
  }

  public String getFjpch() {
    return fjpch;
  }

  public void setCwh(Long cwh) {
    this.cwh = cwh;
  }

  public Long getCwh() {
    return cwh;
  }

  public void setCwhdypcs(String cwhdypcs) {
    this.cwhdypcs = cwhdypcs;
  }

  public String getCwhdypcs() {
    return cwhdypcs;
  }

  public void setMlpnbid(Long mlpnbid) {
    this.mlpnbid = mlpnbid;
  }

  public Long getMlpnbid() {
    return mlpnbid;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public String getJlx() {
    return jlx;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public String getMlph() {
    return mlph;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public String getMlxz() {
    return mlxz;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public String getPcs() {
    return pcs;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public String getZrq() {
    return zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public String getXzjd() {
    return xzjd;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

  public void setPxh(String pxh) {
    this.pxh = pxh;
  }

  public String getPxh() {
    return pxh;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setJlbz(String jlbz) {
    this.jlbz = jlbz;
  }

  public String getJlbz() {
    return jlbz;
  }

}
