package  com.hzjc.hz2004.po;

public class PoRPT_TJBBSJB implements com.hzjc.wsstruts.po.PO
{
  private Long tjbbid;
  private String jcwh;
  private String tjny;
  private Long hs;
  private Long rs_nan;
  private Long rs_nv;
  private Long fnyrks;
  private Long wlczrs;
  private Long ysbsyxrs;
  private Long ysbdsswsrs;
  private Long sswdlssrs;
  private Long lssysrs;
  private Long nldyybrs_nan;
  private Long nldyybrs_nv;
  private String czsj;
  private Long czyid;
  private String czyip;

  public void setTjbbid(Long tjbbid) {
    this.tjbbid = tjbbid;
  }

  public Long getTjbbid() {
    return tjbbid;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

  public void setTjny(String tjny) {
    this.tjny = tjny;
  }

  public String getTjny() {
    return tjny;
  }

  public void setHs(Long hs) {
    this.hs = hs;
  }

  public Long getHs() {
    return hs;
  }

  public void setRs_nan(Long rs_nan) {
    this.rs_nan = rs_nan;
  }

  public Long getRs_nan() {
    return rs_nan;
  }

  public void setRs_nv(Long rs_nv) {
    this.rs_nv = rs_nv;
  }

  public Long getRs_nv() {
    return rs_nv;
  }

  public void setFnyrks(Long fnyrks) {
    this.fnyrks = fnyrks;
  }

  public Long getFnyrks() {
    return fnyrks;
  }

  public void setWlczrs(Long wlczrs) {
    this.wlczrs = wlczrs;
  }

  public Long getWlczrs() {
    return wlczrs;
  }

  public void setYsbsyxrs(Long ysbsyxrs) {
    this.ysbsyxrs = ysbsyxrs;
  }

  public Long getYsbsyxrs() {
    return ysbsyxrs;
  }

  public void setYsbdsswsrs(Long ysbdsswsrs) {
    this.ysbdsswsrs = ysbdsswsrs;
  }

  public Long getYsbdsswsrs() {
    return ysbdsswsrs;
  }

  public void setSswdlssrs(Long sswdlssrs) {
    this.sswdlssrs = sswdlssrs;
  }

  public Long getSswdlssrs() {
    return sswdlssrs;
  }

  public void setLssysrs(Long lssysrs) {
    this.lssysrs = lssysrs;
  }

  public Long getLssysrs() {
    return lssysrs;
  }

  public void setNldyybrs_nan(Long nldyybrs_nan) {
    this.nldyybrs_nan = nldyybrs_nan;
  }

  public Long getNldyybrs_nan() {
    return nldyybrs_nan;
  }

  public void setNldyybrs_nv(Long nldyybrs_nv) {
    this.nldyybrs_nv = nldyybrs_nv;
  }

  public Long getNldyybrs_nv() {
    return nldyybrs_nv;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

  public void setCzyid(Long czyid) {
    this.czyid = czyid;
  }

  public Long getCzyid() {
    return czyid;
  }

  public void setCzyip(String czyip) {
    this.czyip = czyip;
  }

  public String getCzyip() {
    return czyip;
  }

}
