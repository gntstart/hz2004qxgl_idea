package  com.hzjc.hz2004.po;

public class PoXT_YHHHXXB implements com.hzjc.wsstruts.po.PO
{
  private Long yhhhid;
  private Long yhid;
  private String hhid;
  private String yhip;
  private String khdbb;

  public void setYhhhid(Long yhhhid) {
    this.yhhhid = yhhhid;
  }

  public Long getYhhhid() {
    return yhhhid;
  }



  public void setYhid(Long yhid) {
    this.yhid = yhid;
  }

  public Long getYhid() {
    return yhid;
  }
  public String getHhid() {
    return hhid;
  }
  public void setHhid(String hhid) {
    this.hhid = hhid;
  }
  public String getYhip() {
    return yhip;
  }
  public void setYhip(String yhip) {
    this.yhip = yhip;
  }
  public String getKhdbb() {
    return khdbb;
  }
  public void setKhdbb(String khdbb) {
    this.khdbb = khdbb;
  }

}
