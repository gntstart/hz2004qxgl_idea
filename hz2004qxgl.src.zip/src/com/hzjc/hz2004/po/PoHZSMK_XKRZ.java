package com.hzjc.hz2004.po;

public class PoHZSMK_XKRZ
    implements com.hzjc.wsstruts.po.PO {

  private Long xkrzid;  //д����־ID
  private Long rynbid;  //��Ա�ڲ�ID
  private Long ryid;  //��ԱID
  private String gmsfhm;  //�������ݺ���
  private String xm;  //����
  private String xb;  //�Ա�
  private String mz;  //����
  private String csrq;  //��������
  private String csdssxq;  //������ʡ������
  private String dhhm;  //�绰����
  private String whcd;  //�Ļ��̶�
  private String hyzk;  //����״��
  private String sg;  //����
  private String xx;  //Ѫ��
  private String zy;  //ְҵ
  private String hb;  //����
  private String yhzgx;  //�뻧����ϵ
  private String ssxq;  //ʡ������
  private String jlx;  //��·��
  private String mlph;  //��¥�ƺ�
  private String mlxz;  //��¥��ַ
  private String pcs;  //�ɳ���
  private String zrq;  //������
  private String xzjd;  //����ֵ�
  private String jcwh;  //�Ӵ�ί��
  private String hh;  //����
  private String szcsdm;  //���ڳ��д���
  private String czhkszd;  //��ס�������ڵ�
  private String xgqhb;  //�޸�ǰ����
  private String xgqczhkszd;  //�޸�ǰ��ס������סַ
  private String xgqmz;  //�޸�ǰ����
  private String xgqcsd;  //�޸�ǰ������
  private String xgqcsdm;  //�޸�ǰ���д���
  private String kntxdz;  //����ͨѶ��ַ
  private String knyzbm;  //������������
  private String knlxdh;  //������ϵ�绰
  private String knhyzk;  //���ڻ���״��
  private String knwhcd;  //�����Ļ��̶�
  private String kdsbm;  //����ʶ����
  private String fkrq;  //��������
  private String kyxq;  //����Ч��
  private Long xgrid;  //�޸���
  private String xgjqip;  //�޸Ļ���IP
  private String xgsj;  //�޸�ʱ��

  public void setXkrzid(Long xkrzid) {
    this.xkrzid = xkrzid;
  }

  public Long getXkrzid() {
    return xkrzid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public String getXb() {
    return xb;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public String getMz() {
    return mz;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public String getCsrq() {
    return csrq;
  }

  public void setCsdssxq(String csdssxq) {
    this.csdssxq = csdssxq;
  }

  public String getCsdssxq() {
    return csdssxq;
  }

  public void setDhhm(String dhhm) {
    this.dhhm = dhhm;
  }

  public String getDhhm() {
    return dhhm;
  }

  public void setWhcd(String whcd) {
    this.whcd = whcd;
  }

  public String getWhcd() {
    return whcd;
  }

  public void setHyzk(String hyzk) {
    this.hyzk = hyzk;
  }

  public String getHyzk() {
    return hyzk;
  }

  public void setSg(String sg) {
    this.sg = sg;
  }

  public String getSg() {
    return sg;
  }

  public void setXx(String xx) {
    this.xx = xx;
  }

  public String getXx() {
    return xx;
  }

  public void setZy(String zy) {
    this.zy = zy;
  }

  public String getZy() {
    return zy;
  }

  public void setHb(String hb) {
    this.hb = hb;
  }

  public String getHb() {
    return hb;
  }

  public void setYhzgx(String yhzgx) {
    this.yhzgx = yhzgx;
  }

  public String getYhzgx() {
    return yhzgx;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public String getJlx() {
    return jlx;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public String getMlph() {
    return mlph;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public String getMlxz() {
    return mlxz;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public String getPcs() {
    return pcs;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public String getZrq() {
    return zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public String getXzjd() {
    return xzjd;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

  public void setHh(String hh) {
    this.hh = hh;
  }

  public String getHh() {
    return hh;
  }

  public void setSzcsdm(String szcsdm) {
    this.szcsdm = szcsdm;
  }

  public String getSzcsdm() {
    return szcsdm;
  }

  public void setCzhkszd(String czhkszd) {
    this.czhkszd = czhkszd;
  }

  public String getCzhkszd() {
    return czhkszd;
  }

  public void setXgqhb(String xgqhb) {
    this.xgqhb = xgqhb;
  }

  public String getXgqhb() {
    return xgqhb;
  }

  public void setXgqczhkszd(String xgqczhkszd) {
    this.xgqczhkszd = xgqczhkszd;
  }

  public String getXgqczhkszd() {
    return xgqczhkszd;
  }

  public void setXgqmz(String xgqmz) {
    this.xgqmz = xgqmz;
  }

  public String getXgqmz() {
    return xgqmz;
  }

  public void setXgqcsd(String xgqcsd) {
    this.xgqcsd = xgqcsd;
  }

  public String getXgqcsd() {
    return xgqcsd;
  }

  public void setXgqcsdm(String xgqcsdm) {
    this.xgqcsdm = xgqcsdm;
  }

  public String getXgqcsdm() {
    return xgqcsdm;
  }

  public void setKntxdz(String kntxdz) {
    this.kntxdz = kntxdz;
  }

  public String getKntxdz() {
    return kntxdz;
  }

  public void setKnyzbm(String knyzbm) {
    this.knyzbm = knyzbm;
  }

  public String getKnyzbm() {
    return knyzbm;
  }

  public void setKnlxdh(String knlxdh) {
    this.knlxdh = knlxdh;
  }

  public String getKnlxdh() {
    return knlxdh;
  }

  public void setKnhyzk(String knhyzk) {
    this.knhyzk = knhyzk;
  }

  public String getKnhyzk() {
    return knhyzk;
  }

  public void setKnwhcd(String knwhcd) {
    this.knwhcd = knwhcd;
  }

  public String getKnwhcd() {
    return knwhcd;
  }

  public void setKdsbm(String kdsbm) {
    this.kdsbm = kdsbm;
  }

  public String getKdsbm() {
    return kdsbm;
  }

  public void setFkrq(String fkrq) {
    this.fkrq = fkrq;
  }

  public String getFkrq() {
    return fkrq;
  }

  public void setKyxq(String kyxq) {
    this.kyxq = kyxq;
  }

  public String getKyxq() {
    return kyxq;
  }

  public void setXgrid(Long xgrid) {
    this.xgrid = xgrid;
  }

  public Long getXgrid() {
    return xgrid;
  }

  public void setXgjqip(String xgjqip) {
    this.xgjqip = xgjqip;
  }

  public String getXgjqip() {
    return xgjqip;
  }

  public void setXgsj(String xgsj) {
    this.xgsj = xgsj;
  }

  public String getXgsj() {
    return xgsj;
  }


}
