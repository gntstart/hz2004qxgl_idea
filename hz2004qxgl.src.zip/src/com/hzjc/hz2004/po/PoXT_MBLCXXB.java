package  com.hzjc.hz2004.po;

public class PoXT_MBLCXXB implements com.hzjc.wsstruts.po.PO
{
  private Long mblcid;
  private Long spmbid;
  private Long dzid;
  private String dzz;
  private Long xgdzid;
  private String dzbz;

  public void setMblcid(Long mblcid) {
    this.mblcid = mblcid;
  }

  public Long getMblcid() {
    return mblcid;
  }

  public void setSpmbid(Long spmbid) {
    this.spmbid = spmbid;
  }

  public Long getSpmbid() {
    return spmbid;
  }

  public void setDzid(Long dzid) {
    this.dzid = dzid;
  }

  public Long getDzid() {
    return dzid;
  }

  public void setDzz(String dzz) {
    this.dzz = dzz;
  }

  public String getDzz() {
    return dzz;
  }

  public void setXgdzid(Long xgdzid) {
    this.xgdzid = xgdzid;
  }

  public Long getXgdzid() {
    return xgdzid;
  }

  public void setDzbz(String dzbz) {
    this.dzbz = dzbz;
  }

  public String getDzbz() {
    return dzbz;
  }

}
