package  com.hzjc.hz2004.po;

public class PoWW_JKCSB implements com.hzjc.wsstruts.po.PO
{
  private Long csid;
  private String jklb;
  private String jklmc;
  private String jkcs;
  private String jglx;
  private String cjsj;
  private String qybz;
  private String bz;
  private String jklbmc;

  public void setCsid(Long csid) {
    this.csid = csid;
  }

  public Long getCsid() {
    return csid;
  }

  public void setJklb(String jklb) {
    this.jklb = jklb;
  }

  public String getJklb() {
    return jklb;
  }

  public void setJklmc(String jklmc) {
    this.jklmc = jklmc;
  }

  public String getJklmc() {
    return jklmc;
  }

  public void setJkcs(String jkcs) {
    this.jkcs = jkcs;
  }

  public String getJkcs() {
    return jkcs;
  }

  public void setJglx(String jglx) {
    this.jglx = jglx;
  }

  public String getJglx() {
    return jglx;
  }

  public void setCjsj(String cjsj) {
    this.cjsj = cjsj;
  }

  public String getCjsj() {
    return cjsj;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }
  public String getJklbmc() {
    return jklbmc;
  }
  public void setJklbmc(String jklbmc) {
    this.jklbmc = jklbmc;
  }

}
