package  com.hzjc.hz2004.po;

public class PoXT_YHJSXXB implements com.hzjc.wsstruts.po.PO
{
  private Long yhjsid;
  private Long yhid;
  private Long jsid;

  public void setYhjsid(Long yhjsid) {
    this.yhjsid = yhjsid;
  }

  public Long getYhjsid() {
    return yhjsid;
  }

  public void setYhid(Long yhid) {
    this.yhid = yhid;
  }

  public Long getYhid() {
    return yhid;
  }

  public void setJsid(Long jsid) {
    this.jsid = jsid;
  }

  public Long getJsid() {
    return jsid;
  }

}
