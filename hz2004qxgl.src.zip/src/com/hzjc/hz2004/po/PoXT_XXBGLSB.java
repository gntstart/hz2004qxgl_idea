package  com.hzjc.hz2004.po;

public class PoXT_XXBGLSB implements com.hzjc.wsstruts.po.PO
{
  private Long xxbgid;
  private String bgbm;
  private Long bgid;
  private Long yczrid;
  private String bgrq;
  private Long bgrid;
  private String bgxm;
  private String bgqnr;
  private String bghnr;

  public void setXxbgid(Long xxbgid) {
    this.xxbgid = xxbgid;
  }

  public Long getXxbgid() {
    return xxbgid;
  }

  public void setBgbm(String bgbm) {
    this.bgbm = bgbm;
  }

  public String getBgbm() {
    return bgbm;
  }

  public void setBgid(Long bgid) {
    this.bgid = bgid;
  }

  public Long getBgid() {
    return bgid;
  }

  public void setYczrid(Long yczrid) {
    this.yczrid = yczrid;
  }

  public Long getYczrid() {
    return yczrid;
  }

  public void setBgrq(String bgrq) {
    this.bgrq = bgrq;
  }

  public String getBgrq() {
    return bgrq;
  }

  public void setBgrid(Long bgrid) {
    this.bgrid = bgrid;
  }

  public Long getBgrid() {
    return bgrid;
  }

  public void setBgxm(String bgxm) {
    this.bgxm = bgxm;
  }

  public String getBgxm() {
    return bgxm;
  }

  public void setBgqnr(String bgqnr) {
    this.bgqnr = bgqnr;
  }

  public String getBgqnr() {
    return bgqnr;
  }

  public void setBghnr(String bghnr) {
    this.bghnr = bghnr;
  }

  public String getBghnr() {
    return bghnr;
  }

}
