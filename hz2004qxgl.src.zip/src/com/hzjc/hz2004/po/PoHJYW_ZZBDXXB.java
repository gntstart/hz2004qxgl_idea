package com.hzjc.hz2004.po;

public class PoHJYW_ZZBDXXB
    implements com.hzjc.wsstruts.po.PO {
  private Long zzbdid;
  private Long rynbid;
  private Long yhhnbid;
  private Long yhhid;
  private String zzbdlb;
  private String zzbdrq;
  private String qyzbh;
  private String bdfw;
  private Long hjywid;
  private String cxbz;
  private String cxsj;
  private Long cxrid;
  private Long cxhjywid;

  private String sbsj;
  private String sbryxm;
  private String sbrgmsfhm;
  private String slsj;
  private String sldw;
  private Long slrid;

  private String xm;
  private String mz;
  private String xb;
  private String csrq;
  private String cssj;
  private String csdssxq;
  private String gmsfhm;
  private String hh;
  private String hlx;
  private String hb;
  private String hh_q;
  private String hlx_q;
  private String hb_q;
  private String ssxq_q;
  private String jlx_q;
  private String mlph_q;
  private String mlxz_q;
  private String pcs_q;
  private String zrq_q;
  private String xzjd_q;
  private String jcwh_q;
  private String pxh_q;
  private String jdlb_q;
  private String cdlb_q;
  private String ssxq;
  private String jlx;
  private String mlph;
  private String mlxz;
  private String pcs;
  private String zrq;
  private String xzjd;
  private String jcwh;
  private String pxh;
  private String jdlb;
  private String cdlb;
  private Long ryid;
  private Long hhnbid;
  private Long hhid;
  private Long nbsfzid;
  private Long mlpnbid;
  private Long mlpid;
  private Long mlpnbid_q;
  private Long mlpid_q;

  private String yhzgx;
  private String hzxm;
  private String hzgmsfhm;
  private String ywlx;
  private Long czsm;

  private String sbrjtgx;
  private String cxfldm;
  private String nyzyrklhczyydm;
  private String cxsxtz_pdbz;
  private String jjqx_pdbz;
  private String zczjyhjzwnys_pdbz;

  public void setZzbdid(Long zzbdid) {
    this.zzbdid = zzbdid;
  }

  public Long getZzbdid() {
    return zzbdid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setYhhnbid(Long yhhnbid) {
    this.yhhnbid = yhhnbid;
  }

  public Long getYhhnbid() {
    return yhhnbid;
  }

  public void setZzbdlb(String zzbdlb) {
    this.zzbdlb = zzbdlb;
  }

  public String getZzbdlb() {
    return zzbdlb;
  }

  public void setZzbdrq(String zzbdrq) {
    this.zzbdrq = zzbdrq;
  }

  public String getZzbdrq() {
    return zzbdrq;
  }

  public void setQyzbh(String qyzbh) {
    this.qyzbh = qyzbh;
  }

  public String getQyzbh() {
    return qyzbh;
  }

  public void setBdfw(String bdfw) {
    this.bdfw = bdfw;
  }

  public String getBdfw() {
    return bdfw;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public void setCxbz(String cxbz) {
    this.cxbz = cxbz;
  }

  public String getCxbz() {
    return cxbz;
  }

  public void setCxsj(String cxsj) {
    this.cxsj = cxsj;
  }

  public String getCxsj() {
    return cxsj;
  }

  public void setCxrid(Long cxrid) {
    this.cxrid = cxrid;
  }

  public Long getCxrid() {
    return cxrid;
  }

  public void setCxhjywid(Long cxhjywid) {
    this.cxhjywid = cxhjywid;
  }

  public Long getCxhjywid() {
    return cxhjywid;
  }

  public String getSbrgmsfhm() {
    return sbrgmsfhm;
  }

  public void setSbrgmsfhm(String sbrgmsfhm) {
    this.sbrgmsfhm = sbrgmsfhm;
  }

  public String getSbryxm() {
    return sbryxm;
  }

  public void setSbryxm(String sbryxm) {
    this.sbryxm = sbryxm;
  }

  public String getSbsj() {
    return sbsj;
  }

  public void setSbsj(String sbsj) {
    this.sbsj = sbsj;
  }

  public String getSldw() {
    return sldw;
  }

  public void setSldw(String sldw) {
    this.sldw = sldw;
  }

  public Long getSlrid() {
    return slrid;
  }

  public void setSlrid(Long slrid) {
    this.slrid = slrid;
  }

  public String getSlsj() {
    return slsj;
  }

  public void setSlsj(String slsj) {
    this.slsj = slsj;
  }

  public String getCdlb() {
    return cdlb;
  }

  public String getCdlb_q() {
    return cdlb_q;
  }

  public String getCsdssxq() {
    return csdssxq;
  }

  public String getCssj() {
    return cssj;
  }

  public String getCsrq() {
    return csrq;
  }

  public void setCssj(String cssj) {
    this.cssj = cssj;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public void setCsdssxq(String csdssxq) {
    this.csdssxq = csdssxq;
  }

  public void setCdlb_q(String cdlb_q) {
    this.cdlb_q = cdlb_q;
  }

  public void setCdlb(String cdlb) {
    this.cdlb = cdlb;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public String getHb() {
    return hb;
  }

  public String getHb_q() {
    return hb_q;
  }

  public String getHh() {
    return hh;
  }

  public String getHh_q() {
    return hh_q;
  }

  public void setHh_q(String hh_q) {
    this.hh_q = hh_q;
  }

  public void setHh(String hh) {
    this.hh = hh;
  }

  public void setHb_q(String hb_q) {
    this.hb_q = hb_q;
  }

  public void setHb(String hb) {
    this.hb = hb;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getHlx() {
    return hlx;
  }

  public String getHlx_q() {
    return hlx_q;
  }

  public String getJcwh() {
    return jcwh;
  }

  public String getJcwh_q() {
    return jcwh_q;
  }

  public String getJdlb() {
    return jdlb;
  }

  public String getJdlb_q() {
    return jdlb_q;
  }

  public String getJlx() {
    return jlx;
  }

  public String getMlph() {
    return mlph;
  }

  public String getMlph_q() {
    return mlph_q;
  }

  public String getMlxz_q() {
    return mlxz_q;
  }

  public String getMlxz() {
    return mlxz;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public void setMlxz_q(String mlxz_q) {
    this.mlxz_q = mlxz_q;
  }

  public void setMlph_q(String mlph_q) {
    this.mlph_q = mlph_q;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public void setJlx_q(String jlx_q) {
    this.jlx_q = jlx_q;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public void setJdlb_q(String jdlb_q) {
    this.jdlb_q = jdlb_q;
  }

  public void setJdlb(String jdlb) {
    this.jdlb = jdlb;
  }

  public void setJcwh_q(String jcwh_q) {
    this.jcwh_q = jcwh_q;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public void setHlx_q(String hlx_q) {
    this.hlx_q = hlx_q;
  }

  public void setHlx(String hlx) {
    this.hlx = hlx;
  }

  public String getMz() {
    return mz;
  }

  public String getPcs() {
    return pcs;
  }

  public String getPcs_q() {
    return pcs_q;
  }

  public String getPxh() {
    return pxh;
  }

  public String getPxh_q() {
    return pxh_q;
  }

  public void setPxh_q(String pxh_q) {
    this.pxh_q = pxh_q;
  }

  public void setPxh(String pxh) {
    this.pxh = pxh;
  }

  public void setPcs_q(String pcs_q) {
    this.pcs_q = pcs_q;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public String getSsxq() {
    return ssxq;
  }

  public String getSsxq_q() {
    return ssxq_q;
  }

  public String getXb() {
    return xb;
  }

  public String getXm() {
    return xm;
  }

  public String getXzjd() {
    return xzjd;
  }

  public String getXzjd_q() {
    return xzjd_q;
  }

  public void setXzjd_q(String xzjd_q) {
    this.xzjd_q = xzjd_q;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public void setSsxq_q(String ssxq_q) {
    this.ssxq_q = ssxq_q;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getZrq() {
    return zrq;
  }

  public String getZrq_q() {
    return zrq_q;
  }

  public void setZrq_q(String zrq_q) {
    this.zrq_q = zrq_q;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public Long getHhnbid() {
    return hhnbid;
  }

  public void setHhnbid(Long hhnbid) {
    this.hhnbid = hhnbid;
  }

  public String getJlx_q() {
    return jlx_q;
  }

  public Long getMlpnbid() {
    return mlpnbid;
  }

  public void setMlpnbid(Long mlpnbid) {
    this.mlpnbid = mlpnbid;
  }

  public Long getMlpnbid_q() {
    return mlpnbid_q;
  }

  public void setMlpnbid_q(Long mlpnbid_q) {
    this.mlpnbid_q = mlpnbid_q;
  }

  public Long getNbsfzid() {
    return nbsfzid;
  }

  public void setNbsfzid(Long nbsfzid) {
    this.nbsfzid = nbsfzid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getCzsm() {
    return czsm;
  }

  public void setCzsm(Long czsm) {
    this.czsm = czsm;
  }

  public void setHzgmsfhm(String hzgmsfhm) {
    this.hzgmsfhm = hzgmsfhm;
  }

  public String getHzgmsfhm() {
    return hzgmsfhm;
  }

  public String getHzxm() {
    return hzxm;
  }

  public void setHzxm(String hzxm) {
    this.hzxm = hzxm;
  }

  public String getYhzgx() {
    return yhzgx;
  }

  public void setYhzgx(String yhzgx) {
    this.yhzgx = yhzgx;
  }

  public String getYwlx() {
    return ywlx;
  }

  public void setYwlx(String ywlx) {
    this.ywlx = ywlx;
  }

  public Long getHhid() {
    return hhid;
  }

  public void setHhid(Long hhid) {
    this.hhid = hhid;
  }

  public Long getMlpid() {
    return mlpid;
  }

  public void setMlpid(Long mlpid) {
    this.mlpid = mlpid;
  }

  public Long getMlpid_q() {
    return mlpid_q;
  }

  public void setMlpid_q(Long mlpid_q) {
    this.mlpid_q = mlpid_q;
  }

  public Long getYhhid() {
    return yhhid;
  }

  public void setYhhid(Long yhhid) {
    this.yhhid = yhhid;
  }

  public String getSbrjtgx() {
    return sbrjtgx;
  }

  public String getCxfldm() {
    return cxfldm;
  }

  public String getCxsxtz_pdbz() {
    return cxsxtz_pdbz;
  }

  public String getJjqx_pdbz() {
    return jjqx_pdbz;
  }

  public String getNyzyrklhczyydm() {
    return nyzyrklhczyydm;
  }

  public String getZczjyhjzwnys_pdbz() {
    return zczjyhjzwnys_pdbz;
  }

  public void setSbrjtgx(String sbrjtgx) {
    this.sbrjtgx = sbrjtgx;
   }

  public void setCxfldm(String cxfldm) {
    this.cxfldm = cxfldm;
  }

  public void setCxsxtz_pdbz(String cxsxtz_pdbz) {
    this.cxsxtz_pdbz = cxsxtz_pdbz;
  }

  public void setJjqx_pdbz(String jjqx_pdbz) {
    this.jjqx_pdbz = jjqx_pdbz;
  }

  public void setNyzyrklhczyydm(String nyzyrklhczyydm) {
    this.nyzyrklhczyydm = nyzyrklhczyydm;
  }

  public void setZczjyhjzwnys_pdbz(String zczjyhjzwnys_pdbz) {
    this.zczjyhjzwnys_pdbz = zczjyhjzwnys_pdbz;
  }

}
