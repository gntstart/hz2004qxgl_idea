package  com.hzjc.hz2004.po;

public class PoWW_TFBDJGXXB implements com.hzjc.wsstruts.po.PO
{
  private Long bdid;
  private String pptj;
  private String bdyj;
  private String czsj;
  private Long czrid;
  private String czrip;
  private String czrdw;
  private String czrxm;
  private String czrdlm;
  private String bdywbh;
  private Long shrid;
  private String shsj;
  private String cljg;
  private String clsm;
  private Long clrid;
  private String clsj;
  private String clrip;
  private String ssxq;
  private String jlx;
  private String mlph;
  private String mlxz;
  private String pcs;
  private String zrq;
  private String xzjd;
  private String jcwh;
  private Long rynbid;
  private String xm;
  private String gmsfhm;
  private String jlbz;

  private String bdywmc;//�ȶ�ҵ������

  public void setBdid(Long bdid) {
    this.bdid = bdid;
  }

  public Long getBdid() {
    return bdid;
  }

  public void setPptj(String pptj) {
    this.pptj = pptj;
  }

  public String getPptj() {
    return pptj;
  }

  public void setBdyj(String bdyj) {
    this.bdyj = bdyj;
  }

  public String getBdyj() {
    return bdyj;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

  public void setCzrid(Long czrid) {
    this.czrid = czrid;
  }

  public Long getCzrid() {
    return czrid;
  }

  public void setCzrip(String czrip) {
    this.czrip = czrip;
  }

  public String getCzrip() {
    return czrip;
  }

  public void setCzrdw(String czrdw) {
    this.czrdw = czrdw;
  }

  public String getCzrdw() {
    return czrdw;
  }

  public void setCzrxm(String czrxm) {
    this.czrxm = czrxm;
  }

  public String getCzrxm() {
    return czrxm;
  }

  public void setCzrdlm(String czrdlm) {
    this.czrdlm = czrdlm;
  }

  public String getCzrdlm() {
    return czrdlm;
  }

  public void setBdywbh(String bdywbh) {
    this.bdywbh = bdywbh;
  }

  public String getBdywbh() {
    return bdywbh;
  }

  public void setShrid(Long shrid) {
    this.shrid = shrid;
  }

  public Long getShrid() {
    return shrid;
  }

  public void setShsj(String shsj) {
    this.shsj = shsj;
  }

  public String getShsj() {
    return shsj;
  }

  public void setCljg(String cljg) {
    this.cljg = cljg;
  }

  public String getCljg() {
    return cljg;
  }

  public void setClsm(String clsm) {
    this.clsm = clsm;
  }

  public String getClsm() {
    return clsm;
  }

  public void setClrid(Long clrid) {
    this.clrid = clrid;
  }

  public Long getClrid() {
    return clrid;
  }

  public void setClsj(String clsj) {
    this.clsj = clsj;
  }

  public String getClsj() {
    return clsj;
  }

  public void setClrip(String clrip) {
    this.clrip = clrip;
  }

  public String getClrip() {
    return clrip;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public String getJlx() {
    return jlx;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public String getMlph() {
    return mlph;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public String getMlxz() {
    return mlxz;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public String getPcs() {
    return pcs;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public String getZrq() {
    return zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public String getXzjd() {
    return xzjd;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setJlbz(String jlbz) {
    this.jlbz = jlbz;
  }

  public String getJlbz() {
    return jlbz;
  }

  public void setBdywmc(String bdywmc) {
    this.bdywmc = bdywmc;
  }

  public String getBdywmc() {
    return bdywmc;
  }

}
