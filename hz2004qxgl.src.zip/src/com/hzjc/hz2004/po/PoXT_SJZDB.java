package  com.hzjc.hz2004.po;

public class PoXT_SJZDB implements com.hzjc.wsstruts.po.PO
{
  private Long zdid;
  private String zdmc;
  private String zdhy;
  private String zdlx;
  private String zdcd;
  private String zdmj;
  private String bdlx;
  private String bdsj;

  public void setZdid(Long zdid) {
    this.zdid = zdid;
  }

  public Long getZdid() {
    return zdid;
  }

  public void setZdmc(String zdmc) {
    this.zdmc = zdmc;
  }

  public String getZdmc() {
    return zdmc;
  }

  public void setZdhy(String zdhy) {
    this.zdhy = zdhy;
  }

  public String getZdhy() {
    return zdhy;
  }

  public void setZdlx(String zdlx) {
    this.zdlx = zdlx;
  }

  public String getZdlx() {
    return zdlx;
  }

  public void setZdcd(String zdcd) {
    this.zdcd = zdcd;
  }

  public String getZdcd() {
    return zdcd;
  }

  public void setZdmj(String zdmj) {
    this.zdmj = zdmj;
  }

  public String getZdmj() {
    return zdmj;
  }

  public void setBdlx(String bdlx) {
    this.bdlx = bdlx;
  }

  public String getBdlx() {
    return bdlx;
  }

  public void setBdsj(String bdsj) {
    this.bdsj = bdsj;
  }

  public String getBdsj() {
    return bdsj;
  }

}
