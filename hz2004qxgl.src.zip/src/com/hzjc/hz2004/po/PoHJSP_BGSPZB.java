package  com.hzjc.hz2004.po;

public class PoHJSP_BGSPZB implements com.hzjc.wsstruts.po.PO
{
  private Long bgzid;
  private Long spywid;
  private String bggzxm;
  private String bgqnr;
  private String bghnr;
  private String bglb;
  private String bgrq;

  public void setBgzid(Long bgzid) {
    this.bgzid = bgzid;
  }

  public Long getBgzid() {
    return bgzid;
  }

  public void setSpywid(Long spywid) {
    this.spywid = spywid;
  }

  public Long getSpywid() {
    return spywid;
  }

  public void setBggzxm(String bggzxm) {
    this.bggzxm = bggzxm;
  }

  public String getBggzxm() {
    return bggzxm;
  }

  public void setBgqnr(String bgqnr) {
    this.bgqnr = bgqnr;
  }

  public String getBgqnr() {
    return bgqnr;
  }

  public void setBghnr(String bghnr) {
    this.bghnr = bghnr;
  }

  public String getBghnr() {
    return bghnr;
  }

  public void setBglb(String bglb) {
    this.bglb = bglb;
  }

  public String getBglb() {
    return bglb;
  }

  public void setBgrq(String bgrq) {
    this.bgrq = bgrq;
  }

  public String getBgrq() {
    return bgrq;
  }

}
