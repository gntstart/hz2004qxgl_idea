package  com.hzjc.hz2004.po;

public class PoWW_TFBDJKXXB implements com.hzjc.wsstruts.po.PO
{
  private Long jkid;
  private String jkjndi;
  private String cxyj;
  private String qybz;
  private String cjsj;
  private String bz;
  private String fhts;

  public void setJkid(Long jkid) {
    this.jkid = jkid;
  }

  public Long getJkid() {
    return jkid;
  }

  public void setJkjndi(String jkjndi) {
    this.jkjndi = jkjndi;
  }

  public String getJkjndi() {
    return jkjndi;
  }



  public void setCxyj(String cxyj) {
    this.cxyj = cxyj;
  }

  public String getCxyj() {
    return cxyj;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

  public void setCjsj(String cjsj) {
    this.cjsj = cjsj;
  }

  public String getCjsj() {
    return cjsj;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setFhts(String fhts) {
    this.fhts = fhts;
  }

  public String getFhts() {
    return fhts;
  }

}
