package  com.hzjc.hz2004.po;

public class PoXT_SLHXLB implements com.hzjc.wsstruts.po.PO
{
  private Long xlid;
  private String dwdm;
  private String slrq;
  private String slxlid;

  public void setXlid(Long xlid) {
    this.xlid = xlid;
  }

  public Long getXlid() {
    return xlid;
  }

  public void setDwdm(String dwdm) {
    this.dwdm = dwdm;
  }

  public String getDwdm() {
    return dwdm;
  }

  public void setSlrq(String slrq) {
    this.slrq = slrq;
  }

  public String getSlrq() {
    return slrq;
  }

  public void setSlxlid(String slxlid) {
    this.slxlid = slxlid;
  }

  public String getSlxlid() {
    return slxlid;
  }

}
