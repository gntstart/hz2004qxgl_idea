package  com.hzjc.hz2004.po;

public class PoV_HJ_HDXXB implements com.hzjc.wsstruts.po.PO
{
  private Long hhnbid;
  private Long hhid;
  private String hh;
  private String hlx;
  private String jhlb;
  private String chlb;
  private String jhsj;
  private String chsj;
  private Long hcjhjywid;
  private Long hcchjywid;
  private String hhzt;
  private Long hlxdbid;
  private String hjlbz;
  private String hqysj;
  private String hjssj;
  private String hcxbz;
  private Long mlpnbid;
  private Long mlpid;
  private String ssxq;
  private String jlx;
  private String mlph;
  private String mlxz;
  private String pcs;
  private String zrq;
  private String xzjd;
  private String jcwh;
  private String jdlb;
  private String cdlb;
  private String jdsj;
  private String cdsj;
  private Long dcjhjywid;
  private Long dcchjywid;
  private String mlpzt;
  private Long dlxdbid;
  private String djlbz;
  private String dqysj;
  private String djssj;
  private String pxh;

  public void setHhnbid(Long hhnbid) {
    this.hhnbid = hhnbid;
  }

  public Long getHhnbid() {
    return hhnbid;
  }

  public void setHhid(Long hhid) {
    this.hhid = hhid;
  }

  public Long getHhid() {
    return hhid;
  }

  public void setHh(String hh) {
    this.hh = hh;
  }

  public String getHh() {
    return hh;
  }

  public void setHlx(String hlx) {
    this.hlx = hlx;
  }

  public String getHlx() {
    return hlx;
  }

  public void setJhlb(String jhlb) {
    this.jhlb = jhlb;
  }

  public String getJhlb() {
    return jhlb;
  }

  public void setChlb(String chlb) {
    this.chlb = chlb;
  }

  public String getChlb() {
    return chlb;
  }

  public void setJhsj(String jhsj) {
    this.jhsj = jhsj;
  }

  public String getJhsj() {
    return jhsj;
  }

  public void setChsj(String chsj) {
    this.chsj = chsj;
  }

  public String getChsj() {
    return chsj;
  }

  public void setHcjhjywid(Long hcjhjywid) {
    this.hcjhjywid = hcjhjywid;
  }

  public Long getHcjhjywid() {
    return hcjhjywid;
  }

  public void setHcchjywid(Long hcchjywid) {
    this.hcchjywid = hcchjywid;
  }

  public Long getHcchjywid() {
    return hcchjywid;
  }

  public void setHhzt(String hhzt) {
    this.hhzt = hhzt;
  }

  public String getHhzt() {
    return hhzt;
  }

  public void setHlxdbid(Long hlxdbid) {
    this.hlxdbid = hlxdbid;
  }

  public Long getHlxdbid() {
    return hlxdbid;
  }

  public void setHjlbz(String hjlbz) {
    this.hjlbz = hjlbz;
  }

  public String getHjlbz() {
    return hjlbz;
  }

  public void setHqysj(String hqysj) {
    this.hqysj = hqysj;
  }

  public String getHqysj() {
    return hqysj;
  }

  public void setHjssj(String hjssj) {
    this.hjssj = hjssj;
  }

  public String getHjssj() {
    return hjssj;
  }

  public void setHcxbz(String hcxbz) {
    this.hcxbz = hcxbz;
  }

  public String getHcxbz() {
    return hcxbz;
  }

  public void setMlpnbid(Long mlpnbid) {
    this.mlpnbid = mlpnbid;
  }

  public Long getMlpnbid() {
    return mlpnbid;
  }

  public void setMlpid(Long mlpid) {
    this.mlpid = mlpid;
  }

  public Long getMlpid() {
    return mlpid;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public String getJlx() {
    return jlx;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public String getMlph() {
    return mlph;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public String getMlxz() {
    return mlxz;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public String getPcs() {
    return pcs;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public String getZrq() {
    return zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public String getXzjd() {
    return xzjd;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

  public void setJdlb(String jdlb) {
    this.jdlb = jdlb;
  }

  public String getJdlb() {
    return jdlb;
  }

  public void setCdlb(String cdlb) {
    this.cdlb = cdlb;
  }

  public String getCdlb() {
    return cdlb;
  }

  public void setJdsj(String jdsj) {
    this.jdsj = jdsj;
  }

  public String getJdsj() {
    return jdsj;
  }

  public void setCdsj(String cdsj) {
    this.cdsj = cdsj;
  }

  public String getCdsj() {
    return cdsj;
  }

  public void setDcjhjywid(Long dcjhjywid) {
    this.dcjhjywid = dcjhjywid;
  }

  public Long getDcjhjywid() {
    return dcjhjywid;
  }

  public void setDcchjywid(Long dcchjywid) {
    this.dcchjywid = dcchjywid;
  }

  public Long getDcchjywid() {
    return dcchjywid;
  }

  public void setMlpzt(String mlpzt) {
    this.mlpzt = mlpzt;
  }

  public String getMlpzt() {
    return mlpzt;
  }

  public void setDlxdbid(Long dlxdbid) {
    this.dlxdbid = dlxdbid;
  }

  public Long getDlxdbid() {
    return dlxdbid;
  }

  public void setDjlbz(String djlbz) {
    this.djlbz = djlbz;
  }

  public String getDjlbz() {
    return djlbz;
  }

  public void setDqysj(String dqysj) {
    this.dqysj = dqysj;
  }

  public String getDqysj() {
    return dqysj;
  }

  public void setDjssj(String djssj) {
    this.djssj = djssj;
  }

  public String getDjssj() {
    return djssj;
  }

  public void setPxh(String pxh) {
    this.pxh = pxh;
  }

  public String getPxh() {
    return pxh;
  }

}
