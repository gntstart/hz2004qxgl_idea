package  com.hzjc.hz2004.po;

public class PoXT_CZBDB implements com.hzjc.wsstruts.po.PO
{
  private Long bdid;
  private String bdsj;
  private String bdlx;
  private String bdbm;
  private String bdbzjm;
  private Long bdbid;
  private String scsj;
  private String scbz;

  public void setBdid(Long bdid) {
    this.bdid = bdid;
  }

  public Long getBdid() {
    return bdid;
  }

  public void setBdsj(String bdsj) {
    this.bdsj = bdsj;
  }

  public String getBdsj() {
    return bdsj;
  }

  public void setBdlx(String bdlx) {
    this.bdlx = bdlx;
  }

  public String getBdlx() {
    return bdlx;
  }

  public void setBdbm(String bdbm) {
    this.bdbm = bdbm;
  }

  public String getBdbm() {
    return bdbm;
  }

  public void setBdbzjm(String bdbzjm) {
    this.bdbzjm = bdbzjm;
  }

  public String getBdbzjm() {
    return bdbzjm;
  }

  public void setBdbid(Long bdbid) {
    this.bdbid = bdbid;
  }

  public Long getBdbid() {
    return bdbid;
  }

  public void setScsj(String scsj) {
    this.scsj = scsj;
  }

  public String getScsj() {
    return scsj;
  }

  public void setScbz(String scbz) {
    this.scbz = scbz;
  }

  public String getScbz() {
    return scbz;
  }

}
