package com.hzjc.hz2004.po;

public class PoHJXX_PZRZB
    implements com.hzjc.wsstruts.po.PO {

  private Long pzrzid;
  private Long zplsid;
  private Long nbslid;
  private Long yhid;
  private String ipdz;
  private String yhdlm;
  private String yhdw;
  private String yhxm;
  private String bcsj;
  private String rksj;
  private String gmsfhm;
  private String slh;
  private String pzxlh;

  public String getBcsj() {
    return bcsj;
  }

  public void setBcsj(String bcsj) {
    this.bcsj = bcsj;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getIpdz() {
    return ipdz;
  }

  public void setIpdz(String ipdz) {
    this.ipdz = ipdz;
  }

  public Long getPzrzid() {
    return pzrzid;
  }

  public void setPzrzid(Long pzrzid) {
    this.pzrzid = pzrzid;
  }

  public String getPzxlh() {
    return pzxlh;
  }

  public void setPzxlh(String pzxlh) {
    this.pzxlh = pzxlh;
  }

  public String getRksj() {
    return rksj;
  }

  public void setRksj(String rksj) {
    this.rksj = rksj;
  }

  public String getSlh() {
    return slh;
  }

  public void setSlh(String slh) {
    this.slh = slh;
  }

  public String getYhdlm() {
    return yhdlm;
  }

  public void setYhdlm(String yhdlm) {
    this.yhdlm = yhdlm;
  }

  public String getYhdw() {
    return yhdw;
  }

  public void setYhdw(String yhdw) {
    this.yhdw = yhdw;
  }

  public Long getYhid() {
    return yhid;
  }

  public void setYhid(Long yhid) {
    this.yhid = yhid;
  }

  public String getYhxm() {
    return yhxm;
  }

  public void setYhxm(String yhxm) {
    this.yhxm = yhxm;
  }

  public Long getZplsid() {
    return zplsid;
  }

  public void setZplsid(Long zplsid) {
    this.zplsid = zplsid;
  }

  public Long getNbslid() {
    return nbslid;
  }

  public void setNbslid(Long nbslid) {
    this.nbslid = nbslid;
  }
}