package  com.hzjc.hz2004.po;

public class PoXT_YHSJFWB implements com.hzjc.wsstruts.po.PO
{
  private Long sjfwid;
  private Long yhid;
  private String xqlx;
  private String sjfw;

  public void setSjfwid(Long sjfwid) {
    this.sjfwid = sjfwid;
  }

  public Long getSjfwid() {
    return sjfwid;
  }

  public void setYhid(Long yhid) {
    this.yhid = yhid;
  }

  public Long getYhid() {
    return yhid;
  }

  public void setXqlx(String xqlx) {
    this.xqlx = xqlx;
  }

  public String getXqlx() {
    return xqlx;
  }

  public void setSjfw(String sjfw) {
    this.sjfw = sjfw;
  }

  public String getSjfw() {
    return sjfw;
  }

}
