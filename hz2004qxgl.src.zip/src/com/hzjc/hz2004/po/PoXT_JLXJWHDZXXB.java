package  com.hzjc.hz2004.po;

public class PoXT_JLXJWHDZXXB implements com.hzjc.wsstruts.po.PO
{
  private Long czid;
  private String jlxdm;
  private String jwhdm;
  private String jlxhlx;
  private String jlxh;
  private String qybz;
  private String bdlx;
  private String bdsj;

  public void setCzid(Long czid) {
    this.czid = czid;
  }

  public Long getCzid() {
    return czid;
  }

  public void setJlxdm(String jlxdm) {
    this.jlxdm = jlxdm;
  }

  public String getJlxdm() {
    return jlxdm;
  }

  public void setJwhdm(String jwhdm) {
    this.jwhdm = jwhdm;
  }

  public String getJwhdm() {
    return jwhdm;
  }

  public void setJlxhlx(String jlxhlx) {
    this.jlxhlx = jlxhlx;
  }

  public String getJlxhlx() {
    return jlxhlx;
  }

  public void setJlxh(String jlxh) {
    this.jlxh = jlxh;
  }

  public String getJlxh() {
    return jlxh;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

  public void setBdlx(String bdlx) {
    this.bdlx = bdlx;
  }

  public String getBdlx() {
    return bdlx;
  }

  public void setBdsj(String bdsj) {
    this.bdsj = bdsj;
  }

  public String getBdsj() {
    return bdsj;
  }

}
