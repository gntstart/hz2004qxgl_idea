package  com.hzjc.hz2004.po;

public class PoXT_XTKZCSB implements com.hzjc.wsstruts.po.PO
{
  private Long csid;
  private String kzlb;
  private String kzmc;
  private String kzz;
  private String mrz;
  private String bz;
  private String xgbz;
  private String bdlx;
  private String bdsj;

  public void setCsid(Long csid) {
    this.csid = csid;
  }

  public Long getCsid() {
    return csid;
  }

  public void setKzlb(String kzlb) {
    this.kzlb = kzlb;
  }

  public String getKzlb() {
    return kzlb;
  }

  public void setKzmc(String kzmc) {
    this.kzmc = kzmc;
  }

  public String getKzmc() {
    return kzmc;
  }

  public void setKzz(String kzz) {
    this.kzz = kzz;
  }

  public String getKzz() {
    return kzz;
  }

  public void setMrz(String mrz) {
    this.mrz = mrz;
  }

  public String getMrz() {
    return mrz;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setXgbz(String xgbz) {
    this.xgbz = xgbz;
  }

  public String getXgbz() {
    return xgbz;
  }

  public void setBdlx(String bdlx) {
    this.bdlx = bdlx;
  }

  public String getBdlx() {
    return bdlx;
  }

  public void setBdsj(String bdsj) {
    this.bdsj = bdsj;
  }

  public String getBdsj() {
    return bdsj;
  }

}
