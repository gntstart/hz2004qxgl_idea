package  com.hzjc.hz2004.po;

public class PoHJXZ_MLPXXDJB implements com.hzjc.wsstruts.po.PO
{
  private Long mlpdjid;
  private String djfs;
  private String djlx;
  private String ssxq;
  private String jlx;
  private String jcwh;
  private String mlph;
  private String mlxz;
  private String qyrq;
  private String jzrq;
  private Long cjhjywid;
  private Long xghjywid;

  public void setMlpdjid(Long mlpdjid) {
    this.mlpdjid = mlpdjid;
  }

  public Long getMlpdjid() {
    return mlpdjid;
  }

  public void setDjfs(String djfs) {
    this.djfs = djfs;
  }

  public String getDjfs() {
    return djfs;
  }

  public void setDjlx(String djlx) {
    this.djlx = djlx;
  }

  public String getDjlx() {
    return djlx;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public String getJlx() {
    return jlx;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public String getMlph() {
    return mlph;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public String getMlxz() {
    return mlxz;
  }

  public void setQyrq(String qyrq) {
    this.qyrq = qyrq;
  }

  public String getQyrq() {
    return qyrq;
  }

  public void setJzrq(String jzrq) {
    this.jzrq = jzrq;
  }

  public String getJzrq() {
    return jzrq;
  }

  public void setCjhjywid(Long cjhjywid) {
    this.cjhjywid = cjhjywid;
  }

  public Long getCjhjywid() {
    return cjhjywid;
  }

  public void setXghjywid(Long xghjywid) {
    this.xghjywid = xghjywid;
  }

  public Long getXghjywid() {
    return xghjywid;
  }

}
