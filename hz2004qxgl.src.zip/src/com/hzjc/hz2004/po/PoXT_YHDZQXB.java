package  com.hzjc.hz2004.po;

public class PoXT_YHDZQXB implements com.hzjc.wsstruts.po.PO
{
  private Long dzqxid;
  private Long yhid;
  private Long dzid;

  public void setDzqxid(Long dzqxid) {
    this.dzqxid = dzqxid;
  }

  public Long getDzqxid() {
    return dzqxid;
  }

  public void setYhid(Long yhid) {
    this.yhid = yhid;
  }

  public Long getYhid() {
    return yhid;
  }

  public void setDzid(Long dzid) {
    this.dzid = dzid;
  }

  public Long getDzid() {
    return dzid;
  }

}
