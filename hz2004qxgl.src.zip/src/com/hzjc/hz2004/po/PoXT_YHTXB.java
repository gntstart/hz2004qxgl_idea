package com.hzjc.hz2004.po;

public class PoXT_YHTXB implements com.hzjc.wsstruts.po.PO{
  private String sfzh;
  private String xm;
  private String jh;
  private String dw;

  public void setSfzh(String sfzh) {
    this.sfzh = sfzh;
  }

  public String getSfzh() {
    return sfzh;
  }

  public void setJh(String jh) {
      this.jh = jh;
    }

    public String getJh() {
      return jh;
  }

  public void setDw(String dw) {
    this.dw = dw;
  }

  public String getDw() {
    return dw;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }
}
