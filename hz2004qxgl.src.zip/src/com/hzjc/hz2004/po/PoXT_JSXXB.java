package  com.hzjc.hz2004.po;

public class PoXT_JSXXB implements com.hzjc.wsstruts.po.PO
{
  private Long jsid;
  private String jsmc;
  private String ms;

  public void setJsid(Long jsid) {
    this.jsid = jsid;
  }

  public Long getJsid() {
    return jsid;
  }

  public void setJsmc(String jsmc) {
    this.jsmc = jsmc;
  }

  public String getJsmc() {
    return jsmc;
  }

  public void setMs(String ms) {
    this.ms = ms;
  }

  public String getMs() {
    return ms;
  }

}
