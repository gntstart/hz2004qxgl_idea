package com.hzjc.hz2004.po;

public class PoHJYW_CHCLXXB
    implements com.hzjc.wsstruts.po.PO {
  private Long chid;
  private Long ryid;
  private String chsfhm;
  private Long bchryid;
  private String bchrxm;
  private String bchrszpcs;
  private String bchrzz;
  private String clfs;
  private Long hjywid;
  private Long clhjywid;
  private String cxbz;
  private String cxsj;
  private Long cxrid;
  private Long cxhjywid;

  private String sbsj;
  private String sbryxm;
  private String sbrgmsfhm;
  private String slsj;
  private String sldw;
  private Long slrid;


  public void setChid(Long chid) {
    this.chid = chid;
  }

  public Long getChid() {
    return chid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setChsfhm(String chsfhm) {
    this.chsfhm = chsfhm;
  }

  public String getChsfhm() {
    return chsfhm;
  }

  public void setBchryid(Long bchryid) {
    this.bchryid = bchryid;
  }

  public Long getBchryid() {
    return bchryid;
  }

  public void setBchrxm(String bchrxm) {
    this.bchrxm = bchrxm;
  }

  public String getBchrxm() {
    return bchrxm;
  }

  public void setBchrszpcs(String bchrszpcs) {
    this.bchrszpcs = bchrszpcs;
  }

  public String getBchrszpcs() {
    return bchrszpcs;
  }

  public void setBchrzz(String bchrzz) {
    this.bchrzz = bchrzz;
  }

  public String getBchrzz() {
    return bchrzz;
  }

  public void setClfs(String clfs) {
    this.clfs = clfs;
  }

  public String getClfs() {
    return clfs;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public void setClhjywid(Long clhjywid) {
    this.clhjywid = clhjywid;
  }

  public Long getClhjywid() {
    return clhjywid;
  }

  public void setCxbz(String cxbz) {
    this.cxbz = cxbz;
  }

  public String getCxbz() {
    return cxbz;
  }

  public void setCxsj(String cxsj) {
    this.cxsj = cxsj;
  }

  public String getCxsj() {
    return cxsj;
  }

  public void setCxrid(Long cxrid) {
    this.cxrid = cxrid;
  }

  public Long getCxrid() {
    return cxrid;
  }

  public void setCxhjywid(Long cxhjywid) {
    this.cxhjywid = cxhjywid;
  }

  public Long getCxhjywid() {
    return cxhjywid;
  }
  public String getSbrgmsfhm() {
    return sbrgmsfhm;
  }
  public void setSbrgmsfhm(String sbrgmsfhm) {
    this.sbrgmsfhm = sbrgmsfhm;
  }
  public String getSbryxm() {
    return sbryxm;
  }
  public String getSbsj() {
    return sbsj;
  }
  public String getSldw() {
    return sldw;
  }
  public Long getSlrid() {
    return slrid;
  }
  public String getSlsj() {
    return slsj;
  }
  public void setSlsj(String slsj) {
    this.slsj = slsj;
  }
  public void setSlrid(Long slrid) {
    this.slrid = slrid;
  }
  public void setSldw(String sldw) {
    this.sldw = sldw;
  }
  public void setSbsj(String sbsj) {
    this.sbsj = sbsj;
  }
  public void setSbryxm(String sbryxm) {
    this.sbryxm = sbryxm;
  }

}
