package  com.hzjc.hz2004.po;

public class PoXT_JSGNQXB implements com.hzjc.wsstruts.po.PO
{
  private Long jsgnid;
  private Long jsid;
  private Long gnid;

  public void setJsgnid(Long jsgnid) {
    this.jsgnid = jsgnid;
  }

  public Long getJsgnid() {
    return jsgnid;
  }

  public void setJsid(Long jsid) {
    this.jsid = jsid;
  }

  public Long getJsid() {
    return jsid;
  }

  public void setGnid(Long gnid) {
    this.gnid = gnid;
  }

  public Long getGnid() {
    return gnid;
  }

}
