package com.hzjc.hz2004.po;

public class PoYDZJ_SBXXB
    implements com.hzjc.wsstruts.po.PO {
  private Long sbxxid;
  private String ssxq;
  private String slh;
  private String gmsfhm;
  private String xm;
  private String cym;
  private String xb;
  private String csrq;
  private String mz;
  private String zz;
  private String slyy;
  private String zzlx;
  private String lzfs;
  private String sjrxm;
  private String sjrlxdh;
  private String sjryb;
  private String sjrtxdz;
  private Long zpid;
  private Long zzfy;
  private String sbddm;
  private String sbdmc;
  private String czyip;
  private Long czyid;
  private String czyxm;
  private String czsj;
  private String slzt;
  private String tbbz;
  private String bwbha;
  private String tbsj;
  private String bwbhb;
  private String hksj;

  private String zlhkzt;
  private String zzxxcwlb;
  private String cwms;
  private String jydw;
  private String jyr;
  private String jysj;
  private String fkxxbwbh;
  private String clr;
  private String cldw;
  private String clqk;
  private String clsj;
  private String lzsj;
  private Long lzslr;
  private String lzrxm;
  private String lzrgmsfhm;
  private String lzrdh;
  private Long lztbbz;
  private String lzxxbwbh;
  private Long sbh;
  private String bz;
  private String sblx;

  public void setSbxxid(Long sbxxid) {
    this.sbxxid = sbxxid;
  }

  public Long getSbxxid() {
    return sbxxid;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setSlh(String slh) {
    this.slh = slh;
  }

  public String getSlh() {
    return slh;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setCym(String cym) {
    this.cym = cym;
  }

  public String getCym() {
    return cym;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public String getXb() {
    return xb;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public String getCsrq() {
    return csrq;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public String getMz() {
    return mz;
  }

  public void setZz(String zz) {
    this.zz = zz;
  }

  public String getZz() {
    return zz;
  }

  public void setSlyy(String slyy) {
    this.slyy = slyy;
  }

  public String getSlyy() {
    return slyy;
  }

  public void setZzlx(String zzlx) {
    this.zzlx = zzlx;
  }

  public String getZzlx() {
    return zzlx;
  }

  public void setLzfs(String lzfs) {
    this.lzfs = lzfs;
  }

  public String getLzfs() {
    return lzfs;
  }

  public void setSjrxm(String sjrxm) {
    this.sjrxm = sjrxm;
  }

  public String getSjrxm() {
    return sjrxm;
  }

  public void setSjrlxdh(String sjrlxdh) {
    this.sjrlxdh = sjrlxdh;
  }

  public String getSjrlxdh() {
    return sjrlxdh;
  }

  public void setSjryb(String sjryb) {
    this.sjryb = sjryb;
  }

  public String getSjryb() {
    return sjryb;
  }

  public void setSjrtxdz(String sjrtxdz) {
    this.sjrtxdz = sjrtxdz;
  }

  public String getSjrtxdz() {
    return sjrtxdz;
  }

  public void setZpid(Long zpid) {
    this.zpid = zpid;
  }

  public Long getZpid() {
    return zpid;
  }

  public void setZzfy(Long zzfy) {
    this.zzfy = zzfy;
  }

  public Long getZzfy() {
    return zzfy;
  }

  public void setSbddm(String sbddm) {
    this.sbddm = sbddm;
  }

  public String getSbddm() {
    return sbddm;
  }

  public void setSbdmc(String sbdmc) {
    this.sbdmc = sbdmc;
  }

  public String getSbdmc() {
    return sbdmc;
  }

  public void setCzyip(String czyip) {
    this.czyip = czyip;
  }

  public String getCzyip() {
    return czyip;
  }

  public void setCzyid(Long czyid) {
    this.czyid = czyid;
  }

  public Long getCzyid() {
    return czyid;
  }

  public void setCzyxm(String czyxm) {
    this.czyxm = czyxm;
  }

  public String getCzyxm() {
    return czyxm;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

  public void setSlzt(String slzt) {
    this.slzt = slzt;
  }

  public String getSlzt() {
    return slzt;
  }

  public void setTbbz(String tbbz) {
    this.tbbz = tbbz;
  }

  public String getTbbz() {
    return tbbz;
  }

  public void setBwbha(String bwbha) {
    this.bwbha = bwbha;
  }

  public String getBwbha() {
    return bwbha;
  }

  public void setTbsj(String tbsj) {
    this.tbsj = tbsj;
  }

  public String getTbsj() {
    return tbsj;
  }

  public void setBwbhb(String bwbhb) {
    this.bwbhb = bwbhb;
  }

  public String getBwbhb() {
    return bwbhb;
  }

  public void setHksj(String hksj) {
    this.hksj = hksj;
  }

  public String getHksj() {
    return hksj;
  }

  public void setZlhkzt(String zlhkzt) {
    this.zlhkzt = zlhkzt;
  }

  public String getZlhkzt() {
    return zlhkzt;
  }

  public void setZzxxcwlb(String zzxxcwlb) {
    this.zzxxcwlb = zzxxcwlb;
  }

  public String getZzxxcwlb() {
    return zzxxcwlb;
  }

  public void setCwms(String cwms) {
    this.cwms = cwms;
  }

  public String getCwms() {
    return cwms;
  }

  public void setJydw(String jydw) {
    this.jydw = jydw;
  }

  public String getJydw() {
    return jydw;
  }

  public void setJyr(String jyr) {
    this.jyr = jyr;
  }

  public String getJyr() {
    return jyr;
  }

  public void setJysj(String jysj) {
    this.jysj = jysj;
  }

  public String getJysj() {
    return jysj;
  }

  public void setFkxxbwbh(String fkxxbwbh) {
    this.fkxxbwbh = fkxxbwbh;
  }

  public String getFkxxbwbh() {
    return fkxxbwbh;
  }

  public void setClr(String clr) {
    this.clr = clr;
  }

  public String getClr() {
    return clr;
  }

  public void setCldw(String cldw) {
    this.cldw = cldw;
  }

  public String getCldw() {
    return cldw;
  }

  public void setClqk(String clqk) {
    this.clqk = clqk;
  }

  public String getClqk() {
    return clqk;
  }

  public void setClsj(String clsj) {
    this.clsj = clsj;
  }

  public String getClsj() {
    return clsj;
  }

  public void setLzsj(String lzsj) {
    this.lzsj = lzsj;
  }

  public String getLzsj() {
    return lzsj;
  }

  public void setLzslr(Long lzslr) {
    this.lzslr = lzslr;
  }

  public Long getLzslr() {
    return lzslr;
  }

  public void setLzrxm(String lzrxm) {
    this.lzrxm = lzrxm;
  }

  public String getLzrxm() {
    return lzrxm;
  }

  public void setLzrgmsfhm(String lzrgmsfhm) {
    this.lzrgmsfhm = lzrgmsfhm;
  }

  public String getLzrgmsfhm() {
    return lzrgmsfhm;
  }

  public void setLzrdh(String lzrdh) {
    this.lzrdh = lzrdh;
  }

  public String getLzrdh() {
    return lzrdh;
  }

  public void setLztbbz(Long lztbbz) {
    this.lztbbz = lztbbz;
  }

  public Long getLztbbz() {
    return lztbbz;
  }

  public void setLzxxbwbh(String lzxxbwbh) {
    this.lzxxbwbh = lzxxbwbh;
  }

  public String getLzxxbwbh() {
    return lzxxbwbh;
  }

  public void setSbh(Long sbh) {
    this.sbh = sbh;
  }

  public Long getSbh() {
    return sbh;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setSblx(String sblx) {
    this.sblx = sblx;
  }

  public String getSblx() {
    return sblx;
  }

}
