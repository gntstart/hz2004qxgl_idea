package  com.hzjc.hz2004.po;

public class PoXT_JWHXXB implements com.hzjc.wsstruts.po.PO
{
  private String dm;
  private String mc;
  private String zwpy;
  private String wbpy;
  private String dwdm;
  private String xzjddm;
  private String bz;
  private String qybz;
  private String bdlx;
  private String bdsj;

  private String cxflmc;
  private String tjdm;
  private String tjmc;
  private String cxfldm;

  private String xdm;
  private String dzys;
  private String dzysmc;


  public void setCxfldm(String cxfldm) {
    this.cxfldm = cxfldm;
  }

  public String getCxfldm() {
    return cxfldm;
  }

  public void setCxflmc(String cxflmc) {
    this.cxflmc = cxflmc;
  }

  public String getCxflmc() {
    return cxflmc;
  }

  public void setTjdm(String tjdm) {
    this.tjdm = tjdm;
  }

  public String getTjdm() {
    return tjdm;
  }

  public void setTjmc(String tjmc) {
    this.tjmc = tjmc;
  }

  public String getTjmc() {
    return tjmc;
  }

  public void setDm(String dm) {
    this.dm = dm;
  }

  public String getDm() {
    return dm;
  }

  public void setMc(String mc) {
    this.mc = mc;
  }

  public String getMc() {
    return mc;
  }

  public void setZwpy(String zwpy) {
    this.zwpy = zwpy;
  }

  public String getZwpy() {
    return zwpy;
  }

  public void setWbpy(String wbpy) {
    this.wbpy = wbpy;
  }

  public String getWbpy() {
    return wbpy;
  }

  public void setDwdm(String dwdm) {
    this.dwdm = dwdm;
  }

  public String getDwdm() {
    return dwdm;
  }

  public void setXzjddm(String xzjddm) {
    this.xzjddm = xzjddm;
  }

  public String getXzjddm() {
    return xzjddm;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

  public void setBdlx(String bdlx) {
    this.bdlx = bdlx;
  }

  public String getBdlx() {
    return bdlx;
  }

  public void setBdsj(String bdsj) {
    this.bdsj = bdsj;
  }

  public void setDzys(String dzys) {
    this.dzys = dzys;
  }

  public void setDzysmc(String dzysmc) {
    this.dzysmc = dzysmc;
  }

  public void setXdm(String xdm) {
    this.xdm = xdm;
  }

  public String getBdsj() {
    return bdsj;
  }

  public String getDzys() {
    return dzys;
  }

  public String getDzysmc() {
    return dzysmc;
  }

  public String getXdm() {
    return xdm;
  }

}
