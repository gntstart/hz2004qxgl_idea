package com.hzjc.hz2004.po;

public class PoHJSP_HJSPZB
    implements com.hzjc.wsstruts.po.PO {
  private Long spsqzid;
  private Long spywid;
  private Long ryid;
  private String xm;
  private String xb;
  private String csrq;
  private String mz;
  private String gmsfhm;
  private String ysqrgx;
  private String yhkqx;
  private String yhkszd;
  private String hkxz;
  private String qrhhb; //Ǩ��󻧱�
  private String gzdw;
  private Long rynbid;
  private String zqzjlx;
  private String zjbh;

  public void setSpsqzid(Long spsqzid) {
    this.spsqzid = spsqzid;
  }

  public Long getSpsqzid() {
    return spsqzid;
  }

  public void setSpywid(Long spywid) {
    this.spywid = spywid;
  }

  public Long getSpywid() {
    return spywid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public String getXb() {
    return xb;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public String getCsrq() {
    return csrq;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public String getMz() {
    return mz;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setYsqrgx(String ysqrgx) {
    this.ysqrgx = ysqrgx;
  }

  public String getYsqrgx() {
    return ysqrgx;
  }

  public void setYhkqx(String yhkqx) {
    this.yhkqx = yhkqx;
  }

  public String getYhkqx() {
    return yhkqx;
  }

  public void setYhkszd(String yhkszd) {
    this.yhkszd = yhkszd;
  }

  public String getYhkszd() {
    return yhkszd;
  }

  public void setHkxz(String hkxz) {
    this.hkxz = hkxz;
  }

  public String getHkxz() {
    return hkxz;
  }

  public void setGzdw(String gzdw) {
    this.gzdw = gzdw;
  }

  public String getGzdw() {
    return gzdw;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public String getZjbh() {
    return zjbh;
  }

  public void setZjbh(String zjbh) {
    this.zjbh = zjbh;
  }

  public String getZqzjlx() {
    return zqzjlx;
  }

  public void setZqzjlx(String zqzjlx) {
    this.zqzjlx = zqzjlx;
  }
  public String getQrhhb() {
    return qrhhb;
  }
  public void setQrhhb(String qrhhb) {
    this.qrhhb = qrhhb;
  }

}
