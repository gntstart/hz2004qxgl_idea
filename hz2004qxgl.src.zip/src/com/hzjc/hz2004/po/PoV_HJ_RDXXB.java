package  com.hzjc.hz2004.po;

public class PoV_HJ_RDXXB implements com.hzjc.wsstruts.po.PO
{
  private Long rynbid;
  private Long ryid;
  private Long zpid;
  private String gmsfhm;
  private String xm;
  private String cym;
  private String xb;
  private String mz;
  private String csrq;
  private String cssj;
  private String csdgjdq;
  private String csdssxq;
  private String csdxz;
  private String dhhm;
  private String jhrygmsfhm;
  private String jhryxm;
  private String jhryjhgx;
  private String jhregmsfhm;
  private String jhrexm;
  private String jhrejhgx;
  private String fqgmsfhm;
  private String fqxm;
  private String mqgmsfhm;
  private String mqxm;
  private String pogmsfhm;
  private String poxm;
  private String jggjdq;
  private String jgssxq;
  private String zjxy;
  private String whcd;
  private String hyzk;
  private String byzk;
  private String sg;
  private String xx;
  private String zy;
  private String zylb;
  private String fwcs;
  private String xxjb;
  private String rylb;
  private String hb;
  private String yhzgx;
  private String ryzt;
  private String rysdzt;
  private Long rlxdbid;
  private String bz;
  private String rjlbz;
  private String ywnr;
  private Long cjhjywid;
  private Long cchjywid;
  private String rqysj;
  private String rjssj;
  private String rcxbz;
  private Long mlpnbid;
  private Long mlpid;
  private String ssxq;
  private String jlx;
  private String mlph;
  private String mlxz;
  private String pcs;
  private String zrq;
  private String xzjd;
  private String jcwh;
  private String jdlb;
  private String cdlb;
  private String jdsj;
  private String cdsj;
  private Long dcjhjywid;
  private Long dcchjywid;
  private String mlpzt;
  private Long dlxdbid;
  private String djlbz;
  private String dqysj;
  private String djssj;
  private String pxh;

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setZpid(Long zpid) {
    this.zpid = zpid;
  }

  public Long getZpid() {
    return zpid;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setCym(String cym) {
    this.cym = cym;
  }

  public String getCym() {
    return cym;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public String getXb() {
    return xb;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public String getMz() {
    return mz;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public String getCsrq() {
    return csrq;
  }

  public void setCssj(String cssj) {
    this.cssj = cssj;
  }

  public String getCssj() {
    return cssj;
  }

  public void setCsdgjdq(String csdgjdq) {
    this.csdgjdq = csdgjdq;
  }

  public String getCsdgjdq() {
    return csdgjdq;
  }

  public void setCsdssxq(String csdssxq) {
    this.csdssxq = csdssxq;
  }

  public String getCsdssxq() {
    return csdssxq;
  }

  public void setCsdxz(String csdxz) {
    this.csdxz = csdxz;
  }

  public String getCsdxz() {
    return csdxz;
  }

  public void setDhhm(String dhhm) {
    this.dhhm = dhhm;
  }

  public String getDhhm() {
    return dhhm;
  }

  public void setJhrygmsfhm(String jhrygmsfhm) {
    this.jhrygmsfhm = jhrygmsfhm;
  }

  public String getJhrygmsfhm() {
    return jhrygmsfhm;
  }

  public void setJhryxm(String jhryxm) {
    this.jhryxm = jhryxm;
  }

  public String getJhryxm() {
    return jhryxm;
  }

  public void setJhryjhgx(String jhryjhgx) {
    this.jhryjhgx = jhryjhgx;
  }

  public String getJhryjhgx() {
    return jhryjhgx;
  }

  public void setJhregmsfhm(String jhregmsfhm) {
    this.jhregmsfhm = jhregmsfhm;
  }

  public String getJhregmsfhm() {
    return jhregmsfhm;
  }

  public void setJhrexm(String jhrexm) {
    this.jhrexm = jhrexm;
  }

  public String getJhrexm() {
    return jhrexm;
  }

  public void setJhrejhgx(String jhrejhgx) {
    this.jhrejhgx = jhrejhgx;
  }

  public String getJhrejhgx() {
    return jhrejhgx;
  }

  public void setFqgmsfhm(String fqgmsfhm) {
    this.fqgmsfhm = fqgmsfhm;
  }

  public String getFqgmsfhm() {
    return fqgmsfhm;
  }

  public void setFqxm(String fqxm) {
    this.fqxm = fqxm;
  }

  public String getFqxm() {
    return fqxm;
  }

  public void setMqgmsfhm(String mqgmsfhm) {
    this.mqgmsfhm = mqgmsfhm;
  }

  public String getMqgmsfhm() {
    return mqgmsfhm;
  }

  public void setMqxm(String mqxm) {
    this.mqxm = mqxm;
  }

  public String getMqxm() {
    return mqxm;
  }

  public void setPogmsfhm(String pogmsfhm) {
    this.pogmsfhm = pogmsfhm;
  }

  public String getPogmsfhm() {
    return pogmsfhm;
  }

  public void setPoxm(String poxm) {
    this.poxm = poxm;
  }

  public String getPoxm() {
    return poxm;
  }

  public void setJggjdq(String jggjdq) {
    this.jggjdq = jggjdq;
  }

  public String getJggjdq() {
    return jggjdq;
  }

  public void setJgssxq(String jgssxq) {
    this.jgssxq = jgssxq;
  }

  public String getJgssxq() {
    return jgssxq;
  }

  public void setZjxy(String zjxy) {
    this.zjxy = zjxy;
  }

  public String getZjxy() {
    return zjxy;
  }

  public void setWhcd(String whcd) {
    this.whcd = whcd;
  }

  public String getWhcd() {
    return whcd;
  }

  public void setHyzk(String hyzk) {
    this.hyzk = hyzk;
  }

  public String getHyzk() {
    return hyzk;
  }

  public void setByzk(String byzk) {
    this.byzk = byzk;
  }

  public String getByzk() {
    return byzk;
  }

  public void setSg(String sg) {
    this.sg = sg;
  }

  public String getSg() {
    return sg;
  }

  public void setXx(String xx) {
    this.xx = xx;
  }

  public String getXx() {
    return xx;
  }

  public void setZy(String zy) {
    this.zy = zy;
  }

  public String getZy() {
    return zy;
  }

  public void setZylb(String zylb) {
    this.zylb = zylb;
  }

  public String getZylb() {
    return zylb;
  }

  public void setFwcs(String fwcs) {
    this.fwcs = fwcs;
  }

  public String getFwcs() {
    return fwcs;
  }

  public void setXxjb(String xxjb) {
    this.xxjb = xxjb;
  }

  public String getXxjb() {
    return xxjb;
  }

  public void setRylb(String rylb) {
    this.rylb = rylb;
  }

  public String getRylb() {
    return rylb;
  }

  public void setHb(String hb) {
    this.hb = hb;
  }

  public String getHb() {
    return hb;
  }

  public void setYhzgx(String yhzgx) {
    this.yhzgx = yhzgx;
  }

  public String getYhzgx() {
    return yhzgx;
  }

  public void setRyzt(String ryzt) {
    this.ryzt = ryzt;
  }

  public String getRyzt() {
    return ryzt;
  }

  public void setRysdzt(String rysdzt) {
    this.rysdzt = rysdzt;
  }

  public String getRysdzt() {
    return rysdzt;
  }

  public void setRlxdbid(Long rlxdbid) {
    this.rlxdbid = rlxdbid;
  }

  public Long getRlxdbid() {
    return rlxdbid;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setRjlbz(String rjlbz) {
    this.rjlbz = rjlbz;
  }

  public String getRjlbz() {
    return rjlbz;
  }

  public void setYwnr(String ywnr) {
    this.ywnr = ywnr;
  }

  public String getYwnr() {
    return ywnr;
  }

  public void setCjhjywid(Long cjhjywid) {
    this.cjhjywid = cjhjywid;
  }

  public Long getCjhjywid() {
    return cjhjywid;
  }

  public void setCchjywid(Long cchjywid) {
    this.cchjywid = cchjywid;
  }

  public Long getCchjywid() {
    return cchjywid;
  }

  public void setRqysj(String rqysj) {
    this.rqysj = rqysj;
  }

  public String getRqysj() {
    return rqysj;
  }

  public void setRjssj(String rjssj) {
    this.rjssj = rjssj;
  }

  public String getRjssj() {
    return rjssj;
  }

  public void setRcxbz(String rcxbz) {
    this.rcxbz = rcxbz;
  }

  public String getRcxbz() {
    return rcxbz;
  }

  public void setMlpnbid(Long mlpnbid) {
    this.mlpnbid = mlpnbid;
  }

  public Long getMlpnbid() {
    return mlpnbid;
  }

  public void setMlpid(Long mlpid) {
    this.mlpid = mlpid;
  }

  public Long getMlpid() {
    return mlpid;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public String getJlx() {
    return jlx;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public String getMlph() {
    return mlph;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public String getMlxz() {
    return mlxz;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public String getPcs() {
    return pcs;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public String getZrq() {
    return zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public String getXzjd() {
    return xzjd;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

  public void setJdlb(String jdlb) {
    this.jdlb = jdlb;
  }

  public String getJdlb() {
    return jdlb;
  }

  public void setCdlb(String cdlb) {
    this.cdlb = cdlb;
  }

  public String getCdlb() {
    return cdlb;
  }

  public void setJdsj(String jdsj) {
    this.jdsj = jdsj;
  }

  public String getJdsj() {
    return jdsj;
  }

  public void setCdsj(String cdsj) {
    this.cdsj = cdsj;
  }

  public String getCdsj() {
    return cdsj;
  }

  public void setDcjhjywid(Long dcjhjywid) {
    this.dcjhjywid = dcjhjywid;
  }

  public Long getDcjhjywid() {
    return dcjhjywid;
  }

  public void setDcchjywid(Long dcchjywid) {
    this.dcchjywid = dcchjywid;
  }

  public Long getDcchjywid() {
    return dcchjywid;
  }

  public void setMlpzt(String mlpzt) {
    this.mlpzt = mlpzt;
  }

  public String getMlpzt() {
    return mlpzt;
  }

  public void setDlxdbid(Long dlxdbid) {
    this.dlxdbid = dlxdbid;
  }

  public Long getDlxdbid() {
    return dlxdbid;
  }

  public void setDjlbz(String djlbz) {
    this.djlbz = djlbz;
  }

  public String getDjlbz() {
    return djlbz;
  }

  public void setDqysj(String dqysj) {
    this.dqysj = dqysj;
  }

  public String getDqysj() {
    return dqysj;
  }

  public void setDjssj(String djssj) {
    this.djssj = djssj;
  }

  public String getDjssj() {
    return djssj;
  }

  public void setPxh(String pxh) {
    this.pxh = pxh;
  }

  public String getPxh() {
    return pxh;
  }

}
