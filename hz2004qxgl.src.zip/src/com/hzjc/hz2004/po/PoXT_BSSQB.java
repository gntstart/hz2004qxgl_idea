package  com.hzjc.hz2004.po;

public class PoXT_BSSQB implements com.hzjc.wsstruts.po.PO
{
  private Long sqid;
  private String qhdm;
  private String sqbz;
  private String gxbz;
  private String qybz;
  private String bdlx;
  private String bdsj;

  public void setSqid(Long sqid) {
    this.sqid = sqid;
  }

  public Long getSqid() {
    return sqid;
  }

  public void setQhdm(String qhdm) {
    this.qhdm = qhdm;
  }

  public String getQhdm() {
    return qhdm;
  }

  public void setSqbz(String sqbz) {
    this.sqbz = sqbz;
  }

  public String getSqbz() {
    return sqbz;
  }

  public void setGxbz(String gxbz) {
    this.gxbz = gxbz;
  }

  public String getGxbz() {
    return gxbz;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

  public void setBdlx(String bdlx) {
    this.bdlx = bdlx;
  }

  public String getBdlx() {
    return bdlx;
  }

  public void setBdsj(String bdsj) {
    this.bdsj = bdsj;
  }

  public String getBdsj() {
    return bdsj;
  }

}
