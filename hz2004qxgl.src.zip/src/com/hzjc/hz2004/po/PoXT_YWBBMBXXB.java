package  com.hzjc.hz2004.po;

public class PoXT_YWBBMBXXB implements com.hzjc.wsstruts.po.PO
{
  private Long ywbbid;
  private String ywbblb;
  private String bbmc;
  private byte[] bbmb;
  private String jlsj;
  private Long jlrid;
  private String xgsj;
  private Long xgrid;

  public void setYwbbid(Long ywbbid) {
    this.ywbbid = ywbbid;
  }

  public Long getYwbbid() {
    return ywbbid;
  }

  public void setYwbblb(String ywbblb) {
    this.ywbblb = ywbblb;
  }

  public String getYwbblb() {
    return ywbblb;
  }

  public void setBbmc(String bbmc) {
    this.bbmc = bbmc;
  }

  public String getBbmc() {
    return bbmc;
  }

  public void setBbmb(byte[] bbmb) {
    this.bbmb = bbmb;
  }

  public byte[] getBbmb() {
    return bbmb;
  }

  public void setJlsj(String jlsj) {
    this.jlsj = jlsj;
  }

  public String getJlsj() {
    return jlsj;
  }

  public void setJlrid(Long jlrid) {
    this.jlrid = jlrid;
  }

  public Long getJlrid() {
    return jlrid;
  }

  public void setXgsj(String xgsj) {
    this.xgsj = xgsj;
  }

  public String getXgsj() {
    return xgsj;
  }

  public void setXgrid(Long xgrid) {
    this.xgrid = xgrid;
  }

  public Long getXgrid() {
    return xgrid;
  }

}
