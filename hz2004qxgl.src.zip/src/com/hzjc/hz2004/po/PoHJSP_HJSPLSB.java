package  com.hzjc.hz2004.po;

public class PoHJSP_HJSPLSB implements com.hzjc.wsstruts.po.PO
{
  private Long splsid;
  private Long spywid;
  private String splx;
  private Long dzid;
  private String czjg;
  private String czyj;
  private Long czrid;
  private String czsj;

  public void setSplsid(Long splsid) {
    this.splsid = splsid;
  }

  public Long getSplsid() {
    return splsid;
  }

  public void setSpywid(Long spywid) {
    this.spywid = spywid;
  }

  public Long getSpywid() {
    return spywid;
  }

  public void setSplx(String splx) {
    this.splx = splx;
  }

  public String getSplx() {
    return splx;
  }

  public void setDzid(Long dzid) {
    this.dzid = dzid;
  }

  public Long getDzid() {
    return dzid;
  }

  public void setCzjg(String czjg) {
    this.czjg = czjg;
  }

  public String getCzjg() {
    return czjg;
  }

  public void setCzyj(String czyj) {
    this.czyj = czyj;
  }

  public String getCzyj() {
    return czyj;
  }

  public void setCzrid(Long czrid) {
    this.czrid = czrid;
  }

  public Long getCzrid() {
    return czrid;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

}
