package com.hzjc.hz2004.po;

public class PoWW_PJXXYWLSB
    implements com.hzjc.wsstruts.po.PO {

  private Long pjywid;
  private Long pjid;
  private Long hjywid;
  private String ywbz;
  private String ywlx;
  private Long czsm;
  private String sbsj;
  private String sbryxm;
  private String sbrgmsfhm;
  private String slsj;
  private String sldw;
  private Long slrid;
  private String pjjg;

  public Long getPjywid() {
    return pjywid;
  }

  public void setPjywid(Long pjywid) {
    this.pjywid = pjywid;
  }

  public Long getPjid() {
    return pjid;
  }

  public void setPjid(Long pjid) {
    this.pjid = pjid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public String getYwbz() {
    return ywbz;
  }

  public void setYwbz(String ywbz) {
    this.ywbz = ywbz;
  }

  public String getYwlx() {
    return ywlx;
  }

  public void setYwlx(String ywlx) {
    this.ywlx = ywlx;
  }

  public Long getCzsm() {
    return czsm;
  }

  public void setCzsm(Long czsm) {
    this.czsm = czsm;
  }

  public String getSbsj() {
    return sbsj;
  }

  public void setSbsj(String sbsj) {
    this.sbsj = sbsj;
  }

  public String getSbryxm() {
    return sbryxm;
  }

  public void setSbryxm(String sbryxm) {
    this.sbryxm = sbryxm;
  }

  public String getSbrgmsfhm() {
    return sbrgmsfhm;
  }

  public void setSbrgmsfhm(String sbrgmsfhm) {
    this.sbrgmsfhm = sbrgmsfhm;
  }

  public String getSlsj() {
    return slsj;
  }

  public void setSlsj(String slsj) {
    this.slsj = slsj;
  }

  public String getSldw() {
    return sldw;
  }

  public void setSldw(String sldw) {
    this.sldw = sldw;
  }

  public Long getSlrid() {
    return slrid;
  }

  public void setSlrid(Long slrid) {
    this.slrid = slrid;
  }

  public String getPjjg() {
      return pjjg;
    }

    public void setPjjg(String pjjg) {
      this.pjjg = pjjg;
  }
}
