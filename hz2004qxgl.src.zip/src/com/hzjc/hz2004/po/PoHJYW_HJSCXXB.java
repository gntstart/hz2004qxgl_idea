package com.hzjc.hz2004.po;

public class PoHJYW_HJSCXXB
    implements com.hzjc.wsstruts.po.PO {
  private Long hjscid;
  private Long rynbid;
  private String hjsclb;
  private Long hjywid;
  private String cxbz;
  private String cxsj;
  private Long cxrid;
  private Long cxhjywid;
  private String hjscsm;

  private String sbsj;
  private String sbryxm;
  private String sbrgmsfhm;
  private String slsj;
  private String sldw;
  private Long slrid;

  private String xm;
  private String mz;
  private String xb;
  private String csrq;
  private String cssj;
  private String csdssxq;
  private String ssxq;
  private String jlx;
  private String mlph;
  private String mlxz;
  private String pcs;
  private String zrq;
  private String xzjd;
  private String jcwh;
  private String pxh;
  private String gmsfhm;
  private String hb;
  private Long ryid;
  private Long hhnbid;
  private Long hhid;
  private Long mlpnbid;
  private Long mlpid;

  private String yhzgx;
  private String hzxm;
  private String hzgmsfhm;
  private String ywlx;
  private Long czsm;
  private String bz;

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setHjscid(Long hjscid) {
    this.hjscid = hjscid;
  }

  public Long getHjscid() {
    return hjscid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setHjsclb(String hjsclb) {
    this.hjsclb = hjsclb;
  }

  public String getHjsclb() {
    return hjsclb;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public void setCxbz(String cxbz) {
    this.cxbz = cxbz;
  }

  public String getCxbz() {
    return cxbz;
  }

  public void setCxsj(String cxsj) {
    this.cxsj = cxsj;
  }

  public String getCxsj() {
    return cxsj;
  }

  public void setCxrid(Long cxrid) {
    this.cxrid = cxrid;
  }

  public Long getCxrid() {
    return cxrid;
  }

  public void setCxhjywid(Long cxhjywid) {
    this.cxhjywid = cxhjywid;
  }

  public Long getCxhjywid() {
    return cxhjywid;
  }

  public String getSbrgmsfhm() {
    return sbrgmsfhm;
  }

  public void setSbrgmsfhm(String sbrgmsfhm) {
    this.sbrgmsfhm = sbrgmsfhm;
  }

  public String getSbryxm() {
    return sbryxm;
  }

  public void setSbryxm(String sbryxm) {
    this.sbryxm = sbryxm;
  }

  public String getSbsj() {
    return sbsj;
  }

  public void setSbsj(String sbsj) {
    this.sbsj = sbsj;
  }

  public String getSldw() {
    return sldw;
  }

  public void setSldw(String sldw) {
    this.sldw = sldw;
  }

  public Long getSlrid() {
    return slrid;
  }

  public void setSlrid(Long slrid) {
    this.slrid = slrid;
  }

  public String getSlsj() {
    return slsj;
  }

  public void setSlsj(String slsj) {
    this.slsj = slsj;
  }

  public String getCsdssxq() {
    return csdssxq;
  }

  public String getCsrq() {
    return csrq;
  }

  public String getCssj() {
    return cssj;
  }

  public void setCssj(String cssj) {
    this.cssj = cssj;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public void setCsdssxq(String csdssxq) {
    this.csdssxq = csdssxq;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public String getHb() {
    return hb;
  }

  public Long getHhnbid() {
    return hhnbid;
  }

  public void setHhnbid(Long hhnbid) {
    this.hhnbid = hhnbid;
  }

  public void setHb(String hb) {
    this.hb = hb;
  }

  public String getJcwh() {
    return jcwh;
  }

  public String getJlx() {
    return jlx;
  }

  public String getMlph() {
    return mlph;
  }

  public Long getMlpnbid() {
    return mlpnbid;
  }

  public String getMlxz() {
    return mlxz;
  }

  public String getMz() {
    return mz;
  }

  public String getPxh() {
    return pxh;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public void setPxh(String pxh) {
    this.pxh = pxh;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public void setMlpnbid(Long mlpnbid) {
    this.mlpnbid = mlpnbid;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getSsxq() {
    return ssxq;
  }

  public String getXb() {
    return xb;
  }

  public String getXm() {
    return xm;
  }

  public String getXzjd() {
    return xzjd;
  }

  public String getZrq() {
    return zrq;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getPcs() {
    return pcs;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public Long getCzsm() {
    return czsm;
  }

  public void setCzsm(Long czsm) {
    this.czsm = czsm;
  }

  public String getHzgmsfhm() {
    return hzgmsfhm;
  }

  public void setHzgmsfhm(String hzgmsfhm) {
    this.hzgmsfhm = hzgmsfhm;
  }

  public String getHzxm() {
    return hzxm;
  }

  public void setHzxm(String hzxm) {
    this.hzxm = hzxm;
  }

  public String getYhzgx() {
    return yhzgx;
  }

  public void setYhzgx(String yhzgx) {
    this.yhzgx = yhzgx;
  }

  public String getYwlx() {
    return ywlx;
  }

  public void setYwlx(String ywlx) {
    this.ywlx = ywlx;
  }

  public Long getHhid() {
    return hhid;
  }

  public void setHhid(Long hhid) {
    this.hhid = hhid;
  }

  public Long getMlpid() {
    return mlpid;
  }

  public void setMlpid(Long mlpid) {
    this.mlpid = mlpid;
  }

  public String getHjscsm() {
    return hjscsm;
  }

  public void setHjscsm(String hjscsm) {
    this.hjscsm = hjscsm;
  }


}
