package  com.hzjc.hz2004.po;

public class PoXT_JSYWBBQXB implements com.hzjc.wsstruts.po.PO
{
  private Long ywbbqxid;
  private Long jsid;
  private Long ywbbid;

  public void setYwbbqxid(Long ywbbqxid) {
    this.ywbbqxid = ywbbqxid;
  }

  public Long getYwbbqxid() {
    return ywbbqxid;
  }

  public void setJsid(Long jsid) {
    this.jsid = jsid;
  }

  public Long getJsid() {
    return jsid;
  }

  public void setYwbbid(Long ywbbid) {
    this.ywbbid = ywbbid;
  }

  public Long getYwbbid() {
    return ywbbid;
  }

}
