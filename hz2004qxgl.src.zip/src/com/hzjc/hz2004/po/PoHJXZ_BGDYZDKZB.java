package  com.hzjc.hz2004.po;

public class PoHJXZ_BGDYZDKZB implements com.hzjc.wsstruts.po.PO
{
  private Long zdkzid;
  private String zdmc;
  private String zdhy;
  private String kzbz;

  public void setZdkzid(Long zdkzid) {
    this.zdkzid = zdkzid;
  }

  public Long getZdkzid() {
    return zdkzid;
  }

  public void setZdmc(String zdmc) {
    this.zdmc = zdmc;
  }

  public String getZdmc() {
    return zdmc;
  }

  public void setZdhy(String zdhy) {
    this.zdhy = zdhy;
  }

  public String getZdhy() {
    return zdhy;
  }

  public void setKzbz(String kzbz) {
    this.kzbz = kzbz;
  }

  public String getKzbz() {
    return kzbz;
  }

}
