package com.hzjc.hz2004.po;

public class PoHZSMK_DKRZ
    implements com.hzjc.wsstruts.po.PO {

  private Long dkrzid;  //������־ID
  private String kdsbm;  //����ʶ����
  private String kdlb;  //�������
  private String gfbb;  //�淶�汾
  private String cshjgdm;  //��ʼ����������
  private String fkrq;  //��������
  private String kyxq;  //����Ч��
  private String kh;  //����
  private String gmsfhm;  //��������֤
  private String xm;  //����
  private String xb;  //�Ա�
  private String mz;  //����
  private String csrq;  //��������
  private String csdssxq;  //������
  private String szcsdm;  //���ڳ��д���
  private String hb;  //�������
  private String czhkszd;  //��ס�������ڵ�
  private String yzbm;  //��������
  private String txdz;  //ͨѶ��ַ
  private String lxdh;  //��ϵ�绰
  private String whcd;  //�Ļ��̶�
  private String hyzk;  //����״��
  private Long czyid;  //����ԱID
  private String dkjqipdz;  //��������IP��ַ
  private String dksj;  //����ʱ��

  public void setDkrzid(Long dkrzid) {
    this.dkrzid = dkrzid;
  }

  public Long getDkrzid() {
    return dkrzid;
  }

  public void setKdsbm(String kdsbm) {
    this.kdsbm = kdsbm;
  }

  public String getKdsbm() {
    return kdsbm;
  }

  public void setKdlb(String kdlb) {
    this.kdlb = kdlb;
  }

  public String getKdlb() {
    return kdlb;
  }

  public void setGfbb(String gfbb) {
    this.gfbb = gfbb;
  }

  public String getGfbb() {
    return gfbb;
  }

  public void setCshjgdm(String cshjgdm) {
    this.cshjgdm = cshjgdm;
  }

  public String getCshjgdm() {
    return cshjgdm;
  }

  public void setFkrq(String fkrq) {
    this.fkrq = fkrq;
  }

  public String getFkrq() {
    return fkrq;
  }

  public void setKyxq(String kyxq) {
    this.kyxq = kyxq;
  }

  public String getKyxq() {
    return kyxq;
  }

  public void setKh(String kh) {
    this.kh = kh;
  }

  public String getKh() {
    return kh;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public String getXb() {
    return xb;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public String getMz() {
    return mz;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public String getCsrq() {
    return csrq;
  }

  public void setCsdssxq(String csdssxq) {
    this.csdssxq = csdssxq;
  }

  public String getCsdssxq() {
    return csdssxq;
  }

  public void setSzcsdm(String szcsdm) {
    this.szcsdm = szcsdm;
  }

  public String getSzcsdm() {
    return szcsdm;
  }

  public void setHb(String hb) {
    this.hb = hb;
  }

  public String getHb() {
    return hb;
  }

  public void setCzhkszd(String czhkszd) {
    this.czhkszd = czhkszd;
  }

  public String getCzhkszd() {
    return czhkszd;
  }

  public void setYzbm(String yzbm) {
    this.yzbm = yzbm;
  }

  public String getYzbm() {
    return yzbm;
  }

  public void setTxdz(String txdz) {
    this.txdz = txdz;
  }

  public String getTxdz() {
    return txdz;
  }

  public void setLxdh(String lxdh) {
    this.lxdh = lxdh;
  }

  public String getLxdh() {
    return lxdh;
  }

  public void setWhcd(String whcd) {
    this.whcd = whcd;
  }

  public String getWhcd() {
    return whcd;
  }

  public void setHyzk(String hyzk) {
    this.hyzk = hyzk;
  }

  public String getHyzk() {
    return hyzk;
  }

  public void setCzyid(Long czyid) {
    this.czyid = czyid;
  }

  public Long getCzyid() {
    return czyid;
  }

  public void setDkjqipdz(String dkjqipdz) {
    this.dkjqipdz = dkjqipdz;
  }

  public String getDkjqipdz() {
    return dkjqipdz;
  }

  public void setDksj(String dksj) {
    this.dksj = dksj;
  }

  public String getDksj() {
    return dksj;
  }

}
