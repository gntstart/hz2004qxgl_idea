package  com.hzjc.hz2004.po;

public class PoLSSFZ_DYXXB implements com.hzjc.wsstruts.po.PO
{
  private Long lsdyid;
  private Long lsslid;
  private Long ryid;
  private String lsjmsfzkh;
  private Long czyid;
  private String czsj;
  private String czyip;

  public void setLsdyid(Long lsdyid) {
    this.lsdyid = lsdyid;
  }

  public Long getLsdyid() {
    return lsdyid;
  }

  public void setLsslid(Long lsslid) {
    this.lsslid = lsslid;
  }

  public Long getLsslid() {
    return lsslid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setLsjmsfzkh(String lsjmsfzkh) {
    this.lsjmsfzkh = lsjmsfzkh;
  }

  public String getLsjmsfzkh() {
    return lsjmsfzkh;
  }

  public void setCzyid(Long czyid) {
    this.czyid = czyid;
  }

  public Long getCzyid() {
    return czyid;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

  public void setCzyip(String czyip) {
    this.czyip = czyip;
  }

  public String getCzyip() {
    return czyip;
  }

}
