package  com.hzjc.hz2004.po;

public class PoXT_SPMBXXB implements com.hzjc.wsstruts.po.PO
{
  private Long spmbid;
  private String mbmc;
  private String mbdj;
  private Long cjrid;
  private String cjsj;
  private Long xgrid;
  private String xgsj;
  private String qybz;
  private String dqsys;

  public void setSpmbid(Long spmbid) {
    this.spmbid = spmbid;
  }

  public Long getSpmbid() {
    return spmbid;
  }

  public void setMbmc(String mbmc) {
    this.mbmc = mbmc;
  }

  public String getMbmc() {
    return mbmc;
  }

  public void setMbdj(String mbdj) {
    this.mbdj = mbdj;
  }

  public String getMbdj() {
    return mbdj;
  }

  public void setCjrid(Long cjrid) {
    this.cjrid = cjrid;
  }

  public Long getCjrid() {
    return cjrid;
  }

  public void setCjsj(String cjsj) {
    this.cjsj = cjsj;
  }

  public String getCjsj() {
    return cjsj;
  }

  public void setXgrid(Long xgrid) {
    this.xgrid = xgrid;
  }

  public Long getXgrid() {
    return xgrid;
  }

  public void setXgsj(String xgsj) {
    this.xgsj = xgsj;
  }

  public String getXgsj() {
    return xgsj;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

  public void setDqsys(String dqsys) {
    this.dqsys = dqsys;
  }

  public String getDqsys() {
    return dqsys;
  }

}
