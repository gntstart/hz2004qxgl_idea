package  com.hzjc.hz2004.po;

public class PoXT_JSZSBBQXB implements com.hzjc.wsstruts.po.PO
{
  private Long zsbbqxid;
  private Long jsid;
  private Long zsbbmbid;

  public void setZsbbqxid(Long zsbbqxid) {
    this.zsbbqxid = zsbbqxid;
  }

  public Long getZsbbqxid() {
    return zsbbqxid;
  }

  public void setJsid(Long jsid) {
    this.jsid = jsid;
  }

  public Long getJsid() {
    return jsid;
  }

  public void setZsbbmbid(Long zsbbmbid) {
    this.zsbbmbid = zsbbmbid;
  }

  public Long getZsbbmbid() {
    return zsbbmbid;
  }

}
