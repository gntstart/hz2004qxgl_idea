package com.hzjc.hz2004.po;

public class PoHJXZ_GBRYXZB
    implements com.hzjc.wsstruts.po.PO {
  private Long gbryid;
  private Long rynbid;
  private Long ryid;
  private String gmsfhm;
  private String xm;
  private String dw;
  private String zw;
  private Long djrid;
  private String djsj;

  public void setGbryid(Long gbryid) {
    this.gbryid = gbryid;
  }

  public Long getGbryid() {
    return gbryid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setDw(String dw) {
    this.dw = dw;
  }

  public String getDw() {
    return dw;
  }

  public void setZw(String zw) {
    this.zw = zw;
  }

  public String getZw() {
    return zw;
  }

  public void setDjrid(Long djrid) {
    this.djrid = djrid;
  }

  public Long getDjrid() {
    return djrid;
  }

  public void setDjsj(String djsj) {
    this.djsj = djsj;
  }

  public String getDjsj() {
    return djsj;
  }
}
