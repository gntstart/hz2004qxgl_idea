package com.hzjc.hz2004.po;

public class PoHJSP_HJSPSQB
    implements com.hzjc.wsstruts.po.PO {
  private String sqrgmsfhm;
  private Long spmbid;
  private String sqrxm;
  private String sqrzzssxq;
  private Long spywid;
  private String splx;
  private String slrq;
  private String xm;
  private Long ryid;
  private String xb;
  private String gmsfhm;
  private String csrq;
  private String mz;
  private String jhny;
  private String yjrclx;
  private String yrdwjcyrysj;
  private String lxdh;
  private String byxx;
  private String whcd;
  private String bysj;
  private String zyzl;
  private String byzsh;
  private String zyjszc;
  private String jszsh;
  private String jsfzjg;
  private String fmzlmc;
  private String fmzlh;
  private String zlfzjg;
  private String hb;
  private String qrhhb; //Ǩ��󻧱�
  private String zzssxq;
  private String zzxz;
  private String hkszddjjg;
  private String qrdqx;
  private String qrdpcs;
  private String qrdjwzrq;
  private String qrdxzjd;
  private String qrdjwh;
  private String qrdjlx;
  private String qrdmlph;
  private String qrdz;
  private String qrdhkdjjg;
  private Long qrdhhid;
  private String qrdhlx;
  private String rlhbz;
  private String sqqrly;
  private String sqrzzxz;
  private String bz;
  private Long djrid;
  private String djsj;
  private Long xydzid;
  private String spjg;
  private String sqrhkdjjg;
  private String lsbz;
  private Long rynbid;
  private Long hjywid;
  private String ysqrgx;
  private String spsm;
  private String bzdz;
  private String bzdzid;
  private String bzdzx;
  private String bzdzy;
  private String bzdzst;
  private String cxfldm;
  private String nyzyrklhczyydm;
  private String kdqqy_qcdqbm;
  private String kdqqy_qchjywid;
  
  public String getKdqqy_qcdqbm() {
	return kdqqy_qcdqbm;
}
public void setKdqqy_qcdqbm(String kdqqy_qcdqbm) {
	this.kdqqy_qcdqbm = kdqqy_qcdqbm;
}
public String getKdqqy_qchjywid() {
	return kdqqy_qchjywid;
}
public void setKdqqy_qchjywid(String kdqqy_qchjywid) {
	this.kdqqy_qchjywid = kdqqy_qchjywid;
}
public String getBzdzst() {
  return bzdzst;
 }
 public void setBzdzst(String bzdzst) {
   this.bzdzst = bzdzst;
 }

  public String getBzdzy() {
  return bzdzy;
 }
 public void setBzdzy(String bzdzy) {
   this.bzdzy = bzdzy;
 }

  public String getBzdzx() {
  return bzdzx;
 }
 public void setBzdzx(String bzdzx) {
   this.bzdzx = bzdzx;
 }

  public void setBzdz(String bzdz) {
    this.bzdz = bzdz;
  }

  public String getBzdz() {
    return bzdz;
  }

  public void setBzdzid(String bzdzid) {
    this.bzdzid = bzdzid;
  }

  public String getBzdzid() {
    return bzdzid;
  }
  public void setSqrgmsfhm(String sqrgmsfhm) {
    this.sqrgmsfhm = sqrgmsfhm;
  }

  public String getSqrgmsfhm() {
    return sqrgmsfhm;
  }

  public void setSpmbid(Long spmbid) {
    this.spmbid = spmbid;
  }

  public Long getSpmbid() {
    return spmbid;
  }

  public void setSqrxm(String sqrxm) {
    this.sqrxm = sqrxm;
  }

  public String getSqrxm() {
    return sqrxm;
  }

  public void setSqrzzssxq(String sqrzzssxq) {
    this.sqrzzssxq = sqrzzssxq;
  }

  public String getSqrzzssxq() {
    return sqrzzssxq;
  }

  public void setSpywid(Long spywid) {
    this.spywid = spywid;
  }

  public Long getSpywid() {
    return spywid;
  }

  public void setSplx(String splx) {
    this.splx = splx;
  }

  public String getSplx() {
    return splx;
  }

  public void setSlrq(String slrq) {
    this.slrq = slrq;
  }

  public String getSlrq() {
    return slrq;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public String getXb() {
    return xb;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public String getCsrq() {
    return csrq;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public String getMz() {
    return mz;
  }

  public void setJhny(String jhny) {
    this.jhny = jhny;
  }

  public String getJhny() {
    return jhny;
  }

  public void setYjrclx(String yjrclx) {
    this.yjrclx = yjrclx;
  }

  public String getYjrclx() {
    return yjrclx;
  }

  public void setYrdwjcyrysj(String yrdwjcyrysj) {
    this.yrdwjcyrysj = yrdwjcyrysj;
  }

  public String getYrdwjcyrysj() {
    return yrdwjcyrysj;
  }

  public void setLxdh(String lxdh) {
    this.lxdh = lxdh;
  }

  public String getLxdh() {
    return lxdh;
  }

  public void setByxx(String byxx) {
    this.byxx = byxx;
  }

  public String getByxx() {
    return byxx;
  }

  public void setWhcd(String whcd) {
    this.whcd = whcd;
  }

  public String getWhcd() {
    return whcd;
  }

  public void setBysj(String bysj) {
    this.bysj = bysj;
  }

  public String getBysj() {
    return bysj;
  }

  public void setZyzl(String zyzl) {
    this.zyzl = zyzl;
  }

  public String getZyzl() {
    return zyzl;
  }

  public void setByzsh(String byzsh) {
    this.byzsh = byzsh;
  }

  public String getByzsh() {
    return byzsh;
  }

  public void setZyjszc(String zyjszc) {
    this.zyjszc = zyjszc;
  }

  public String getZyjszc() {
    return zyjszc;
  }

  public void setJszsh(String jszsh) {
    this.jszsh = jszsh;
  }

  public String getJszsh() {
    return jszsh;
  }

  public void setJsfzjg(String jsfzjg) {
    this.jsfzjg = jsfzjg;
  }

  public String getJsfzjg() {
    return jsfzjg;
  }

  public void setFmzlmc(String fmzlmc) {
    this.fmzlmc = fmzlmc;
  }

  public String getFmzlmc() {
    return fmzlmc;
  }

  public void setFmzlh(String fmzlh) {
    this.fmzlh = fmzlh;
  }

  public String getFmzlh() {
    return fmzlh;
  }

  public void setZlfzjg(String zlfzjg) {
    this.zlfzjg = zlfzjg;
  }

  public String getZlfzjg() {
    return zlfzjg;
  }

  public void setHb(String hb) {
    this.hb = hb;
  }

  public String getHb() {
    return hb;
  }

  public void setZzssxq(String zzssxq) {
    this.zzssxq = zzssxq;
  }

  public String getZzssxq() {
    return zzssxq;
  }

  public void setZzxz(String zzxz) {
    this.zzxz = zzxz;
  }

  public String getZzxz() {
    return zzxz;
  }

  public void setHkszddjjg(String hkszddjjg) {
    this.hkszddjjg = hkszddjjg;
  }

  public String getHkszddjjg() {
    return hkszddjjg;
  }

  public void setQrdqx(String qrdqx) {
    this.qrdqx = qrdqx;
  }

  public String getQrdqx() {
    return qrdqx;
  }

  public void setQrdpcs(String qrdpcs) {
    this.qrdpcs = qrdpcs;
  }

  public String getQrdpcs() {
    return qrdpcs;
  }

  public void setQrdjwzrq(String qrdjwzrq) {
    this.qrdjwzrq = qrdjwzrq;
  }

  public String getQrdjwzrq() {
    return qrdjwzrq;
  }

  public void setQrdxzjd(String qrdxzjd) {
    this.qrdxzjd = qrdxzjd;
  }

  public String getQrdxzjd() {
    return qrdxzjd;
  }

  public void setQrdjwh(String qrdjwh) {
    this.qrdjwh = qrdjwh;
  }

  public String getQrdjwh() {
    return qrdjwh;
  }

  public void setQrdjlx(String qrdjlx) {
    this.qrdjlx = qrdjlx;
  }

  public String getQrdjlx() {
    return qrdjlx;
  }

  public void setQrdmlph(String qrdmlph) {
    this.qrdmlph = qrdmlph;
  }

  public String getQrdmlph() {
    return qrdmlph;
  }

  public void setQrdz(String qrdz) {
    this.qrdz = qrdz;
  }

  public String getQrdz() {
    return qrdz;
  }

  public void setQrdhkdjjg(String qrdhkdjjg) {
    this.qrdhkdjjg = qrdhkdjjg;
  }

  public String getQrdhkdjjg() {
    return qrdhkdjjg;
  }

  public void setQrdhhid(Long qrdhhid) {
    this.qrdhhid = qrdhhid;
  }

  public Long getQrdhhid() {
    return qrdhhid;
  }

  public void setQrdhlx(String qrdhlx) {
    this.qrdhlx = qrdhlx;
  }

  public String getQrdhlx() {
    return qrdhlx;
  }

  public void setRlhbz(String rlhbz) {
    this.rlhbz = rlhbz;
  }

  public String getRlhbz() {
    return rlhbz;
  }

  public void setSqqrly(String sqqrly) {
    this.sqqrly = sqqrly;
  }

  public String getSqqrly() {
    return sqqrly;
  }

  public void setSqrzzxz(String sqrzzxz) {
    this.sqrzzxz = sqrzzxz;
  }

  public String getSqrzzxz() {
    return sqrzzxz;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setDjrid(Long djrid) {
    this.djrid = djrid;
  }

  public Long getDjrid() {
    return djrid;
  }

  public void setDjsj(String djsj) {
    this.djsj = djsj;
  }

  public String getDjsj() {
    return djsj;
  }

  public void setXydzid(Long xydzid) {
    this.xydzid = xydzid;
  }

  public Long getXydzid() {
    return xydzid;
  }

  public void setSpjg(String spjg) {
    this.spjg = spjg;
  }

  public String getSpjg() {
    return spjg;
  }

  public void setSqrhkdjjg(String sqrhkdjjg) {
    this.sqrhkdjjg = sqrhkdjjg;
  }

  public String getSqrhkdjjg() {
    return sqrhkdjjg;
  }

  public void setLsbz(String lsbz) {
    this.lsbz = lsbz;
  }

  public String getLsbz() {
    return lsbz;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public String getYsqrgx() {
    return ysqrgx;
  }

  public void setYsqrgx(String ysqrgx) {
    this.ysqrgx = ysqrgx;
  }

  public String getSpsm() {
    return spsm;
  }

  public void setSpsm(String spsm) {
    this.spsm = spsm;
  }

  public String getQrhhb() {
    return qrhhb;
  }

  public String getCxfldm() {
    return cxfldm;
  }

  public String getNyzyrklhczyydm() {
    return nyzyrklhczyydm;
  }

  public void setQrhhb(String qrhhb) {
    this.qrhhb = qrhhb;
  }

  public void setCxfldm(String cxfldm) {
    this.cxfldm = cxfldm;
  }

  public void setNyzyrklhczyydm(String nyzyrklhczyydm) {
    this.nyzyrklhczyydm = nyzyrklhczyydm;
  }

}
