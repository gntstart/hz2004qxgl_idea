package  com.hzjc.hz2004.po;

public class PoDZZJ_SBXXB implements com.hzjc.wsstruts.po.PO
{
  private String sbglh;
  private String dwdm;
  private String zcsj;
  private String zxsj;
  private String sbzt;
  private String sbid;

  public void setSbglh(String sbglh) {
    this.sbglh = sbglh;
  }

  public String getSbglh() {
    return sbglh;
  }

  public void setDwdm(String dwdm) {
    this.dwdm = dwdm;
  }

  public String getDwdm() {
    return dwdm;
  }

  public void setZcsj(String zcsj) {
    this.zcsj = zcsj;
  }

  public String getZcsj() {
    return zcsj;
  }

  public void setZxsj(String zxsj) {
    this.zxsj = zxsj;
  }

  public String getZxsj() {
    return zxsj;
  }

  public void setSbzt(String sbzt) {
    this.sbzt = sbzt;
  }

  public String getSbzt() {
    return sbzt;
  }
  public String getSbid() {
    return sbid;
  }
  public void setSbid(String sbid) {
    this.sbid = sbid;
  }

}
