package  com.hzjc.hz2004.po;

public class PoXT_PYFHB implements com.hzjc.wsstruts.po.PO
{
  private Long fhid;
  private String hz;
  private String py;
  private String nm;

  public void setFhid(Long fhid) {
    this.fhid = fhid;
  }

  public Long getFhid() {
    return fhid;
  }

  public void setHz(String hz) {
    this.hz = hz;
  }

  public String getHz() {
    return hz;
  }

  public void setPy(String py) {
    this.py = py;
  }

  public String getPy() {
    return py;
  }

  public void setNm(String nm) {
    this.nm = nm;
  }

  public String getNm() {
    return nm;
  }

}
