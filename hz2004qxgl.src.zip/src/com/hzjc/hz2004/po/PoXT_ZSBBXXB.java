package  com.hzjc.hz2004.po;

public class PoXT_ZSBBXXB implements com.hzjc.wsstruts.po.PO
{
  private Long zsbbid;
  private Long zsbbmbid;
  private String bbmc;
  private byte[] bbsjmb;
  private String jlsj;
  private Long scrid;
  private String xgsj;
  private Long xgrid;

  public void setZsbbid(Long zsbbid) {
    this.zsbbid = zsbbid;
  }

  public Long getZsbbid() {
    return zsbbid;
  }

  public void setZsbbmbid(Long zsbbmbid) {
    this.zsbbmbid = zsbbmbid;
  }

  public Long getZsbbmbid() {
    return zsbbmbid;
  }

  public void setBbmc(String bbmc) {
    this.bbmc = bbmc;
  }

  public String getBbmc() {
    return bbmc;
  }

  public void setBbsjmb(byte[] bbsjmb) {
    this.bbsjmb = bbsjmb;
  }

  public byte[] getBbsjmb() {
    return bbsjmb;
  }

  public void setJlsj(String jlsj) {
    this.jlsj = jlsj;
  }

  public String getJlsj() {
    return jlsj;
  }

  public void setScrid(Long scrid) {
    this.scrid = scrid;
  }

  public Long getScrid() {
    return scrid;
  }

  public void setXgsj(String xgsj) {
    this.xgsj = xgsj;
  }

  public String getXgsj() {
    return xgsj;
  }

  public void setXgrid(Long xgrid) {
    this.xgrid = xgrid;
  }

  public Long getXgrid() {
    return xgrid;
  }

}
