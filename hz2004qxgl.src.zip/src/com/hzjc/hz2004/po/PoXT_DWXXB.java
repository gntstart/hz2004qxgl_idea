package  com.hzjc.hz2004.po;

public class PoXT_DWXXB implements com.hzjc.wsstruts.po.PO
{
  private String dm;
  private String mc;
  private String zwpy;
  private String wbpy;
  private String dwjgdm;
  private String qhdm;
  private String dwjb;
  private String bz;
  private String qybz;
  private String bdlx;
  private String bdsj;
  private String fjjgdm;
  private String fjjgmc;

  public void setDm(String dm) {
    this.dm = dm;
  }

  public String getDm() {
    return dm;
  }

  public void setMc(String mc) {
    this.mc = mc;
  }

  public String getMc() {
    return mc;
  }

  public void setZwpy(String zwpy) {
    this.zwpy = zwpy;
  }

  public String getZwpy() {
    return zwpy;
  }

  public void setWbpy(String wbpy) {
    this.wbpy = wbpy;
  }

  public String getWbpy() {
    return wbpy;
  }

  public void setDwjgdm(String dwjgdm) {
    this.dwjgdm = dwjgdm;
  }

  public String getDwjgdm() {
    return dwjgdm;
  }

  public void setQhdm(String qhdm) {
    this.qhdm = qhdm;
  }

  public String getQhdm() {
    return qhdm;
  }

  public void setDwjb(String dwjb) {
    this.dwjb = dwjb;
  }

  public String getDwjb() {
    return dwjb;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

  public void setBdlx(String bdlx) {
    this.bdlx = bdlx;
  }

  public String getBdlx() {
    return bdlx;
  }

  public void setBdsj(String bdsj) {
    this.bdsj = bdsj;
  }

  public String getBdsj() {
    return bdsj;
  }
  public String getFjjgdm() {
    return fjjgdm;
  }
  public void setFjjgdm(String fjjgdm) {
    this.fjjgdm = fjjgdm;
  }
  public String getFjjgmc() {
    return fjjgmc;
  }
  public void setFjjgmc(String fjjgmc) {
    this.fjjgmc = fjjgmc;
  }

}
