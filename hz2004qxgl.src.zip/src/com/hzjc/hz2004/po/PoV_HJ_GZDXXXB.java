package com.hzjc.hz2004.po;

public class PoV_HJ_GZDXXXB
    implements com.hzjc.wsstruts.po.PO {

  private String rybh;
  private String gmsfhm;
  private String xm;

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getRybh() {
    return rybh;
  }

  public void setRybh(String rybh) {
    this.rybh = rybh;
  }

  public String getXm() {
    return xm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }
}