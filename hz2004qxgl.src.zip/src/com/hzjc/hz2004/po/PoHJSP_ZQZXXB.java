package  com.hzjc.hz2004.po;

public class PoHJSP_ZQZXXB implements com.hzjc.wsstruts.po.PO
{
  private String qfrq;
  private String qyrs;
  private Long zqid;
  private String sqrgmsfhm;
  private String sqrxm;
  private String sqrzzssxq;
  private String sqrzzxz;
  private String sqrhkdjjg;
  private String qyrysqrgx1;
  private String qyrxm1;
  private String qyrxb1;
  private String qyrcsrq1;
  private String qyrgmsfhm1;
  private String qyrysqrgx2;
  private String qyrxm2;
  private String qyrxb2;
  private String qyrcsrq2;
  private String qyrgmsfhm2;
  private String qyrysqrgx3;
  private String qyrxm3;
  private String qyrxb3;
  private String qyrcsrq3;
  private String qyrgmsfhm3;
  private String qyrysqrgx4;
  private String qyrxm4;
  private String qyrxb4;
  private String qyrcsrq4;
  private String qyrgmsfhm4;
  private String qyrhkdjjg;
  private String qyrzzssxq;
  private String qyrzzxz;
  private String qrdssxq;
  private String qrdxz;
  private String qrdhkdjjg;
  private String zqyy;
  private String pzjg;
  private String cbr;
  private String bz;
  private Long spywid;
  private String zqzjlx;
  private String zjbh;

  public void setQfrq(String qfrq) {
    this.qfrq = qfrq;
  }

  public String getQfrq() {
    return qfrq;
  }

  public void setQyrs(String qyrs) {
    this.qyrs = qyrs;
  }

  public String getQyrs() {
    return qyrs;
  }

  public void setZqid(Long zqid) {
    this.zqid = zqid;
  }

  public Long getZqid() {
    return zqid;
  }

  public void setSqrgmsfhm(String sqrgmsfhm) {
    this.sqrgmsfhm = sqrgmsfhm;
  }

  public String getSqrgmsfhm() {
    return sqrgmsfhm;
  }

  public void setSqrxm(String sqrxm) {
    this.sqrxm = sqrxm;
  }

  public String getSqrxm() {
    return sqrxm;
  }

  public void setSqrzzssxq(String sqrzzssxq) {
    this.sqrzzssxq = sqrzzssxq;
  }

  public String getSqrzzssxq() {
    return sqrzzssxq;
  }

  public void setSqrzzxz(String sqrzzxz) {
    this.sqrzzxz = sqrzzxz;
  }

  public String getSqrzzxz() {
    return sqrzzxz;
  }

  public void setSqrhkdjjg(String sqrhkdjjg) {
    this.sqrhkdjjg = sqrhkdjjg;
  }

  public String getSqrhkdjjg() {
    return sqrhkdjjg;
  }

  public void setQyrysqrgx1(String qyrysqrgx1) {
    this.qyrysqrgx1 = qyrysqrgx1;
  }

  public String getQyrysqrgx1() {
    return qyrysqrgx1;
  }

  public void setQyrxm1(String qyrxm1) {
    this.qyrxm1 = qyrxm1;
  }

  public String getQyrxm1() {
    return qyrxm1;
  }

  public void setQyrxb1(String qyrxb1) {
    this.qyrxb1 = qyrxb1;
  }

  public String getQyrxb1() {
    return qyrxb1;
  }

  public void setQyrcsrq1(String qyrcsrq1) {
    this.qyrcsrq1 = qyrcsrq1;
  }

  public String getQyrcsrq1() {
    return qyrcsrq1;
  }

  public void setQyrgmsfhm1(String qyrgmsfhm1) {
    this.qyrgmsfhm1 = qyrgmsfhm1;
  }

  public String getQyrgmsfhm1() {
    return qyrgmsfhm1;
  }

  public void setQyrysqrgx2(String qyrysqrgx2) {
    this.qyrysqrgx2 = qyrysqrgx2;
  }

  public String getQyrysqrgx2() {
    return qyrysqrgx2;
  }

  public void setQyrxm2(String qyrxm2) {
    this.qyrxm2 = qyrxm2;
  }

  public String getQyrxm2() {
    return qyrxm2;
  }

  public void setQyrxb2(String qyrxb2) {
    this.qyrxb2 = qyrxb2;
  }

  public String getQyrxb2() {
    return qyrxb2;
  }

  public void setQyrcsrq2(String qyrcsrq2) {
    this.qyrcsrq2 = qyrcsrq2;
  }

  public String getQyrcsrq2() {
    return qyrcsrq2;
  }

  public void setQyrgmsfhm2(String qyrgmsfhm2) {
    this.qyrgmsfhm2 = qyrgmsfhm2;
  }

  public String getQyrgmsfhm2() {
    return qyrgmsfhm2;
  }

  public void setQyrysqrgx3(String qyrysqrgx3) {
    this.qyrysqrgx3 = qyrysqrgx3;
  }

  public String getQyrysqrgx3() {
    return qyrysqrgx3;
  }

  public void setQyrxm3(String qyrxm3) {
    this.qyrxm3 = qyrxm3;
  }

  public String getQyrxm3() {
    return qyrxm3;
  }

  public void setQyrxb3(String qyrxb3) {
    this.qyrxb3 = qyrxb3;
  }

  public String getQyrxb3() {
    return qyrxb3;
  }

  public void setQyrcsrq3(String qyrcsrq3) {
    this.qyrcsrq3 = qyrcsrq3;
  }

  public String getQyrcsrq3() {
    return qyrcsrq3;
  }

  public void setQyrgmsfhm3(String qyrgmsfhm3) {
    this.qyrgmsfhm3 = qyrgmsfhm3;
  }

  public String getQyrgmsfhm3() {
    return qyrgmsfhm3;
  }

  public void setQyrysqrgx4(String qyrysqrgx4) {
    this.qyrysqrgx4 = qyrysqrgx4;
  }

  public String getQyrysqrgx4() {
    return qyrysqrgx4;
  }

  public void setQyrxm4(String qyrxm4) {
    this.qyrxm4 = qyrxm4;
  }

  public String getQyrxm4() {
    return qyrxm4;
  }

  public void setQyrxb4(String qyrxb4) {
    this.qyrxb4 = qyrxb4;
  }

  public String getQyrxb4() {
    return qyrxb4;
  }

  public void setQyrcsrq4(String qyrcsrq4) {
    this.qyrcsrq4 = qyrcsrq4;
  }

  public String getQyrcsrq4() {
    return qyrcsrq4;
  }

  public void setQyrgmsfhm4(String qyrgmsfhm4) {
    this.qyrgmsfhm4 = qyrgmsfhm4;
  }

  public String getQyrgmsfhm4() {
    return qyrgmsfhm4;
  }

  public void setQyrhkdjjg(String qyrhkdjjg) {
    this.qyrhkdjjg = qyrhkdjjg;
  }

  public String getQyrhkdjjg() {
    return qyrhkdjjg;
  }

  public void setQyrzzssxq(String qyrzzssxq) {
    this.qyrzzssxq = qyrzzssxq;
  }

  public String getQyrzzssxq() {
    return qyrzzssxq;
  }

  public void setQyrzzxz(String qyrzzxz) {
    this.qyrzzxz = qyrzzxz;
  }

  public String getQyrzzxz() {
    return qyrzzxz;
  }

  public void setQrdssxq(String qrdssxq) {
    this.qrdssxq = qrdssxq;
  }

  public String getQrdssxq() {
    return qrdssxq;
  }

  public void setQrdxz(String qrdxz) {
    this.qrdxz = qrdxz;
  }

  public String getQrdxz() {
    return qrdxz;
  }

  public void setQrdhkdjjg(String qrdhkdjjg) {
    this.qrdhkdjjg = qrdhkdjjg;
  }

  public String getQrdhkdjjg() {
    return qrdhkdjjg;
  }

  public void setZqyy(String zqyy) {
    this.zqyy = zqyy;
  }

  public String getZqyy() {
    return zqyy;
  }

  public void setPzjg(String pzjg) {
    this.pzjg = pzjg;
  }

  public String getPzjg() {
    return pzjg;
  }

  public void setCbr(String cbr) {
    this.cbr = cbr;
  }

  public String getCbr() {
    return cbr;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setSpywid(Long spywid) {
    this.spywid = spywid;
  }

  public Long getSpywid() {
    return spywid;
  }

  public void setZqzjlx(String zqzjlx) {
    this.zqzjlx = zqzjlx;
  }

  public String getZqzjlx() {
    return zqzjlx;
  }

  public void setZjbh(String zjbh) {
    this.zjbh = zjbh;
  }

  public String getZjbh() {
    return zjbh;
  }

}
