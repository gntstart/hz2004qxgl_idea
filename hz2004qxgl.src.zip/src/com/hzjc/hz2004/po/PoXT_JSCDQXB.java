package  com.hzjc.hz2004.po;

public class PoXT_JSCDQXB implements com.hzjc.wsstruts.po.PO
{
  private Long jscdid;
  private Long jsid;
  private Long gncdid;

  public void setJscdid(Long jscdid) {
    this.jscdid = jscdid;
  }

  public Long getJscdid() {
    return jscdid;
  }

  public void setJsid(Long jsid) {
    this.jsid = jsid;
  }

  public Long getJsid() {
    return jsid;
  }

  public void setGncdid(Long gncdid) {
    this.gncdid = gncdid;
  }

  public Long getGncdid() {
    return gncdid;
  }

}
