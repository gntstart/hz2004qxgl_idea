package  com.hzjc.hz2004.po;

public class PoHJXX_HGLGXB implements com.hzjc.wsstruts.po.PO
{
  private Long glid;
  private Long hhid;
  private Long glhhid;
  private String glgx;
  private String jljlsj;
  private Long jljlrid;
  private String zt;

  public void setGlid(Long glid) {
    this.glid = glid;
  }

  public Long getGlid() {
    return glid;
  }

  public void setHhid(Long hhid) {
    this.hhid = hhid;
  }

  public Long getHhid() {
    return hhid;
  }

  public void setGlhhid(Long glhhid) {
    this.glhhid = glhhid;
  }

  public Long getGlhhid() {
    return glhhid;
  }

  public void setGlgx(String glgx) {
    this.glgx = glgx;
  }

  public String getGlgx() {
    return glgx;
  }

  public void setJljlsj(String jljlsj) {
    this.jljlsj = jljlsj;
  }

  public String getJljlsj() {
    return jljlsj;
  }

  public void setJljlrid(Long jljlrid) {
    this.jljlrid = jljlrid;
  }

  public Long getJljlrid() {
    return jljlrid;
  }

  public void setZt(String zt) {
    this.zt = zt;
  }

  public String getZt() {
    return zt;
  }

}
