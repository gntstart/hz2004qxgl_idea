package com.hzjc.hz2004.po;

public class PoXT_LNWSDB
    implements com.hzjc.wsstruts.po.PO {
  private Long wsdid;
  private String qhdm;
  private String dwdm;
  private String ksd;
  private String jsd;
  private String qyrq;
  private String bz;
  private String xzjd;

  public void setWsdid(Long wsdid) {
    this.wsdid = wsdid;
  }

  public Long getWsdid() {
    return wsdid;
  }

  public void setQhdm(String qhdm) {
    this.qhdm = qhdm;
  }

  public String getQhdm() {
    return qhdm;
  }

  public void setDwdm(String dwdm) {
    this.dwdm = dwdm;
  }

  public String getDwdm() {
    return dwdm;
  }

  public void setKsd(String ksd) {
    this.ksd = ksd;
  }

  public String getKsd() {
    return ksd;
  }

  public void setJsd(String jsd) {
    this.jsd = jsd;
  }

  public String getJsd() {
    return jsd;
  }

  public void setQyrq(String qyrq) {
    this.qyrq = qyrq;
  }

  public String getQyrq() {
    return qyrq;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public String getXzjd() {
    return xzjd;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

}
