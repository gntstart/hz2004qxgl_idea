package  com.hzjc.hz2004.po;

public class PoDZZJ_CZRZB implements com.hzjc.wsstruts.po.PO
{
  private Long rzid;
  private String czsj;
  private Long czyid;
  private String czdz;
  private String czip;
  private Long bczyid;

  public void setRzid(Long rzid) {
    this.rzid = rzid;
  }

  public Long getRzid() {
    return rzid;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

  public void setCzyid(Long czyid) {
    this.czyid = czyid;
  }

  public Long getCzyid() {
    return czyid;
  }

  public void setCzdz(String czdz) {
    this.czdz = czdz;
  }

  public String getCzdz() {
    return czdz;
  }

  public void setCzip(String czip) {
    this.czip = czip;
  }

  public String getCzip() {
    return czip;
  }

  public void setBczyid(Long bczyid) {
    this.bczyid = bczyid;
  }

  public Long getBczyid() {
    return bczyid;
  }

}
