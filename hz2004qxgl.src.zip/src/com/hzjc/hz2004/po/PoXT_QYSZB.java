package  com.hzjc.hz2004.po;

public class PoXT_QYSZB implements com.hzjc.wsstruts.po.PO
{
  private Long qyid;
  private String qhdma;
  private String qhdmb;
  private String cjsj;
  private Long cjrid;
  private String xgsj;
  private Long xgrid;
  private String qybz;

  public void setQyid(Long qyid) {
    this.qyid = qyid;
  }

  public Long getQyid() {
    return qyid;
  }

  public void setQhdma(String qhdma) {
    this.qhdma = qhdma;
  }

  public String getQhdma() {
    return qhdma;
  }

  public void setQhdmb(String qhdmb) {
    this.qhdmb = qhdmb;
  }

  public String getQhdmb() {
    return qhdmb;
  }

  public void setCjsj(String cjsj) {
    this.cjsj = cjsj;
  }

  public String getCjsj() {
    return cjsj;
  }

  public void setCjrid(Long cjrid) {
    this.cjrid = cjrid;
  }

  public Long getCjrid() {
    return cjrid;
  }

  public void setXgsj(String xgsj) {
    this.xgsj = xgsj;
  }

  public String getXgsj() {
    return xgsj;
  }

  public void setXgrid(Long xgrid) {
    this.xgrid = xgrid;
  }

  public Long getXgrid() {
    return xgrid;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

}
