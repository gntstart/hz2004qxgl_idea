package com.hzjc.hz2004.po;

public class PoZJLS_SFZYWCZB
    implements com.hzjc.wsstruts.po.PO {
  private Long zjywid;
  private String slh;
  private String ywbz;
  private String slzt;
  private Long czyid;
  private String czyxm;
  private String czsj;
  private String czip;

  public void setZjywid(Long zjywid) {
    this.zjywid = zjywid;
  }

  public Long getZjywid() {
    return zjywid;
  }

  public void setSlh(String slh) {
    this.slh = slh;
  }

  public String getSlh() {
    return slh;
  }

  public void setYwbz(String ywbz) {
    this.ywbz = ywbz;
  }

  public String getYwbz() {
    return ywbz;
  }

  public void setSlzt(String slzt) {
    this.slzt = slzt;
  }

  public String getSlzt() {
    return slzt;
  }

  public void setCzyid(Long czyid) {
    this.czyid = czyid;
  }

  public Long getCzyid() {
    return czyid;
  }

  public void setCzyxm(String czyxm) {
    this.czyxm = czyxm;
  }

  public String getCzyxm() {
    return czyxm;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

  public String getCzip() {
    return czip;
  }

  public void setCzip(String czip) {
    this.czip = czip;
  }

}
