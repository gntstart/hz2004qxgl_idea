package  com.hzjc.hz2004.po;

public class PoOLD_HJYW_QRDJXXB implements com.hzjc.wsstruts.po.PO
{
  private Long qrdjid;
  private Long rynbid;
  private String qrqhb;
  private String qrlb;
  private String qrrq;
  private String qcdgjdq;
  private String qcdssxq;
  private String qcdpcs;
  private String qcdxzjd;
  private String qcdjwh;
  private String qcdjlx;
  private String qcdjwzrq;
  private String qcdmlph;
  private String qcdxz;
  private String qyzbh;
  private String zqzbh;
  private Long nbsfzid;
  private String bdfw;
  private Long hjywid;
  private String cxbz;
  private String cxsj;
  private Long cxrid;
  private Long cxhjywid;
  private Long tbbz;
  private String bwbh;
  private String sbsj;
  private String sbryxm;
  private String sbrgmsfhm;
  private String slsj;
  private String sldw;
  private Long slrid;
  private String ywlx;
  private Long czsm;
  private String jhryxm;
  private String jhrygmsfhm;
  private String jhryjhgx;
  private String jhrexm;
  private String jhregmsfhm;
  private String jhrejhgx;
  private String fqxm;
  private String fqgmsfhm;
  private String mqxm;
  private String mqgmsfhm;
  private String poxm;
  private String pogmsfhm;
  private String jggjdq;
  private String jgssxq;
  private String zjxy;
  private String whcd;
  private String hyzk;
  private String byzk;
  private String sg;
  private String xx;
  private String zy;
  private String zylb;
  private String fwcs;
  private String xxjb;
  private String zjlb;
  private String qfjg;
  private String yxqxqsrq;
  private String yxqxjzrq;
  private String dhhm;
  private String qtssxq;
  private String bz;
  private String qtzz;
  private String csdxz;
  private String csdgjdq;
  private String xm;
  private String cym;
  private String gmsfhm;
  private String mz;
  private String xb;
  private String csrq;
  private String cssj;
  private String csdssxq;
  private Long ryid;
  private Long hhnbid;
  private String ssxq;
  private String jlx;
  private String mlph;
  private String mlxz;
  private String pcs;
  private String zrq;
  private String xzjd;
  private String jcwh;
  private String pxh;
  private Long mlpnbid;
  private String yhzgx;
  private String hzxm;
  private String hzgmsfhm;
  private Long hhid;
  private Long mlpid;
  private String hb;

  public void setQrdjid(Long qrdjid) {
    this.qrdjid = qrdjid;
  }

  public Long getQrdjid() {
    return qrdjid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setQrqhb(String qrqhb) {
    this.qrqhb = qrqhb;
  }

  public String getQrqhb() {
    return qrqhb;
  }

  public void setQrlb(String qrlb) {
    this.qrlb = qrlb;
  }

  public String getQrlb() {
    return qrlb;
  }

  public void setQrrq(String qrrq) {
    this.qrrq = qrrq;
  }

  public String getQrrq() {
    return qrrq;
  }

  public void setQcdgjdq(String qcdgjdq) {
    this.qcdgjdq = qcdgjdq;
  }

  public String getQcdgjdq() {
    return qcdgjdq;
  }

  public void setQcdssxq(String qcdssxq) {
    this.qcdssxq = qcdssxq;
  }

  public String getQcdssxq() {
    return qcdssxq;
  }

  public void setQcdpcs(String qcdpcs) {
    this.qcdpcs = qcdpcs;
  }

  public String getQcdpcs() {
    return qcdpcs;
  }

  public void setQcdxzjd(String qcdxzjd) {
    this.qcdxzjd = qcdxzjd;
  }

  public String getQcdxzjd() {
    return qcdxzjd;
  }

  public void setQcdjwh(String qcdjwh) {
    this.qcdjwh = qcdjwh;
  }

  public String getQcdjwh() {
    return qcdjwh;
  }

  public void setQcdjlx(String qcdjlx) {
    this.qcdjlx = qcdjlx;
  }

  public String getQcdjlx() {
    return qcdjlx;
  }

  public void setQcdjwzrq(String qcdjwzrq) {
    this.qcdjwzrq = qcdjwzrq;
  }

  public String getQcdjwzrq() {
    return qcdjwzrq;
  }

  public void setQcdmlph(String qcdmlph) {
    this.qcdmlph = qcdmlph;
  }

  public String getQcdmlph() {
    return qcdmlph;
  }

  public void setQcdxz(String qcdxz) {
    this.qcdxz = qcdxz;
  }

  public String getQcdxz() {
    return qcdxz;
  }

  public void setQyzbh(String qyzbh) {
    this.qyzbh = qyzbh;
  }

  public String getQyzbh() {
    return qyzbh;
  }

  public void setZqzbh(String zqzbh) {
    this.zqzbh = zqzbh;
  }

  public String getZqzbh() {
    return zqzbh;
  }

  public void setNbsfzid(Long nbsfzid) {
    this.nbsfzid = nbsfzid;
  }

  public Long getNbsfzid() {
    return nbsfzid;
  }

  public void setBdfw(String bdfw) {
    this.bdfw = bdfw;
  }

  public String getBdfw() {
    return bdfw;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public void setCxbz(String cxbz) {
    this.cxbz = cxbz;
  }

  public String getCxbz() {
    return cxbz;
  }

  public void setCxsj(String cxsj) {
    this.cxsj = cxsj;
  }

  public String getCxsj() {
    return cxsj;
  }

  public void setCxrid(Long cxrid) {
    this.cxrid = cxrid;
  }

  public Long getCxrid() {
    return cxrid;
  }

  public void setCxhjywid(Long cxhjywid) {
    this.cxhjywid = cxhjywid;
  }

  public Long getCxhjywid() {
    return cxhjywid;
  }

  public void setTbbz(Long tbbz) {
    this.tbbz = tbbz;
  }

  public Long getTbbz() {
    return tbbz;
  }

  public void setBwbh(String bwbh) {
    this.bwbh = bwbh;
  }

  public String getBwbh() {
    return bwbh;
  }

  public void setSbsj(String sbsj) {
    this.sbsj = sbsj;
  }

  public String getSbsj() {
    return sbsj;
  }

  public void setSbryxm(String sbryxm) {
    this.sbryxm = sbryxm;
  }

  public String getSbryxm() {
    return sbryxm;
  }

  public void setSbrgmsfhm(String sbrgmsfhm) {
    this.sbrgmsfhm = sbrgmsfhm;
  }

  public String getSbrgmsfhm() {
    return sbrgmsfhm;
  }

  public void setSlsj(String slsj) {
    this.slsj = slsj;
  }

  public String getSlsj() {
    return slsj;
  }

  public void setSldw(String sldw) {
    this.sldw = sldw;
  }

  public String getSldw() {
    return sldw;
  }

  public void setSlrid(Long slrid) {
    this.slrid = slrid;
  }

  public Long getSlrid() {
    return slrid;
  }

  public void setYwlx(String ywlx) {
    this.ywlx = ywlx;
  }

  public String getYwlx() {
    return ywlx;
  }

  public void setCzsm(Long czsm) {
    this.czsm = czsm;
  }

  public Long getCzsm() {
    return czsm;
  }

  public void setJhryxm(String jhryxm) {
    this.jhryxm = jhryxm;
  }

  public String getJhryxm() {
    return jhryxm;
  }

  public void setJhrygmsfhm(String jhrygmsfhm) {
    this.jhrygmsfhm = jhrygmsfhm;
  }

  public String getJhrygmsfhm() {
    return jhrygmsfhm;
  }

  public void setJhryjhgx(String jhryjhgx) {
    this.jhryjhgx = jhryjhgx;
  }

  public String getJhryjhgx() {
    return jhryjhgx;
  }

  public void setJhrexm(String jhrexm) {
    this.jhrexm = jhrexm;
  }

  public String getJhrexm() {
    return jhrexm;
  }

  public void setJhregmsfhm(String jhregmsfhm) {
    this.jhregmsfhm = jhregmsfhm;
  }

  public String getJhregmsfhm() {
    return jhregmsfhm;
  }

  public void setJhrejhgx(String jhrejhgx) {
    this.jhrejhgx = jhrejhgx;
  }

  public String getJhrejhgx() {
    return jhrejhgx;
  }

  public void setFqxm(String fqxm) {
    this.fqxm = fqxm;
  }

  public String getFqxm() {
    return fqxm;
  }

  public void setFqgmsfhm(String fqgmsfhm) {
    this.fqgmsfhm = fqgmsfhm;
  }

  public String getFqgmsfhm() {
    return fqgmsfhm;
  }

  public void setMqxm(String mqxm) {
    this.mqxm = mqxm;
  }

  public String getMqxm() {
    return mqxm;
  }

  public void setMqgmsfhm(String mqgmsfhm) {
    this.mqgmsfhm = mqgmsfhm;
  }

  public String getMqgmsfhm() {
    return mqgmsfhm;
  }

  public void setPoxm(String poxm) {
    this.poxm = poxm;
  }

  public String getPoxm() {
    return poxm;
  }

  public void setPogmsfhm(String pogmsfhm) {
    this.pogmsfhm = pogmsfhm;
  }

  public String getPogmsfhm() {
    return pogmsfhm;
  }

  public void setJggjdq(String jggjdq) {
    this.jggjdq = jggjdq;
  }

  public String getJggjdq() {
    return jggjdq;
  }

  public void setJgssxq(String jgssxq) {
    this.jgssxq = jgssxq;
  }

  public String getJgssxq() {
    return jgssxq;
  }

  public void setZjxy(String zjxy) {
    this.zjxy = zjxy;
  }

  public String getZjxy() {
    return zjxy;
  }

  public void setWhcd(String whcd) {
    this.whcd = whcd;
  }

  public String getWhcd() {
    return whcd;
  }

  public void setHyzk(String hyzk) {
    this.hyzk = hyzk;
  }

  public String getHyzk() {
    return hyzk;
  }

  public void setByzk(String byzk) {
    this.byzk = byzk;
  }

  public String getByzk() {
    return byzk;
  }

  public void setSg(String sg) {
    this.sg = sg;
  }

  public String getSg() {
    return sg;
  }

  public void setXx(String xx) {
    this.xx = xx;
  }

  public String getXx() {
    return xx;
  }

  public void setZy(String zy) {
    this.zy = zy;
  }

  public String getZy() {
    return zy;
  }

  public void setZylb(String zylb) {
    this.zylb = zylb;
  }

  public String getZylb() {
    return zylb;
  }

  public void setFwcs(String fwcs) {
    this.fwcs = fwcs;
  }

  public String getFwcs() {
    return fwcs;
  }

  public void setXxjb(String xxjb) {
    this.xxjb = xxjb;
  }

  public String getXxjb() {
    return xxjb;
  }

  public void setZjlb(String zjlb) {
    this.zjlb = zjlb;
  }

  public String getZjlb() {
    return zjlb;
  }

  public void setQfjg(String qfjg) {
    this.qfjg = qfjg;
  }

  public String getQfjg() {
    return qfjg;
  }

  public void setYxqxqsrq(String yxqxqsrq) {
    this.yxqxqsrq = yxqxqsrq;
  }

  public String getYxqxqsrq() {
    return yxqxqsrq;
  }

  public void setYxqxjzrq(String yxqxjzrq) {
    this.yxqxjzrq = yxqxjzrq;
  }

  public String getYxqxjzrq() {
    return yxqxjzrq;
  }

  public void setDhhm(String dhhm) {
    this.dhhm = dhhm;
  }

  public String getDhhm() {
    return dhhm;
  }

  public void setQtssxq(String qtssxq) {
    this.qtssxq = qtssxq;
  }

  public String getQtssxq() {
    return qtssxq;
  }

  public void setBz(String bz) {
    this.bz = bz;
  }

  public String getBz() {
    return bz;
  }

  public void setQtzz(String qtzz) {
    this.qtzz = qtzz;
  }

  public String getQtzz() {
    return qtzz;
  }

  public void setCsdxz(String csdxz) {
    this.csdxz = csdxz;
  }

  public String getCsdxz() {
    return csdxz;
  }

  public void setCsdgjdq(String csdgjdq) {
    this.csdgjdq = csdgjdq;
  }

  public String getCsdgjdq() {
    return csdgjdq;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setCym(String cym) {
    this.cym = cym;
  }

  public String getCym() {
    return cym;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public String getMz() {
    return mz;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public String getXb() {
    return xb;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public String getCsrq() {
    return csrq;
  }

  public void setCssj(String cssj) {
    this.cssj = cssj;
  }

  public String getCssj() {
    return cssj;
  }

  public void setCsdssxq(String csdssxq) {
    this.csdssxq = csdssxq;
  }

  public String getCsdssxq() {
    return csdssxq;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setHhnbid(Long hhnbid) {
    this.hhnbid = hhnbid;
  }

  public Long getHhnbid() {
    return hhnbid;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public String getJlx() {
    return jlx;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public String getMlph() {
    return mlph;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public String getMlxz() {
    return mlxz;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public String getPcs() {
    return pcs;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public String getZrq() {
    return zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public String getXzjd() {
    return xzjd;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

  public void setPxh(String pxh) {
    this.pxh = pxh;
  }

  public String getPxh() {
    return pxh;
  }

  public void setMlpnbid(Long mlpnbid) {
    this.mlpnbid = mlpnbid;
  }

  public Long getMlpnbid() {
    return mlpnbid;
  }

  public void setYhzgx(String yhzgx) {
    this.yhzgx = yhzgx;
  }

  public String getYhzgx() {
    return yhzgx;
  }

  public void setHzxm(String hzxm) {
    this.hzxm = hzxm;
  }

  public String getHzxm() {
    return hzxm;
  }

  public void setHzgmsfhm(String hzgmsfhm) {
    this.hzgmsfhm = hzgmsfhm;
  }

  public String getHzgmsfhm() {
    return hzgmsfhm;
  }

  public void setHhid(Long hhid) {
    this.hhid = hhid;
  }

  public Long getHhid() {
    return hhid;
  }

  public void setMlpid(Long mlpid) {
    this.mlpid = mlpid;
  }

  public Long getMlpid() {
    return mlpid;
  }

  public void setHb(String hb) {
    this.hb = hb;
  }

  public String getHb() {
    return hb;
  }

}
