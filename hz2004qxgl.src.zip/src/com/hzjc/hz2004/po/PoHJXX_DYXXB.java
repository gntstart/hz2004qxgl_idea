package com.hzjc.hz2004.po;

public class PoHJXX_DYXXB
    implements com.hzjc.wsstruts.po.PO {
  private Long dyid;
  private Long ryid;
  private Long rynbid;
  private String gmsfhm;
  private String xm;
  private String pcs;
  private String ssxq;
  private String dylb;
  private String zjbh;
  private String yznf;
  private String slsj;
  private String sldw;
  private Long slrid;
  private String czip;
  private Long mlpnbid;
  private String jlx;
  private String mlph;
  private String mlxz;
  private String zrq;
  private String xzjd;
  private String jcwh;

  public void setDyid(Long dyid) {
    this.dyid = dyid;
  }

  public Long getDyid() {
    return dyid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public String getPcs() {
    return pcs;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setDylb(String dylb) {
    this.dylb = dylb;
  }

  public String getDylb() {
    return dylb;
  }

  public void setZjbh(String zjbh) {
    this.zjbh = zjbh;
  }

  public String getZjbh() {
    return zjbh;
  }

  public void setYznf(String yznf) {
    this.yznf = yznf;
  }

  public String getYznf() {
    return yznf;
  }

  public void setSlsj(String slsj) {
    this.slsj = slsj;
  }

  public String getSlsj() {
    return slsj;
  }

  public void setSldw(String sldw) {
    this.sldw = sldw;
  }

  public String getSldw() {
    return sldw;
  }

  public void setSlrid(Long slrid) {
    this.slrid = slrid;
  }

  public Long getSlrid() {
    return slrid;
  }

  public void setCzip(String czip) {
    this.czip = czip;
  }

  public String getCzip() {
    return czip;
  }

  public void setMlpnbid(Long mlpnbid) {
    this.mlpnbid = mlpnbid;
  }

  public Long getMlpnbid() {
    return mlpnbid;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public String getJlx() {
    return jlx;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public String getMlph() {
    return mlph;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public String getMlxz() {
    return mlxz;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public String getZrq() {
    return zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public String getXzjd() {
    return xzjd;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

}
