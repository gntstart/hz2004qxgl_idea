package com.hzjc.hz2004.po;

public class PoHJSP_BGSPXXB
    implements com.hzjc.wsstruts.po.PO {
  private Long spywid;
  private Long bgryid;
  private Long xydzid;
  private String spjg;
  private String lsbz;
  private Long bghrynbid;
  private Long hjywid;
  private String sbsj;
  private String sbryxm;
  private String sbrgmsfhm;
  private Long spmbid;
  private Long djrid;
  private String spsm;

  public void setSpywid(Long spywid) {
    this.spywid = spywid;
  }

  public Long getSpywid() {
    return spywid;
  }

  public void setBgryid(Long bgryid) {
    this.bgryid = bgryid;
  }

  public Long getBgryid() {
    return bgryid;
  }

  public void setXydzid(Long xydzid) {
    this.xydzid = xydzid;
  }

  public Long getXydzid() {
    return xydzid;
  }

  public void setSpjg(String spjg) {
    this.spjg = spjg;
  }

  public String getSpjg() {
    return spjg;
  }

  public void setLsbz(String lsbz) {
    this.lsbz = lsbz;
  }

  public String getLsbz() {
    return lsbz;
  }

  public void setBghrynbid(Long bghrynbid) {
    this.bghrynbid = bghrynbid;
  }

  public Long getBghrynbid() {
    return bghrynbid;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public void setSbsj(String sbsj) {
    this.sbsj = sbsj;
  }

  public String getSbsj() {
    return sbsj;
  }

  public void setSbryxm(String sbryxm) {
    this.sbryxm = sbryxm;
  }

  public String getSbryxm() {
    return sbryxm;
  }

  public void setSbrgmsfhm(String sbrgmsfhm) {
    this.sbrgmsfhm = sbrgmsfhm;
  }

  public String getSbrgmsfhm() {
    return sbrgmsfhm;
  }

  public void setSpmbid(Long spmbid) {
    this.spmbid = spmbid;
  }

  public Long getSpmbid() {
    return spmbid;
  }

  public Long getDjrid() {
    return djrid;
  }

  public void setDjrid(Long djrid) {
    this.djrid = djrid;
  }

  public String getSpsm() {
    return spsm;
  }

  public void setSpsm(String spsm) {
    this.spsm = spsm;
  }

}
