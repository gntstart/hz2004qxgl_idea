package  com.hzjc.hz2004.po;

public class PoXT_YHDTQXB implements com.hzjc.wsstruts.po.PO
{
  private Long dtqxid;
  private Long yhid;
  private Long dtyhid;

  public void setDtqxid(Long dtqxid) {
    this.dtqxid = dtqxid;
  }

  public Long getDtqxid() {
    return dtqxid;
  }

  public void setYhid(Long yhid) {
    this.yhid = yhid;
  }

  public Long getYhid() {
    return yhid;
  }

  public void setDtyhid(Long dtyhid) {
    this.dtyhid = dtyhid;
  }

  public Long getDtyhid() {
    return dtyhid;
  }

}
