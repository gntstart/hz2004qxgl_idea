package  com.hzjc.hz2004.po;

public class PoHJYW_ZXHKXXB implements com.hzjc.wsstruts.po.PO
{
  private Long zxhkid;
  private Long bzxrynbid;
  private String zxhkyy;
  private Long hjywid;

  public void setZxhkid(Long zxhkid) {
    this.zxhkid = zxhkid;
  }

  public Long getZxhkid() {
    return zxhkid;
  }

  public void setBzxrynbid(Long bzxrynbid) {
    this.bzxrynbid = bzxrynbid;
  }

  public Long getBzxrynbid() {
    return bzxrynbid;
  }

  public void setZxhkyy(String zxhkyy) {
    this.zxhkyy = zxhkyy;
  }

  public String getZxhkyy() {
    return zxhkyy;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

}
