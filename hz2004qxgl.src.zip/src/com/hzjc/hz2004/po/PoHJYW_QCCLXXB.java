package com.hzjc.hz2004.po;

public class PoHJYW_QCCLXXB
    implements com.hzjc.wsstruts.po.PO {
  private Long qcclid;
  private Long qqrynbid;
  private Long qhrynbid;
  private String czlx;
  private String clrq;
  private String clbz;
  private Long clrid;
  private String cgdyrq;
  private Long hjywid;
  private String cxbz;
  private String cxsj;
  private Long cxrid;
  private Long cxhjywid;
  private Long mlpnbid_q;
  private Long ryid;
  private Long mlpnbid_h;
  private String gmsfhm;
  private String xm;
  private String xb;
  private String mz;
  private String csrq;
  private String cssj;
  private String csdssxq;
  private String ssxq_q;
  private String jlx_q;
  private String mlph_q;
  private String mlxz_q;
  private String pcs_q;
  private String zrq_q;
  private String xzjd_q;
  private String jcwh_q;
  private String pxh_q;
  private String ssxq_h;
  private String jlx_h;
  private String mlph_h;
  private String mlxz_h;
  private String pcs_h;
  private String zrq_h;
  private String xzjd_h;
  private String jcwh_h;
  private String pxh_h;

  public void setQcclid(Long qcclid) {
    this.qcclid = qcclid;
  }

  public Long getQcclid() {
    return qcclid;
  }

  public void setQqrynbid(Long qqrynbid) {
    this.qqrynbid = qqrynbid;
  }

  public Long getQqrynbid() {
    return qqrynbid;
  }

  public void setQhrynbid(Long qhrynbid) {
    this.qhrynbid = qhrynbid;
  }

  public Long getQhrynbid() {
    return qhrynbid;
  }

  public void setCzlx(String czlx) {
    this.czlx = czlx;
  }

  public String getCzlx() {
    return czlx;
  }

  public void setClrq(String clrq) {
    this.clrq = clrq;
  }

  public String getClrq() {
    return clrq;
  }

  public void setClbz(String clbz) {
    this.clbz = clbz;
  }

  public String getClbz() {
    return clbz;
  }

  public void setClrid(Long clrid) {
    this.clrid = clrid;
  }

  public Long getClrid() {
    return clrid;
  }

  public void setCgdyrq(String cgdyrq) {
    this.cgdyrq = cgdyrq;
  }

  public String getCgdyrq() {
    return cgdyrq;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public void setCxbz(String cxbz) {
    this.cxbz = cxbz;
  }

  public String getCxbz() {
    return cxbz;
  }

  public void setCxsj(String cxsj) {
    this.cxsj = cxsj;
  }

  public String getCxsj() {
    return cxsj;
  }

  public void setCxrid(Long cxrid) {
    this.cxrid = cxrid;
  }

  public Long getCxrid() {
    return cxrid;
  }

  public void setCxhjywid(Long cxhjywid) {
    this.cxhjywid = cxhjywid;
  }

  public Long getCxhjywid() {
    return cxhjywid;
  }

  public String getCsdssxq() {
    return csdssxq;
  }

  public void setCsdssxq(String csdssxq) {
    this.csdssxq = csdssxq;
  }

  public String getCsrq() {
    return csrq;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public String getCssj() {
    return cssj;
  }

  public void setCssj(String cssj) {
    this.cssj = cssj;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getJcwh_h() {
    return jcwh_h;
  }

  public void setJcwh_h(String jcwh_h) {
    this.jcwh_h = jcwh_h;
  }

  public String getJcwh_q() {
    return jcwh_q;
  }

  public void setJcwh_q(String jcwh_q) {
    this.jcwh_q = jcwh_q;
  }

  public String getJlx_h() {
    return jlx_h;
  }

  public void setJlx_h(String jlx_h) {
    this.jlx_h = jlx_h;
  }

  public String getJlx_q() {
    return jlx_q;
  }

  public void setJlx_q(String jlx_q) {
    this.jlx_q = jlx_q;
  }

  public String getMlph_h() {
    return mlph_h;
  }

  public void setMlph_h(String mlph_h) {
    this.mlph_h = mlph_h;
  }

  public String getMlph_q() {
    return mlph_q;
  }

  public void setMlph_q(String mlph_q) {
    this.mlph_q = mlph_q;
  }

  public Long getMlpnbid_h() {
    return mlpnbid_h;
  }

  public void setMlpnbid_h(Long mlpnbid_h) {
    this.mlpnbid_h = mlpnbid_h;
  }

  public Long getMlpnbid_q() {
    return mlpnbid_q;
  }

  public void setMlpnbid_q(Long mlpnbid_q) {
    this.mlpnbid_q = mlpnbid_q;
  }

  public String getMlxz_h() {
    return mlxz_h;
  }

  public void setMlxz_h(String mlxz_h) {
    this.mlxz_h = mlxz_h;
  }

  public String getMlxz_q() {
    return mlxz_q;
  }

  public void setMlxz_q(String mlxz_q) {
    this.mlxz_q = mlxz_q;
  }

  public String getMz() {
    return mz;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public String getPcs_h() {
    return pcs_h;
  }

  public void setPcs_h(String pcs_h) {
    this.pcs_h = pcs_h;
  }

  public String getPcs_q() {
    return pcs_q;
  }

  public void setPcs_q(String pcs_q) {
    this.pcs_q = pcs_q;
  }

  public String getPxh_h() {
    return pxh_h;
  }

  public void setPxh_h(String pxh_h) {
    this.pxh_h = pxh_h;
  }

  public String getPxh_q() {
    return pxh_q;
  }

  public void setPxh_q(String pxh_q) {
    this.pxh_q = pxh_q;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public String getSsxq_h() {
    return ssxq_h;
  }

  public void setSsxq_h(String ssxq_h) {
    this.ssxq_h = ssxq_h;
  }

  public String getSsxq_q() {
    return ssxq_q;
  }

  public void setSsxq_q(String ssxq_q) {
    this.ssxq_q = ssxq_q;
  }

  public String getXb() {
    return xb;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public String getXm() {
    return xm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXzjd_h() {
    return xzjd_h;
  }

  public void setXzjd_h(String xzjd_h) {
    this.xzjd_h = xzjd_h;
  }

  public String getXzjd_q() {
    return xzjd_q;
  }

  public void setXzjd_q(String xzjd_q) {
    this.xzjd_q = xzjd_q;
  }

  public String getZrq_h() {
    return zrq_h;
  }

  public void setZrq_h(String zrq_h) {
    this.zrq_h = zrq_h;
  }

  public String getZrq_q() {
    return zrq_q;
  }

  public void setZrq_q(String zrq_q) {
    this.zrq_q = zrq_q;
  }

}
