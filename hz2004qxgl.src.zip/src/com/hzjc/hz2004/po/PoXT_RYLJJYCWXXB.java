package  com.hzjc.hz2004.po;

public class PoXT_RYLJJYCWXXB implements com.hzjc.wsstruts.po.PO
{
  private Long jyid;
  private Long ryid;
  private Long rynbid;
  private String xm;
  private String gmsfhm;
  private String pcs;
  private String sm;
  private String jysj;
  private Long jyrid;

  public void setJyid(Long jyid) {
    this.jyid = jyid;
  }

  public Long getJyid() {
    return jyid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public String getPcs() {
    return pcs;
  }

  public void setSm(String sm) {
    this.sm = sm;
  }

  public String getSm() {
    return sm;
  }

  public void setJysj(String jysj) {
    this.jysj = jysj;
  }

  public String getJysj() {
    return jysj;
  }

  public void setJyrid(Long jyrid) {
    this.jyrid = jyrid;
  }

  public Long getJyrid() {
    return jyrid;
  }

}
