package com.hzjc.hz2004.po;

public class PoHJYW_CSDJXXB
    implements com.hzjc.wsstruts.po.PO {
  private Long csdjid;
  private Long rynbid;
  private String cszmbh;
  private String csdjlb;
  private Long hjywid;
  private String cxbz;
  private String cxsj;
  private Long cxrid;
  private Long cxhjywid;

  private String sbsj;
  private String sbryxm;
  private String sbrgmsfhm;
  private String slsj;
  private String sldw;
  private Long slrid;

  private String xm;
  private String gmsfhm;
  private String xb;
  private String mz;
  private String csrq;
  private String cssj;
  private String csdgjdq;
  private String csdssxq;
  private String jhryxm;
  private String jhrygmsfhm;
  private String jhryjhgx;
  private String jhrexm;
  private String jhregmsfhm;
  private String jhrejhgx;
  private String fqxm;
  private String fqgmsfhm;
  private String mqxm;
  private String mqgmsfhm;
  private String jggjdq;
  private String jgssxq;
  private String xx;
  private String hh;
  private String hlx;
  private String ssxq;
  private String jlx;
  private Long mlpnbid;
  private Long mlpid;
  private String mlph;
  private String mlxz;
  private String pcs;
  private String zrq;
  private String xzjd;
  private String jcwh;
  private String pxh;
  private Long ryid;
  private Long hhnbid;
  private Long hhid;
  private String csdxz;
  private String hb;
  private String yhzgx;
  private String hzxm;
  private String hzgmsfhm;
  private String ywlx;
  private Long czsm;

  private String  sbrjtgx;
  private String cxfldm;

  public void setCsdjid(Long csdjid) {
    this.csdjid = csdjid;
  }

  public Long getCsdjid() {
    return csdjid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setCszmbh(String cszmbh) {
    this.cszmbh = cszmbh;
  }

  public String getCszmbh() {
    return cszmbh;
  }

  public void setCsdjlb(String csdjlb) {
    this.csdjlb = csdjlb;
  }

  public String getCsdjlb() {
    return csdjlb;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public void setCxbz(String cxbz) {
    this.cxbz = cxbz;
  }

  public String getCxbz() {
    return cxbz;
  }

  public void setCxsj(String cxsj) {
    this.cxsj = cxsj;
  }

  public String getCxsj() {
    return cxsj;
  }

  public void setCxrid(Long cxrid) {
    this.cxrid = cxrid;
  }

  public Long getCxrid() {
    return cxrid;
  }

  public void setCxhjywid(Long cxhjywid) {
    this.cxhjywid = cxhjywid;
  }

  public Long getCxhjywid() {
    return cxhjywid;
  }

  public String getSbrgmsfhm() {
    return sbrgmsfhm;
  }

  public void setSbrgmsfhm(String sbrgmsfhm) {
    this.sbrgmsfhm = sbrgmsfhm;
  }

  public String getSbryxm() {
    return sbryxm;
  }

  public void setSbryxm(String sbryxm) {
    this.sbryxm = sbryxm;
  }

  public String getSbsj() {
    return sbsj;
  }

  public void setSbsj(String sbsj) {
    this.sbsj = sbsj;
  }

  public String getSldw() {
    return sldw;
  }

  public void setSldw(String sldw) {
    this.sldw = sldw;
  }

  public Long getSlrid() {
    return slrid;
  }

  public void setSlrid(Long slrid) {
    this.slrid = slrid;
  }

  public String getSlsj() {
    return slsj;
  }

  public void setSlsj(String slsj) {
    this.slsj = slsj;
  }

  public String getCsdgjdq() {
    return csdgjdq;
  }

  public void setCsdgjdq(String csdgjdq) {
    this.csdgjdq = csdgjdq;
  }

  public String getCsdssxq() {
    return csdssxq;
  }

  public String getCsdxz() {
    return csdxz;
  }

  public String getCsrq() {
    return csrq;
  }

  public String getCssj() {
    return cssj;
  }

  public void setCssj(String cssj) {
    this.cssj = cssj;
  }

  public void setCsrq(String csrq) {
    this.csrq = csrq;
  }

  public void setCsdxz(String csdxz) {
    this.csdxz = csdxz;
  }

  public void setCsdssxq(String csdssxq) {
    this.csdssxq = csdssxq;
  }

  public String getFqgmsfhm() {
    return fqgmsfhm;
  }

  public String getFqxm() {
    return fqxm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public String getHh() {
    return hh;
  }

  public Long getHhnbid() {
    return hhnbid;
  }

  public void setHhnbid(Long hhnbid) {
    this.hhnbid = hhnbid;
  }

  public void setHh(String hh) {
    this.hh = hh;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public void setFqxm(String fqxm) {
    this.fqxm = fqxm;
  }

  public void setFqgmsfhm(String fqgmsfhm) {
    this.fqgmsfhm = fqgmsfhm;
  }

  public String getHlx() {
    return hlx;
  }

  public String getJcwh() {
    return jcwh;
  }

  public String getJggjdq() {
    return jggjdq;
  }

  public String getJgssxq() {
    return jgssxq;
  }

  public String getJhregmsfhm() {
    return jhregmsfhm;
  }

  public String getJhrejhgx() {
    return jhrejhgx;
  }

  public String getJhrygmsfhm() {
    return jhrygmsfhm;
  }

  public String getJhryjhgx() {
    return jhryjhgx;
  }

  public String getJhryxm() {
    return jhryxm;
  }

  public String getJlx() {
    return jlx;
  }

  public String getMlph() {
    return mlph;
  }

  public Long getMlpnbid() {
    return mlpnbid;
  }

  public String getMlxz() {
    return mlxz;
  }

  public String getMqgmsfhm() {
    return mqgmsfhm;
  }

  public String getMqxm() {
    return mqxm;
  }

  public String getMz() {
    return mz;
  }

  public String getPcs() {
    return pcs;
  }

  public String getPxh() {
    return pxh;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public void setPxh(String pxh) {
    this.pxh = pxh;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public void setMz(String mz) {
    this.mz = mz;
  }

  public void setMqxm(String mqxm) {
    this.mqxm = mqxm;
  }

  public void setMqgmsfhm(String mqgmsfhm) {
    this.mqgmsfhm = mqgmsfhm;
  }

  public void setMlxz(String mlxz) {
    this.mlxz = mlxz;
  }

  public void setMlpnbid(Long mlpnbid) {
    this.mlpnbid = mlpnbid;
  }

  public void setMlph(String mlph) {
    this.mlph = mlph;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public void setJhryxm(String jhryxm) {
    this.jhryxm = jhryxm;
  }

  public void setJhryjhgx(String jhryjhgx) {
    this.jhryjhgx = jhryjhgx;
  }

  public void setJhrygmsfhm(String jhrygmsfhm) {
    this.jhrygmsfhm = jhrygmsfhm;
  }

  public void setJhrexm(String jhrexm) {
    this.jhrexm = jhrexm;
  }

  public void setJhrejhgx(String jhrejhgx) {
    this.jhrejhgx = jhrejhgx;
  }

  public void setJhregmsfhm(String jhregmsfhm) {
    this.jhregmsfhm = jhregmsfhm;
  }

  public void setJgssxq(String jgssxq) {
    this.jgssxq = jgssxq;
  }

  public void setJggjdq(String jggjdq) {
    this.jggjdq = jggjdq;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public void setHlx(String hlx) {
    this.hlx = hlx;
  }

  public String getSsxq() {
    return ssxq;
  }

  public String getXb() {
    return xb;
  }

  public String getXm() {
    return xm;
  }

  public String getXx() {
    return xx;
  }

  public String getXzjd() {
    return xzjd;
  }

  public String getZrq() {
    return zrq;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public void setXx(String xx) {
    this.xx = xx;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public void setXb(String xb) {
    this.xb = xb;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getJhrexm() {
    return jhrexm;
  }

  public Long getCzsm() {
    return czsm;
  }

  public void setCzsm(Long czsm) {
    this.czsm = czsm;
  }

  public String getHzgmsfhm() {
    return hzgmsfhm;
  }

  public void setHzgmsfhm(String hzgmsfhm) {
    this.hzgmsfhm = hzgmsfhm;
  }

  public String getHzxm() {
    return hzxm;
  }

  public void setHzxm(String hzxm) {
    this.hzxm = hzxm;
  }

  public String getYhzgx() {
    return yhzgx;
  }

  public void setYhzgx(String yhzgx) {
    this.yhzgx = yhzgx;
  }

  public String getYwlx() {
    return ywlx;
  }

  public void setYwlx(String ywlx) {
    this.ywlx = ywlx;
  }

  public String getHb() {
    return hb;
  }

  public void setHb(String hb) {
    this.hb = hb;
  }

  public Long getHhid() {
    return hhid;
  }

  public void setHhid(Long hhid) {
    this.hhid = hhid;
  }

  public Long getMlpid() {
    return mlpid;
  }

  public void setMlpid(Long mlpid) {
    this.mlpid = mlpid;
  }

  public String getSbrjtgx() {
    return sbrjtgx;
  }

  public String getCxfldm() {
    return cxfldm;
  }

  public void setSbrjtgx(String sbrjtgx) {
    this.sbrjtgx = sbrjtgx;
  }

  public void setCxfldm(String cxfldm) {
    this.cxfldm = cxfldm;
  }

}
