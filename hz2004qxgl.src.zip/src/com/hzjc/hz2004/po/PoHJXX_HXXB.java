package  com.hzjc.hz2004.po;

public class PoHJXX_HXXB implements com.hzjc.wsstruts.po.PO
{
  private Long hhnbid;
  private Long hhid;
  private Long mlpnbid;
  private String hh;
  private String hlx;
  private String jhlb;
  private String chlb;
  private String jhsj;
  private String chsj;
  private Long cjhjywid;
  private Long cchjywid;
  private String bdfw;
  private String bdyy;
  private String hhzt;
  private Long lxdbid;
  private String jlbz;
  private String qysj;
  private String jssj;
  private String cxbz;

  public void setHhnbid(Long hhnbid) {
    this.hhnbid = hhnbid;
  }

  public Long getHhnbid() {
    return hhnbid;
  }

  public void setHhid(Long hhid) {
    this.hhid = hhid;
  }

  public Long getHhid() {
    return hhid;
  }

  public void setMlpnbid(Long mlpnbid) {
    this.mlpnbid = mlpnbid;
  }

  public Long getMlpnbid() {
    return mlpnbid;
  }

  public void setHh(String hh) {
    this.hh = hh;
  }

  public String getHh() {
    return hh;
  }

  public void setHlx(String hlx) {
    this.hlx = hlx;
  }

  public String getHlx() {
    return hlx;
  }

  public void setJhlb(String jhlb) {
    this.jhlb = jhlb;
  }

  public String getJhlb() {
    return jhlb;
  }

  public void setChlb(String chlb) {
    this.chlb = chlb;
  }

  public String getChlb() {
    return chlb;
  }

  public void setJhsj(String jhsj) {
    this.jhsj = jhsj;
  }

  public String getJhsj() {
    return jhsj;
  }

  public void setChsj(String chsj) {
    this.chsj = chsj;
  }

  public String getChsj() {
    return chsj;
  }

  public void setCjhjywid(Long cjhjywid) {
    this.cjhjywid = cjhjywid;
  }

  public Long getCjhjywid() {
    return cjhjywid;
  }

  public void setCchjywid(Long cchjywid) {
    this.cchjywid = cchjywid;
  }

  public Long getCchjywid() {
    return cchjywid;
  }

  public void setBdfw(String bdfw) {
    this.bdfw = bdfw;
  }

  public String getBdfw() {
    return bdfw;
  }

  public void setBdyy(String bdyy) {
    this.bdyy = bdyy;
  }

  public String getBdyy() {
    return bdyy;
  }

  public void setHhzt(String hhzt) {
    this.hhzt = hhzt;
  }

  public String getHhzt() {
    return hhzt;
  }

  public void setLxdbid(Long lxdbid) {
    this.lxdbid = lxdbid;
  }

  public Long getLxdbid() {
    return lxdbid;
  }

  public void setJlbz(String jlbz) {
    this.jlbz = jlbz;
  }

  public String getJlbz() {
    return jlbz;
  }

  public void setQysj(String qysj) {
    this.qysj = qysj;
  }

  public String getQysj() {
    return qysj;
  }

  public void setJssj(String jssj) {
    this.jssj = jssj;
  }

  public String getJssj() {
    return jssj;
  }

  public void setCxbz(String cxbz) {
    this.cxbz = cxbz;
  }

  public String getCxbz() {
    return cxbz;
  }

}
