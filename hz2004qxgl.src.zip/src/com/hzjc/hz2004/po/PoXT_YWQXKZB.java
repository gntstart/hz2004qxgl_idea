package  com.hzjc.hz2004.po;

public class PoXT_YWQXKZB implements com.hzjc.wsstruts.po.PO
{
  private Long qxkzid;
  private String ywid;
  private String ywmc;
  private String xqlx;
  private String sjfwxz;
  private String yhdtcx;

  public void setQxkzid(Long qxkzid) {
    this.qxkzid = qxkzid;
  }

  public Long getQxkzid() {
    return qxkzid;
  }

  public void setYwid(String ywid) {
    this.ywid = ywid;
  }

  public String getYwid() {
    return ywid;
  }

  public void setYwmc(String ywmc) {
    this.ywmc = ywmc;
  }

  public String getYwmc() {
    return ywmc;
  }

  public void setXqlx(String xqlx) {
    this.xqlx = xqlx;
  }

  public String getXqlx() {
    return xqlx;
  }

  public void setSjfwxz(String sjfwxz) {
    this.sjfwxz = sjfwxz;
  }

  public String getSjfwxz() {
    return sjfwxz;
  }

  public void setYhdtcx(String yhdtcx) {
    this.yhdtcx = yhdtcx;
  }

  public String getYhdtcx() {
    return yhdtcx;
  }

}
