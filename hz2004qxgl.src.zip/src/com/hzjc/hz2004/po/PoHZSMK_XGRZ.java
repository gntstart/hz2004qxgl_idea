package com.hzjc.hz2004.po;

public class PoHZSMK_XGRZ
    implements com.hzjc.wsstruts.po.PO {

  private Long xgrzid; //�޸���־ID
  private Long xkrzid; //д����־ID
  private Long rynbid; //��Ա�ڲ�ID
  private Long ryid; //��ԱID
  private String gmsfhm; //�������ݺ���
  private String xm; //����
  private String ssxq;  //ʡ���أ�����
  private String jlx;  //��·��
  private String pcs;  //�ɳ���
  private String zrq;  //������
  private String xzjd;  //���򣨽ֵ���
  private String jcwh;  //�ӣ��壩ί��
  private String xgzdm;  //�޸��ֶ�����
  private String xgqnr;  //�޸�ǰ����
  private String xghnr;  //�޸ĺ�����

  public void setXgrzid(Long xgrzid) {
    this.xgrzid = xgrzid;
  }

  public Long getXgrzid() {
    return xgrzid;
  }

  public void setXkrzid(Long xkrzid) {
    this.xkrzid = xkrzid;
  }

  public Long getXkrzid() {
    return xkrzid;
  }

  public void setRynbid(Long rynbid) {
    this.rynbid = rynbid;
  }

  public Long getRynbid() {
    return rynbid;
  }

  public void setRyid(Long ryid) {
    this.ryid = ryid;
  }

  public Long getRyid() {
    return ryid;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setSsxq(String ssxq) {
    this.ssxq = ssxq;
  }

  public String getSsxq() {
    return ssxq;
  }

  public void setJlx(String jlx) {
    this.jlx = jlx;
  }

  public String getJlx() {
    return jlx;
  }

  public void setPcs(String pcs) {
    this.pcs = pcs;
  }

  public String getPcs() {
    return pcs;
  }

  public void setZrq(String zrq) {
    this.zrq = zrq;
  }

  public String getZrq() {
    return zrq;
  }

  public void setXzjd(String xzjd) {
    this.xzjd = xzjd;
  }

  public String getXzjd() {
    return xzjd;
  }

  public void setJcwh(String jcwh) {
    this.jcwh = jcwh;
  }

  public String getJcwh() {
    return jcwh;
  }

  public void setXgzdm(String xgzdm) {
    this.xgzdm = xgzdm;
  }

  public String getXgzdm() {
    return xgzdm;
  }

  public void setXgqnr(String xgqnr) {
    this.xgqnr = xgqnr;
  }

  public String getXgqnr() {
    return xgqnr;
  }

  public void setXghnr(String xghnr) {
    this.xghnr = xghnr;
  }

  public String getXghnr() {
    return xghnr;
  }


}
