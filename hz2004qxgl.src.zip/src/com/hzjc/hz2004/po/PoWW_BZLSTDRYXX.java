package com.hzjc.hz2004.po;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
public class PoWW_BZLSTDRYXX
    implements com.hzjc.wsstruts.po.PO {
  private Long id;
  private String gmsfhm;
  private String xm;
  private String rkrq;

  public void setId(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setXm(String xm) {
    this.xm = xm;
  }

  public String getXm() {
    return xm;
  }

  public void setRkrq(String rkrq) {
    this.rkrq = rkrq;
  }

  public String getRkrq() {
    return rkrq;
  }

}
