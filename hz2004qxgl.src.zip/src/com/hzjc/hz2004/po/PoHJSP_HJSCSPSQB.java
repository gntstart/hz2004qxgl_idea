package com.hzjc.hz2004.po;

public class PoHJSP_HJSCSPSQB
    implements com.hzjc.wsstruts.po.PO {
  private Long spmbid;
  private Long spywid;
  private Long bscryid;
  private String csyy;
  private Long xydzid;
  private String spjg;
  private String lsbz;
  private Long hjywid;
  private String sqsj;
  private Long sqyhid;
  private String spsm;
  private String hjscsm;

  public void setSpmbid(Long spmbid) {
    this.spmbid = spmbid;
  }

  public Long getSpmbid() {
    return spmbid;
  }

  public void setSpywid(Long spywid) {
    this.spywid = spywid;
  }

  public Long getSpywid() {
    return spywid;
  }

  public void setBscryid(Long bscryid) {
    this.bscryid = bscryid;
  }

  public Long getBscryid() {
    return bscryid;
  }

  public void setCsyy(String csyy) {
    this.csyy = csyy;
  }

  public String getCsyy() {
    return csyy;
  }

  public void setXydzid(Long xydzid) {
    this.xydzid = xydzid;
  }

  public Long getXydzid() {
    return xydzid;
  }

  public void setSpjg(String spjg) {
    this.spjg = spjg;
  }

  public String getSpjg() {
    return spjg;
  }

  public void setLsbz(String lsbz) {
    this.lsbz = lsbz;
  }

  public String getLsbz() {
    return lsbz;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

  public void setSqsj(String sqsj) {
    this.sqsj = sqsj;
  }

  public String getSqsj() {
    return sqsj;
  }

  public void setSqyhid(Long sqyhid) {
    this.sqyhid = sqyhid;
  }

  public Long getSqyhid() {
    return sqyhid;
  }

  public String getSpsm() {
    return spsm;
  }

  public void setSpsm(String spsm) {
    this.spsm = spsm;
  }

  public String getHjscsm() {
    return hjscsm;
  }

  public void setHjscsm(String hjscsm) {
    this.hjscsm = hjscsm;
  }


}
