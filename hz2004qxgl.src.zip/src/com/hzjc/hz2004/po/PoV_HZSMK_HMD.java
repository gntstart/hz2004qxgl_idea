package com.hzjc.hz2004.po;

public class PoV_HZSMK_HMD
    implements com.hzjc.wsstruts.po.PO {

  private String gmsfhm; //�������ݺ���
  private String kdsbm; //����ʶ����

  public void setGmsfhm(String gmsfhm) {
    this.gmsfhm = gmsfhm;
  }

  public String getGmsfhm() {
    return gmsfhm;
  }

  public void setKdsbm(String kdsbm) {
    this.kdsbm = kdsbm;
  }

  public String getKdsbm() {
    return kdsbm;
  }

}
