package  com.hzjc.hz2004.po;

public class PoHJYW_HFHKXXB implements com.hzjc.wsstruts.po.PO
{
  private Long hfhkid;
  private Long bhfrynbid;
  private String hfhkyy;
  private Long hjywid;

  public void setHfhkid(Long hfhkid) {
    this.hfhkid = hfhkid;
  }

  public Long getHfhkid() {
    return hfhkid;
  }

  public void setBhfrynbid(Long bhfrynbid) {
    this.bhfrynbid = bhfrynbid;
  }

  public Long getBhfrynbid() {
    return bhfrynbid;
  }

  public void setHfhkyy(String hfhkyy) {
    this.hfhkyy = hfhkyy;
  }

  public String getHfhkyy() {
    return hfhkyy;
  }

  public void setHjywid(Long hjywid) {
    this.hjywid = hjywid;
  }

  public Long getHjywid() {
    return hjywid;
  }

}
