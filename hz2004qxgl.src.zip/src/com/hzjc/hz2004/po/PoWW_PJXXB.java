package com.hzjc.hz2004.po;

public class PoWW_PJXXB
    implements com.hzjc.wsstruts.po.PO {

  private Long pjid;
  private String pjjg;
  private String pjrlxfs;
  private String pjkssj;
  private String pjjssj;
  private Long bpjrid;
  private String bpjrdlm;
  private String bpjrxm;
  private String bpjdw;
  private Long ywzs;

  public Long getPjid() {
    return pjid;
  }

  public void setPjid(Long pjid) {
    this.pjid = pjid;
  }

  public String getPjjg() {
    return pjjg;
  }

  public void setPjjg(String pjjg) {
    this.pjjg = pjjg;
  }

  public String getPjrlxfs() {
    return pjrlxfs;
  }

  public void setPjrlxfs(String pjrlxfs) {
    this.pjrlxfs = pjrlxfs;
  }

  public String getPjkssj() {
    return pjkssj;
  }

  public void setPjkssj(String pjkssj) {
    this.pjkssj = pjkssj;
  }

  public String getPjjssj() {
    return pjjssj;
  }

  public void setPjjssj(String pjjssj) {
    this.pjjssj = pjjssj;
  }

  public Long getBpjrid() {
    return bpjrid;
  }

  public void setBpjrid(Long bpjrid) {
    this.bpjrid = bpjrid;
  }

  public String getBpjrdlm() {
    return bpjrdlm;
  }

  public void setBpjrdlm(String bpjrdlm) {
    this.bpjrdlm = bpjrdlm;
  }

  public String getBpjrxm() {
    return bpjrxm;
  }

  public void setBpjrxm(String bpjrxm) {
    this.bpjrxm = bpjrxm;
  }


  public String getBpjdw() {
    return bpjdw;
  }

  public void setBpjdw(String bpjdw) {
    this.bpjdw = bpjdw;
  }

  public Long getYwzs() {
    return ywzs;
  }

  public void setYwzs(Long ywzs) {
    this.ywzs = ywzs;
  }

}
