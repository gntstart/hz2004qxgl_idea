package  com.hzjc.hz2004.po;

public class PoWW_RZB implements com.hzjc.wsstruts.po.PO
{
  private Long rzid;
  private String ywbz;
  private String rznr;
  private String czsj;
  private Long czrid;
  private String czrdw;
  private String czrip;
  private String ywjg;

  public void setRzid(Long rzid) {
    this.rzid = rzid;
  }

  public Long getRzid() {
    return rzid;
  }

  public void setYwbz(String ywbz) {
    this.ywbz = ywbz;
  }

  public String getYwbz() {
    return ywbz;
  }

  public void setRznr(String rznr) {
    this.rznr = rznr;
  }

  public String getRznr() {
    return rznr;
  }

  public void setCzsj(String czsj) {
    this.czsj = czsj;
  }

  public String getCzsj() {
    return czsj;
  }

  public void setCzrid(Long czrid) {
    this.czrid = czrid;
  }

  public Long getCzrid() {
    return czrid;
  }

  public void setCzrdw(String czrdw) {
    this.czrdw = czrdw;
  }

  public String getCzrdw() {
    return czrdw;
  }

  public void setCzrip(String czrip) {
    this.czrip = czrip;
  }

  public String getCzrip() {
    return czrip;
  }
  public String getYwjg() {
    return ywjg;
  }
  public void setYwjg(String ywjg) {
    this.ywjg = ywjg;
  }

}
