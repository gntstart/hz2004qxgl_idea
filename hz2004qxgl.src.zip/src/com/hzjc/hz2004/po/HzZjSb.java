package  com.hzjc.hz2004.po;

import java.util.*;


public class HzZjSb implements com.hzjc.wsstruts.po.PO{
        private Long id;
        private String sqrxm;
        private String sqrsfz;
        private String sqrlxdh;
        private String sqrlxdz;
        private Long ywlb;
        private String bsqrxm;
        private String bsqrsfz;
        private String czdw;
        private String czyh;
        private Date czsj;
        private String lhbs;
        private String lhsfz;
        private String lhdz;
        private String sbzt;
        private String clbs;
        private Date clsj;
        private String pch;
        private String ywlbm;
        private String nbgxm;
        private String cym;
        private String csyxzmbh;
        private String bsqrxb;
        private String bsqrmz;
        private String bsqrcsrq;
        private String btkrgx;
        private String bsqrsjhm;
        private String zxyy;

        public String getYwlbm() {
                return ywlbm;
        }
        public void setYwlbm(String ywlbm) {
                this.ywlbm = ywlbm;
        }

        public Long getId() {
                return id;
        }
        public void setId(Long id) {
                this.id = id;
        }
        public String getSqrxm() {
                return sqrxm;
        }
        public void setSqrxm(String sqrxm) {
                this.sqrxm = sqrxm;
        }
        public String getSqrsfz() {
                return sqrsfz;
        }
        public void setSqrsfz(String sqrsfz) {
                this.sqrsfz = sqrsfz;
        }
        public String getSqrlxdh() {
                return sqrlxdh;
        }
        public void setSqrlxdh(String sqrlxdh) {
                this.sqrlxdh = sqrlxdh;
        }
        public String getSqrlxdz() {
                return sqrlxdz;
        }
        public void setSqrlxdz(String sqrlxdz) {
                this.sqrlxdz = sqrlxdz;
        }
        public Long getYwlb() {
                return ywlb;
        }
        public void setYwlb(Long ywlb) {
                this.ywlb = ywlb;
        }
        public String getBsqrxm() {
                return bsqrxm;
        }
        public void setBsqrxm(String bsqrxm) {
                this.bsqrxm = bsqrxm;
        }
        public String getBsqrsfz() {
                return bsqrsfz;
        }
        public void setBsqrsfz(String bsqrsfz) {
                this.bsqrsfz = bsqrsfz;
        }
        public String getCzdw() {
                return czdw;
        }
        public void setCzdw(String czdw) {
                this.czdw = czdw;
        }
        public String getCzyh() {
                return czyh;
        }
        public void setCzyh(String czyh) {
                this.czyh = czyh;
        }
        public Date getCzsj() {
                return czsj;
        }
        public void setCzsj(Date czsj) {
                this.czsj = czsj;
        }
        public String getLhbs() {
                return lhbs;
        }
        public void setLhbs(String lhbs) {
                this.lhbs = lhbs;
        }
        public String getLhsfz() {
                return lhsfz;
        }
        public void setLhsfz(String lhsfz) {
                this.lhsfz = lhsfz;
        }
        public String getLhdz() {
                return lhdz;
        }
        public void setLhdz(String lhdz) {
                this.lhdz = lhdz;
        }
        public String getSbzt() {
                return sbzt;
        }
        public void setSbzt(String sbzt) {
                this.sbzt = sbzt;
        }
        public String getClbs() {
                return clbs;
        }
        public void setClbs(String clbs) {
                this.clbs = clbs;
        }
        public Date getClsj() {
                return clsj;
        }
        public void setClsj(Date clsj) {
                this.clsj = clsj;
        }
        public String getPch() {
                return pch;
        }

  public String getBsqrcsrq() {
    return bsqrcsrq;
  }

  public String getBsqrmz() {
    return bsqrmz;
  }

  public String getBsqrsjhm() {
    return bsqrsjhm;
  }

  public String getBsqrxb() {
    return bsqrxb;
  }

  public String getBtkrgx() {
    return btkrgx;
  }

  public String getCsyxzmbh() {
    return csyxzmbh;
  }

  public String getCym() {
    return cym;
  }

  public String getNbgxm() {
    return nbgxm;
  }

  public String getZxyy() {
    return zxyy;
  }

  public void setPch(String pch) {
                this.pch = pch;
        }

  public void setBsqrcsrq(String bsqrcsrq) {
    this.bsqrcsrq = bsqrcsrq;
  }

  public void setBsqrmz(String bsqrmz) {
    this.bsqrmz = bsqrmz;
  }

  public void setCym(String cym) {
    this.cym = cym;
  }

  public void setCsyxzmbh(String csyxzmbh) {
    this.csyxzmbh = csyxzmbh;
  }

  public void setBtkrgx(String btkrgx) {
    this.btkrgx = btkrgx;
  }

  public void setBsqrxb(String bsqrxb) {
    this.bsqrxb = bsqrxb;
  }

  public void setBsqrsjhm(String bsqrsjhm) {
    this.bsqrsjhm = bsqrsjhm;
  }

  public void setNbgxm(String nbgxm) {
    this.nbgxm = nbgxm;
  }

  public void setZxyy(String zxyy) {
    this.zxyy = zxyy;
  }
}
