package  com.hzjc.hz2004.po;

public class PoXT_XTCSB implements com.hzjc.wsstruts.po.PO
{
  private Long csid;
  private String cslb;
  private String dm;
  private String mc;
  private String zwpy;
  private String kzbzb;
  private String kzbzc;
  private String kzbzd;
  private String kzbze;
  private String kzbzf;
  private String kzbzg;
  private String xgbz;
  private String bdlx;
  private String bdsj;

  public void setCsid(Long csid) {
    this.csid = csid;
  }

  public Long getCsid() {
    return csid;
  }

  public void setCslb(String cslb) {
    this.cslb = cslb;
  }

  public String getCslb() {
    return cslb;
  }

  public void setDm(String dm) {
    this.dm = dm;
  }

  public String getDm() {
    return dm;
  }

  public void setMc(String mc) {
    this.mc = mc;
  }

  public String getMc() {
    return mc;
  }

  public void setZwpy(String zwpy) {
    this.zwpy = zwpy;
  }

  public String getZwpy() {
    return zwpy;
  }

  public void setKzbzb(String kzbzb) {
    this.kzbzb = kzbzb;
  }

  public String getKzbzb() {
    return kzbzb;
  }

  public void setKzbzc(String kzbzc) {
    this.kzbzc = kzbzc;
  }

  public String getKzbzc() {
    return kzbzc;
  }

  public void setKzbzd(String kzbzd) {
    this.kzbzd = kzbzd;
  }

  public String getKzbzd() {
    return kzbzd;
  }

  public void setKzbze(String kzbze) {
    this.kzbze = kzbze;
  }

  public String getKzbze() {
    return kzbze;
  }

  public void setKzbzf(String kzbzf) {
    this.kzbzf = kzbzf;
  }

  public String getKzbzf() {
    return kzbzf;
  }

  public void setKzbzg(String kzbzg) {
    this.kzbzg = kzbzg;
  }

  public String getKzbzg() {
    return kzbzg;
  }

  public void setXgbz(String xgbz) {
    this.xgbz = xgbz;
  }

  public String getXgbz() {
    return xgbz;
  }

  public void setBdlx(String bdlx) {
    this.bdlx = bdlx;
  }

  public String getBdlx() {
    return bdlx;
  }

  public void setBdsj(String bdsj) {
    this.bdsj = bdsj;
  }

  public String getBdsj() {
    return bdsj;
  }

}
