package  com.hzjc.hz2004.po;

public class PoXT_HHXLB implements com.hzjc.wsstruts.po.PO
{
  private Long xlid;
  private String dwdm;
  private String hhxlid;

  public void setXlid(Long xlid) {
    this.xlid = xlid;
  }

  public Long getXlid() {
    return xlid;
  }

  public void setDwdm(String dwdm) {
    this.dwdm = dwdm;
  }

  public String getDwdm() {
    return dwdm;
  }

  public void setHhxlid(String hhxlid) {
    this.hhxlid = hhxlid;
  }

  public String getHhxlid() {
    return hhxlid;
  }

}
