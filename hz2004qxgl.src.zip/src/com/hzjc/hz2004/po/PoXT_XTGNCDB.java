package  com.hzjc.hz2004.po;

public class PoXT_XTGNCDB implements com.hzjc.wsstruts.po.PO
{
  private Long gncdid;
  private String cdcc;
  private String cdbz;
  private String cdlx;
  private String zdlb;
  private String cdmc;

  public void setGncdid(Long gncdid) {
    this.gncdid = gncdid;
  }

  public Long getGncdid() {
    return gncdid;
  }

  public void setCdcc(String cdcc) {
    this.cdcc = cdcc;
  }

  public String getCdcc() {
    return cdcc;
  }

  public void setCdbz(String cdbz) {
    this.cdbz = cdbz;
  }

  public String getCdbz() {
    return cdbz;
  }

  public void setCdlx(String cdlx) {
    this.cdlx = cdlx;
  }

  public String getCdlx() {
    return cdlx;
  }

  public void setZdlb(String zdlb) {
    this.zdlb = zdlb;
  }

  public String getZdlb() {
    return zdlb;
  }

  public void setCdmc(String cdmc) {
    this.cdmc = cdmc;
  }

  public String getCdmc() {
    return cdmc;
  }

}
