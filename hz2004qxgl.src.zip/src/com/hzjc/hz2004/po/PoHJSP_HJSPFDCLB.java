package  com.hzjc.hz2004.po;

public class PoHJSP_HJSPFDCLB implements com.hzjc.wsstruts.po.PO
{
  private Long spclid;
  private String splx;
  private Long spywid;
  private String clbh;

  public void setSpclid(Long spclid) {
    this.spclid = spclid;
  }

  public Long getSpclid() {
    return spclid;
  }

  public void setSplx(String splx) {
    this.splx = splx;
  }

  public String getSplx() {
    return splx;
  }

  public void setSpywid(Long spywid) {
    this.spywid = spywid;
  }

  public Long getSpywid() {
    return spywid;
  }

  public void setClbh(String clbh) {
    this.clbh = clbh;
  }

  public String getClbh() {
    return clbh;
  }

}
