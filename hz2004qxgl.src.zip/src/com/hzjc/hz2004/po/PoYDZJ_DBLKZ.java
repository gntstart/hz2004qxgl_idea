package  com.hzjc.hz2004.po;

public class PoYDZJ_DBLKZ implements com.hzjc.wsstruts.po.PO
{
  private String sbddm;
  private String sbdmc;
  private Long jbdbl;
  private Long ydbl;
  private String sfdbwc;
  private String cshsj;

  public void setSbddm(String sbddm) {
    this.sbddm = sbddm;
  }

  public String getSbddm() {
    return sbddm;
  }

  public void setSbdmc(String sbdmc) {
    this.sbdmc = sbdmc;
  }

  public String getSbdmc() {
    return sbdmc;
  }

  public void setJbdbl(Long jbdbl) {
    this.jbdbl = jbdbl;
  }

  public Long getJbdbl() {
    return jbdbl;
  }

  public void setYdbl(Long ydbl) {
    this.ydbl = ydbl;
  }

  public Long getYdbl() {
    return ydbl;
  }

  public void setSfdbwc(String sfdbwc) {
    this.sfdbwc = sfdbwc;
  }

  public String getSfdbwc() {
    return sfdbwc;
  }

  public void setCshsj(String cshsj) {
    this.cshsj = cshsj;
  }

  public String getCshsj() {
    return cshsj;
  }

}
