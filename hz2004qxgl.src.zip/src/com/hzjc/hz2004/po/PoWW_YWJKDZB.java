package  com.hzjc.hz2004.po;

public class PoWW_YWJKDZB implements com.hzjc.wsstruts.po.PO
{
  private Long dzid;
  private String bdywbh;
  private String bdywmc;
  private Long csid;
  private String fhlx;
  private String qybz;
  private String cjsj;

  public void setDzid(Long dzid) {
    this.dzid = dzid;
  }

  public Long getDzid() {
    return dzid;
  }

  public void setBdywbh(String bdywbh) {
    this.bdywbh = bdywbh;
  }

  public String getBdywbh() {
    return bdywbh;
  }

  public void setBdywmc(String bdywmc) {
    this.bdywmc = bdywmc;
  }

  public String getBdywmc() {
    return bdywmc;
  }

  public void setCsid(Long csid) {
    this.csid = csid;
  }

  public Long getCsid() {
    return csid;
  }

  public void setFhlx(String fhlx) {
    this.fhlx = fhlx;
  }

  public String getFhlx() {
    return fhlx;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

  public void setCjsj(String cjsj) {
    this.cjsj = cjsj;
  }

  public String getCjsj() {
    return cjsj;
  }

}
