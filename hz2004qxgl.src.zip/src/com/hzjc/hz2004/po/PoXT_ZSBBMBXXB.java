package  com.hzjc.hz2004.po;

public class PoXT_ZSBBMBXXB implements com.hzjc.wsstruts.po.PO
{
  private Long zsbbmbid;
  private String zsbblb;
  private String bbmbmc;
  private byte[] bbmb;
  private String jlsj;
  private Long scrid;
  private String xgsj;
  private Long xgrid;

  public void setZsbbmbid(Long zsbbmbid) {
    this.zsbbmbid = zsbbmbid;
  }

  public Long getZsbbmbid() {
    return zsbbmbid;
  }

  public void setZsbblb(String zsbblb) {
    this.zsbblb = zsbblb;
  }

  public String getZsbblb() {
    return zsbblb;
  }

  public void setBbmbmc(String bbmbmc) {
    this.bbmbmc = bbmbmc;
  }

  public String getBbmbmc() {
    return bbmbmc;
  }

  public void setBbmb(byte[] bbmb) {
    this.bbmb = bbmb;
  }

  public byte[] getBbmb() {
    return bbmb;
  }

  public void setJlsj(String jlsj) {
    this.jlsj = jlsj;
  }

  public String getJlsj() {
    return jlsj;
  }

  public void setScrid(Long scrid) {
    this.scrid = scrid;
  }

  public Long getScrid() {
    return scrid;
  }

  public void setXgsj(String xgsj) {
    this.xgsj = xgsj;
  }

  public String getXgsj() {
    return xgsj;
  }

  public void setXgrid(Long xgrid) {
    this.xgrid = xgrid;
  }

  public Long getXgrid() {
    return xgrid;
  }

}
