package  com.hzjc.hz2004.po;

public class PoXT_SPDZB implements com.hzjc.wsstruts.po.PO
{
  private String fwjb;
  private Long dzid;
  private String dzmc;
  private String ms;
  private String qybz;

  public void setFwjb(String fwjb) {
    this.fwjb = fwjb;
  }

  public String getFwjb() {
    return fwjb;
  }

  public void setDzid(Long dzid) {
    this.dzid = dzid;
  }

  public Long getDzid() {
    return dzid;
  }

  public void setDzmc(String dzmc) {
    this.dzmc = dzmc;
  }

  public String getDzmc() {
    return dzmc;
  }

  public void setMs(String ms) {
    this.ms = ms;
  }

  public String getMs() {
    return ms;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

}
