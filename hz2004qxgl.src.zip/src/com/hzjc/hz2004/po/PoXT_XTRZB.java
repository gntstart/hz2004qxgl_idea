package  com.hzjc.hz2004.po;

public class PoXT_XTRZB implements com.hzjc.wsstruts.po.PO
{
  private Long rzid;
  private String czkssj;
  private String czjssj;
  private Long zxsj;
  private Long czyid;
  private String khdip;
  private String rzlx;
  private String rznr;
  private String ywbz;
  private String organization;// ORGANIZATION;
  private String organizationId;//ORGANIZATION_ID;
  private String operateType;//OPERATE_TYPE;
  private String operateResult;//OPERATE_RESULT;
  private String errorCode;//ERROR_CODE;
  private String operateName;//OPERATE_NAME;
  private String resourceType;//RESOURCE_TYPE;
  private String resourceName;//RESOURCE_NAME;
  private String czyxm;

public void setCzyxm(String czyxm) {
      this.czyxm = czyxm;
  }

  public String getCzyxm() {
      return czyxm;
  }

  public void setResourceName(String resourceName) {
      this.resourceName = resourceName;
  }

  public String getResourceName() {
      return resourceName;
  }

  public void setResourceType(String resourceType) {
      this.resourceType = resourceType;
  }

  public String getResourceType() {
      return resourceType;
  }


  public void setOperateName(String operateName) {
      this.operateName = operateName;
  }

  public String getOperateName() {
      return operateName;
  }

  public void setErrorCode(String errorCode) {
      this.errorCode = errorCode;
    }

  public String getErrorCode() {
      return errorCode;
  }

  public void setOperateResult(String operateResult) {
    this.operateResult = operateResult;
  }

  public String getOperateResult() {
    return operateResult;
  }

  public void setOperateType(String operateType) {
    this.operateType = operateType;
  }

  public String getOperateType() {
    return operateType;
  }

  public String getOrganizationId() {
    return organizationId;
  }

  public void setOrganizationId(String organizationId) {
    this.organizationId = organizationId;
  }

  public String getOrganization() {
    return organization;
  }
  public void setOrganization(String organization) {
    this.organization = organization;
  }

  public void setRzid(Long rzid) {
    this.rzid = rzid;
  }

  public Long getRzid() {
    return rzid;
  }

  public void setCzkssj(String czkssj) {
    this.czkssj = czkssj;
  }

  public String getCzkssj() {
    return czkssj;
  }

  public void setCzjssj(String czjssj) {
    this.czjssj = czjssj;
  }

  public String getCzjssj() {
    return czjssj;
  }

  public void setZxsj(Long zxsj) {
    this.zxsj = zxsj;
  }

  public Long getZxsj() {
    return zxsj;
  }

  public void setCzyid(Long czyid) {
    this.czyid = czyid;
  }

  public Long getCzyid() {
    return czyid;
  }

  public void setKhdip(String khdip) {
    this.khdip = khdip;
  }

  public String getKhdip() {
    return khdip;
  }

  public void setRzlx(String rzlx) {
    this.rzlx = rzlx;
  }

  public String getRzlx() {
    return rzlx;
  }

  public void setRznr(String rznr) {
    this.rznr = rznr;
  }

  public String getRznr() {
    return rznr;
  }

  public void setYwbz(String ywbz) {
    this.ywbz = ywbz;
  }

  public String getYwbz() {
    return ywbz;
  }

}
