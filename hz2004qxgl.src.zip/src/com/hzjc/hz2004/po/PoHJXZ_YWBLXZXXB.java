package  com.hzjc.hz2004.po;

public class PoHJXZ_YWBLXZXXB implements com.hzjc.wsstruts.po.PO
{
  private Long xzxxid;
  private String xzmc;
  private String xzywlx;
  private String xzbds;
  private Long cjrid;
  private String cjsj;
  private Long xgrid;
  private String xgsj;
  private String xzzt;
  private String qybz;
  private Long spmbid;

  public void setXzxxid(Long xzxxid) {
    this.xzxxid = xzxxid;
  }

  public Long getXzxxid() {
    return xzxxid;
  }

  public void setXzmc(String xzmc) {
    this.xzmc = xzmc;
  }

  public String getXzmc() {
    return xzmc;
  }

  public void setXzywlx(String xzywlx) {
    this.xzywlx = xzywlx;
  }

  public String getXzywlx() {
    return xzywlx;
  }

  public void setXzbds(String xzbds) {
    this.xzbds = xzbds;
  }

  public String getXzbds() {
    return xzbds;
  }

  public void setCjrid(Long cjrid) {
    this.cjrid = cjrid;
  }

  public Long getCjrid() {
    return cjrid;
  }

  public void setCjsj(String cjsj) {
    this.cjsj = cjsj;
  }

  public String getCjsj() {
    return cjsj;
  }

  public void setXgrid(Long xgrid) {
    this.xgrid = xgrid;
  }

  public Long getXgrid() {
    return xgrid;
  }

  public void setXgsj(String xgsj) {
    this.xgsj = xgsj;
  }

  public String getXgsj() {
    return xgsj;
  }

  public void setXzzt(String xzzt) {
    this.xzzt = xzzt;
  }

  public String getXzzt() {
    return xzzt;
  }

  public void setQybz(String qybz) {
    this.qybz = qybz;
  }

  public String getQybz() {
    return qybz;
  }

  public void setSpmbid(Long spmbid) {
    this.spmbid = spmbid;
  }

  public Long getSpmbid() {
    return spmbid;
  }

}
