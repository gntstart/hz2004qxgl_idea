package  com.hzjc.hz2004.po;

public class PoDZZJ_CZYXXB implements com.hzjc.wsstruts.po.PO
{
  private Long czyid;
  private String czydlm;
  private String czyxm;
  private String czymm;
  private String czydwdm;
  private String czysfhm;
  private String czysfzglh;
  private String sbglh;
  private String czyzw1;
  private String czyzw2;
  private String zcsj;
  private String zxsj;
  private String czyzt;
  private String ktglhdn;

  public void setCzyid(Long czyid) {
    this.czyid = czyid;
  }

  public Long getCzyid() {
    return czyid;
  }

  public void setCzydlm(String czydlm) {
    this.czydlm = czydlm;
  }

  public String getCzydlm() {
    return czydlm;
  }

  public void setCzyxm(String czyxm) {
    this.czyxm = czyxm;
  }

  public String getCzyxm() {
    return czyxm;
  }

  public void setCzymm(String czymm) {
    this.czymm = czymm;
  }

  public String getCzymm() {
    return czymm;
  }

  public void setCzydwdm(String czydwdm) {
    this.czydwdm = czydwdm;
  }

  public String getCzydwdm() {
    return czydwdm;
  }

  public void setCzysfhm(String czysfhm) {
    this.czysfhm = czysfhm;
  }

  public String getCzysfhm() {
    return czysfhm;
  }

  public void setCzysfzglh(String czysfzglh) {
    this.czysfzglh = czysfzglh;
  }

  public String getCzysfzglh() {
    return czysfzglh;
  }

  public void setSbglh(String sbglh) {
    this.sbglh = sbglh;
  }

  public String getSbglh() {
    return sbglh;
  }

  public void setCzyzw1(String czyzw1) {
    this.czyzw1 = czyzw1;
  }

  public String getCzyzw1() {
    return czyzw1;
  }

  public void setCzyzw2(String czyzw2) {
    this.czyzw2 = czyzw2;
  }

  public String getCzyzw2() {
    return czyzw2;
  }

  public void setZcsj(String zcsj) {
    this.zcsj = zcsj;
  }

  public String getZcsj() {
    return zcsj;
  }

  public void setZxsj(String zxsj) {
    this.zxsj = zxsj;
  }

  public String getZxsj() {
    return zxsj;
  }

  public void setCzyzt(String czyzt) {
    this.czyzt = czyzt;
  }

  public String getCzyzt() {
    return czyzt;
  }
  public String getKtglhdn() {
    return ktglhdn;
  }
  public void setKtglhdn(String ktglhdn) {
    this.ktglhdn = ktglhdn;
  }

}
