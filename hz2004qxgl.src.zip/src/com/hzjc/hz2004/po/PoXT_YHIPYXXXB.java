package  com.hzjc.hz2004.po;

public class PoXT_YHIPYXXXB implements com.hzjc.wsstruts.po.PO
{
  private Long ipyxid;
  private Long yhid;
  private String ipdz;
  private Long cjrid;
  private String cjsj;

  public void setIpyxid(Long ipyxid) {
    this.ipyxid = ipyxid;
  }

  public Long getIpyxid() {
    return ipyxid;
  }

  public void setYhid(Long yhid) {
    this.yhid = yhid;
  }

  public Long getYhid() {
    return yhid;
  }

  public void setIpdz(String ipdz) {
    this.ipdz = ipdz;
  }

  public String getIpdz() {
    return ipdz;
  }

  public void setCjrid(Long cjrid) {
    this.cjrid = cjrid;
  }

  public Long getCjrid() {
    return cjrid;
  }

  public void setCjsj(String cjsj) {
    this.cjsj = cjsj;
  }

  public String getCjsj() {
    return cjsj;
  }

}
