package  com.hzjc.hz2004.po;

public class PoXT_SJBBHB implements com.hzjc.wsstruts.po.PO
{
  private Long xlid;
  private String rq;
  private String bhid;

  public void setXlid(Long xlid) {
    this.xlid = xlid;
  }

  public Long getXlid() {
    return xlid;
  }

  public void setRq(String rq) {
    this.rq = rq;
  }

  public String getRq() {
    return rq;
  }

  public void setBhid(String bhid) {
    this.bhid = bhid;
  }

  public String getBhid() {
    return bhid;
  }

}
